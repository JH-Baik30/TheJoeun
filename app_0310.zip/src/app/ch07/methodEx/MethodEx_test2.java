package app.ch07.methodEx;

import java.util.Scanner;
// 연습 2 : 저장 범위의 합
public class MethodEx_test2 {
	public static void sum(int start, int end) {
		int sum = 0;
		for (int i = start; i <= end; i++) {
			sum += i;
		}
		System.out.println(sum);
	}
	
	public static void main(String[] args) {
		System.out.print("시작할 수를 입력하세요. : ");
		int start = new Scanner(System.in).nextInt();
		System.out.print("합할 마지막수를 입력하세요. : ");
		int end = new Scanner(System.in).nextInt();
		sum(start, end);
	}
}
