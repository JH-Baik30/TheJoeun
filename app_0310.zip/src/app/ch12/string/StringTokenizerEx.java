package app.ch12.string;

import java.util.StringTokenizer;

public class StringTokenizerEx {
	public static void main(String[] args) {
		String str = "자바 SE,자바 EE,자바 ME";
		String derim = ","; // args[0]
		StringTokenizer st;
//		st = new StringTokenizer(str);
		st = new StringTokenizer(str, derim);		// 1
		st = new StringTokenizer(str, derim, true); // 2
		System.out.println(st.countTokens());
		while ( st.hasMoreTokens() ) {
			String token = st.nextToken();
			System.out.println(token);
			System.out.println(st.countTokens());
		}
	}
}
