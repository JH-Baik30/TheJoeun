package app.ch12;

class PointEx { // 암시적으로 Object 클래스의 상속을 받는다.
	int x, y;
	public PointEx() {
		
	}
	public PointEx(int x, int y) {
		this.x = x;
	}
	
	@Override
		public String toString() {
			String str;
			str = "( " + x + ", " + y + " )";
			return str;
		}
}

public class ObjectEx {
	public static void main(String[] args) {
		PointEx pt = new PointEx();
		System.out.println("클래스 이름 : " + pt.getClass());
		System.out.println("클래스 이름 : " + pt.hashCode());
		PointEx pt2 = new PointEx(10, 20);
		System.out.println("클래스 이름 : " + pt2.getClass());
		// getClass는 프레임웍에서 주로 사용
		System.out.println("클래스 이름 : " + pt2.hashCode());
		// hashCode 리플랙션 할때 사용 
		// 자바는 new 객체생성 이라는 정적방법외에 리플렉션이라는 방법이 있다.
		// 리플렉션 - 클래스의 정보를 가지고 객체를 생성하는 방법
		System.out.println(pt == pt2);
		System.out.println(pt.equals(pt2));
		// String의 equals 는 Object 의 equals 를 @Override 하고 있다.
		System.out.println(pt2);			// toString을 안해도 toString이 호출된다.
//		System.out.println(pt2.toString()); // toString을 안해도 toString이 호출된다.
	}
}
