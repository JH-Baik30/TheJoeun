package app.ch04;

public class OperEx1 {
	public static void main(String[] args) {
		/*int su1 = 10;
		int su2 = 20;
		int result = 0;
		result = su1 + su2;
		System.out.println("결과1 : " + result);
		result = su1 - su2;
		System.out.println("결과2 : " + result);
		result = su1 * su2;
		System.out.println("결과3 : " + result);
		result = su1 / su2;
		System.out.println("결과4 : " + result);
		result = su1 % su2;
		System.out.println("결과5 : " + result);*/
		
		int sum = 1+2+3+4+5+6+7+8+9+10;
//		int a1 = 1;
//		int a2 = 2;
//		int a3 = 3;
//		int a4 = 4;
//		int a5 = 5;
//		int a6 = 6;
//		int a7 = 7;
//		int a8 = 8;
//		int a9 = 9;
//		int a10 = 10;
		
		System.out.println(sum);
		
		
	}
}
