package app.banktest;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class UI extends JFrame{
	public JButton bt1, bt2, btx, bt3, bt4, bt5, bt6, btLO;
	public TextArea tArea;
	public JPanel jpb1, jpt, jpb2;
	private JLabel label;
	
	public UI() {
		label = new JLabel("A label");
		label.setFont(new Font("Serif", Font.PLAIN, 20));
		label.setForeground(new Color(0xffffdd));
		
		bt1 = new JButton("은행 업무");
		bt1.setPreferredSize(new Dimension(100, 50));
		bt2 = new JButton("계좌 개설");
		bt2.setPreferredSize(new Dimension(100, 50));
		btx = new JButton("종     료");
		btx.setPreferredSize(new Dimension(100, 50));
		bt3 = new JButton("입     금");
		bt3.setPreferredSize(new Dimension(100, 50));
		bt4 = new JButton("출     금");
		bt4.setPreferredSize(new Dimension(100, 50));
		bt5 = new JButton("예금 조회");
		bt5.setPreferredSize(new Dimension(100, 50));
		bt6 = new JButton("계좌 이체");
		bt6.setPreferredSize(new Dimension(100, 50));
		btLO = new JButton("업무 종료");
		btLO.setPreferredSize(new Dimension(100, 50));
		tArea = new TextArea();
		
		jpb1 = new JPanel();
		jpt = new JPanel();
		jpb2 = new JPanel();
//		jpb1.setLayout(null);
		jpb1.add(bt1);	jpb1.add(bt2);	jpb1.add(btx);
		jpt.add(tArea, BorderLayout.SOUTH);
		jpb2.add(bt3);	jpb2.add(bt4);	jpb2.add(bt5);	jpb2.add(bt6);	jpb2.add(btLO);
		
		setLayout(new GridLayout(1, 3));
		add(jpb1, BorderLayout.CENTER);
		add(jpt, BorderLayout.CENTER);
		add(jpb2, BorderLayout.CENTER);
		
		setSize(500,400);
		setVisible(true);
		
		// 없음 안댐!!!
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	
	
	
	public static void main(String[] args) {
		new UI();
	}
}
