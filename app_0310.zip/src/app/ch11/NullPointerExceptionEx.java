package app.ch11;

public class NullPointerExceptionEx {
	public static void main(String[] args) {
		String data = null;
		if ( data == null ) {
			System.out.println(data.toString());
		}
	}
}
