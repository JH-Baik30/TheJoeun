package app.ch08.makeClassEx;

public class WorkPc extends PcBase{
	
	void work() {
		powerOn();
		startWork();
		videoEdit();
		powerOff();
	}
	void startWork() {
		System.out.println("작업을 시작합니다.");
	}
	void videoEdit() {
		System.out.println("영상편집을 합니다.");
	}
	
	
}
