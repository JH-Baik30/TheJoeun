package app.ch17;

public class ThreadEx extends Thread{
	@Override
	public void run() {
		try {
//			while (true) {
			for (int i = 0; i < 10; i++) {
				Thread.sleep(500);
//				System.out.println("작업1");
				System.out.println("작업2");
//			}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		
		ThreadEx thread = new ThreadEx();
//		thread.start();
		thread.run();
		while (true) {
			try {
				thread.sleep(1000);
				System.out.println("메인작업");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
