package app.ch05;

public class ForEx2 {
	public static void main(String[] args) {
		
	}
}
