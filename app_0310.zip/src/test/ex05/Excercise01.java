package test.ex05;

public class Excercise01 {
 public static void main(String[] args) {
	int sum = 0;
	for (int i = 0; i <= 100; i += 5) {
		sum += i;
	}
	System.out.println(sum);
}
}
