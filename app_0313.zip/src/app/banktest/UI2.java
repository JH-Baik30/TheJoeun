package app.banktest;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class UI2 extends JFrame implements ActionListener{
	public JButton bt1, bt2, bt3, bt4, bt5, bt6, btExit, btLogIn;
	public TextArea tArea;
	public JPanel jpb1, jpt, jpb2;
//	private JLabel label;
	String s1 = "입     금",
		   s2 = "출     금",
		   s3 = "예금 조회",
		   s4 = "계좌 이체",
		   s5 = "공 사 중",
		   s6 = "계좌 개설",
		   sLogIn = "로그 인",
		   sExit = "종     료";
	
	
	public UI2() {
		bt1 = new JButton(s1);//"은행 업무");
		bt1.setPreferredSize(new Dimension(50, 25));
		bt2 = new JButton(s2);
		bt2.setPreferredSize(new Dimension(50, 2));
		bt3 = new JButton(s3);
		bt3.setPreferredSize(new Dimension(100, 50));
		bt4 = new JButton(s4);
		bt4.setPreferredSize(new Dimension(100, 50));
		bt5 = new JButton(s5);
		bt5.setPreferredSize(new Dimension(100, 50));
		bt6 = new JButton(s6);
		bt6.setPreferredSize(new Dimension(100, 50));
		btExit = new JButton(sLogIn);
		btExit.setPreferredSize(new Dimension(50, 25));
		btLogIn = new JButton(sExit);
		btLogIn.setPreferredSize(new Dimension(100, 50));
		tArea = new TextArea();
		
		jpb1 = new JPanel(new BorderLayout(50, 50));
		jpt = new JPanel();
		jpb2 = new JPanel();
		jpb1.setLayout(new GridLayout(3, 1));
		jpb1.add(bt1);	jpb1.add(bt2);	jpb1.add(btExit);
		jpt.setLayout(new BorderLayout());
		jpt.add(tArea, BorderLayout.CENTER);
		jpb2.setLayout(new GridLayout(5, 1));
		jpb2.add(bt3);	jpb2.add(bt4);	jpb2.add(bt5);	jpb2.add(bt6);	jpb2.add(btLogIn);
		
		/*add(bt1, BorderLayout.WEST);
		add(bt2, BorderLayout.WEST);
		add(btx, BorderLayout.WEST);
		add(jpt, BorderLayout.CENTER);
		add(bt3, BorderLayout.EAST);
		add(bt4, BorderLayout.EAST);
		add(bt5, BorderLayout.EAST);
		add(bt6, BorderLayout.EAST);
		add(btLO, BorderLayout.EAST);*/
		
		
//		setLayout(new GridLayout(1, 3, 20, 20));
		setLayout(new GridLayout(1, 3));
		add(jpb1, BorderLayout.CENTER);
		add(jpt, BorderLayout.CENTER);
		add(jpb2, BorderLayout.CENTER);
		setTitle("ATM");
		setSize(500,400);
		setVisible(true);
		
		bt1.addActionListener(this);
		bt2.addActionListener(this);
		bt3.addActionListener(this);
		bt4.addActionListener(this);
		bt5.addActionListener(this);
		bt6.addActionListener(this);
		btExit.addActionListener(this);
		btLogIn.addActionListener(this);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if (obj == bt1) {
			tArea.setText(" << 입금을 선택하셨습니다. >>");
			
		} else if (obj == bt2) {
			tArea.setText(" << 출금을 선택하셨습니다. >>");
			
		} else if (obj == bt3) {
			tArea.setText(" << 조회를 선택하셨습니다. >>");
			
		} else if (obj == bt4) {
			tArea.setText(" << 계좌이체를 선택하셨습니다. >>");
			
		} else if (obj == bt5) {
			tArea.setText(" << 서비스 준비중 >>");
			
		} else if (obj == bt6) {
			tArea.setText(" << 계좌 개설을 선택하셨습니다. >>");
			
		} else if (obj == bt2) {
			
		} else if (obj == bt2) {
			
		} else if (obj == bt2) {
			
		} else if (obj == bt2) {
			
		}
		
		
		
//		"은행 업무"
//		"계좌 개설"
//		"입     금"
//		"출     금"
//		"예금 조회"
//		"계좌 이체"
//		"종     료"
//		"업무 종료"		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	public static void main(String[] args) {
		new UI2();
	}

}
