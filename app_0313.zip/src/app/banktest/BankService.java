package app.banktest;

public class BankService {
	public static void main(String[] args) {
//		CreateAccMenu bankGo = new CreateAccMenu();
		CreateAccMenu2 bankGo = new CreateAccMenu2();
//		try {
			bankGo.logInMenu();			
//		} catch (Exception e) {
//			System.out.println("계좌 생성이 불가합니다. 관리자에게 문의하세요.");
//		}
	}
}
