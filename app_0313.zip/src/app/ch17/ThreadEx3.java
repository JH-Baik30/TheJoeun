package app.ch17;

public class ThreadEx3 implements Runnable{
	@Override
	public void run() {
		while (true) {
			try {
				Thread.sleep(500);
				System.out.println("Ex3 run");
			} catch (InterruptedException e) {
			}
		}
	}
	public static void main(String[] args) {
		ThreadEx3 threadEx3 = new ThreadEx3();
		Thread thread1 = new Thread(threadEx3);
		thread1.start();
		ThreadEx threadEx = new ThreadEx();
		threadEx.start();
		while (true) {
			try {
				Thread.sleep(1000);
				System.out.println("Ex3 main");
			} catch (InterruptedException e) {
			}
		}
		
	}
}
