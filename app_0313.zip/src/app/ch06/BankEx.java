package app.ch06;

import java.util.Scanner;

public class BankEx {
	public static void main(String[] args) {
		boolean run = true;
		Scanner scanner = new Scanner(System.in);
		int[][] member = { {1, 0} , {2, 0} };
		
		do {
			System.out.println("-----------------------------------");
			System.out.println(" 1. 예금 | 2. 출금 | 3. 잔고 | 4. 총료 ");
			System.out.println("-----------------------------------");
			System.out.print("선택> ");
			int menuNum = scanner.nextInt();
			switch (menuNum) {
			case 1:
				System.out.print("사용자 선택> ");
				int user = scanner.nextInt();
				System.out.print("예금액> ");
				member[user-1][1] += scanner.nextInt();
//				System.out.println(member[user-1][1]);
				break;
			case 2:
				System.out.print("사용자 선택> ");
				user = scanner.nextInt();
				System.out.println("출금액> ");
				int out = scanner.nextInt();
				if (out > member[user-1][1]) {
					System.out.println("잔고가 부족합니다.");
				} else {
					member[user-1][1] -= out;
					System.out.println("출금이 완료되었습니다.");
				}
				break;
			case 3:
				System.out.print("사용자 선택> ");
				user = scanner.nextInt();
				switch (user) {
				case 1: {
					System.out.print("잔고> ");
					System.out.println(member[user-1][1]);}
					break;
				case 2: { 
					System.out.print("잔고> ");
					System.out.println(member[user-1][1]);}
					break;
				}
				break;
			case 4:
				run = false;
				break;
			default:
				System.out.println("Wrong answer");
			}			
			System.out.println();
		} while (run);
		System.out.println("프로그램 종료");
	}
}
