package app.ch05;

public class WhileEx {
	public static void main(String[] args) {
		int odd = 0;
		int even = 0;
		int i = 1;
		while (i <= 10) {
			if (i % 2 == 1) {
				odd += i;
			} else {
				even += i;
			}
			i++;
		}
		System.out.println("홀수의 합: " + odd);
		System.out.println("짝수의 합: " + even);

		int su = 0;
		int sum = 0;
		while (su < 10) {
			sum += ++su;
		}
		System.out.println(sum);
		System.out.println(su);
	}
}
