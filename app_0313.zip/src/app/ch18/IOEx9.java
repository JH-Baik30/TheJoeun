package app.ch18;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class IOEx9 {
	public static void main(String[] args) throws IOException{
		File file = new File("G:/work/file/IO.txt");
		
		// 문자열 데이터를 기록
		FileWriter fWriter = new FileWriter(file);
		
		BufferedWriter bw = new BufferedWriter(fWriter);		// 버퍼에 담긴걸 그때그때 뿌려준다. (편함)
		// 파일을 기록할대마다 플러쉬 해줘야 하는데 알아서 해주는코드
		PrintWriter pw = new PrintWriter(bw, true);				// 오토 플러쉬 true,  true를 빼면 34번줄에 flush()를 줘야한다.
																// flush() -> 버퍼에 있는 내용을 뿌려준다.
		// 입력한 데이터를 읽어서 메모리 버퍼에 올리는 코드
		InputStream is = System.in;
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		System.out.print("입력 : ");
		String str = "";
		while (!str.equals("end")) {			// end 를 치면 종료
			// 입력한 것을
			str = br.readLine();
			// 파일로 기록
			pw.println(str);
			bw.write(str);
//			pw.flush()
			
		}
		br.close();
//		pw.close();
		
		
		
		
	}
}
