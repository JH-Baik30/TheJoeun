// 선생님 답안

package app.ch12.calendar;

import java.util.Calendar;

public class CalendarMissionAns {
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();

		int year = cal.get(Calendar.YEAR);
		int month = (cal.get(Calendar.MONTH) + 1);
		int date = cal.get(Calendar.DATE);
		cal.set(2023, month-1, 1);
		date = cal.get(Calendar.DAY_OF_WEEK);
		int lastDay = cal.getActualMaximum(Calendar.DATE);
		System.out.println(date);
		
		System.out.println("	" + 2023 + "년 " +  03 + "월 ");
		System.out.println();
		System.out.println("일\t월\t화\t수\t목\t금\t토");
		for (int i = 1; i < lastDay + date; i++) {
			if( i < date ) {
				System.out.print("\t");
				continue;
			}
			System.out.print((i - date + 1) + "\t");
			if (i % 7 == 0) {
				System.out.println();
				
			}
		}
		
	}
}
