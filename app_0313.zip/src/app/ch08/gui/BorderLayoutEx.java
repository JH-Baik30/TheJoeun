package app.ch08.gui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class BorderLayoutEx extends Frame{
	public Button b1, b2, b3, b4, b5;
	
	public BorderLayoutEx() {
		b1 = new Button("1");
		b2 = new Button("2");
		b3 = new Button("3");
		b4 = new Button("4");
		b5 = new Button("5");
//		BorderLayout borderLayout = new BorderLayout();   1안 재사용을 위한 객체생성
//		setLayout(new BorderLayout());					//2안 1회용.  
		// frame은 default 배치관리자를 가지고 있어서 생략가능.
		// 다른 layout을 쓰려면 적용해야한다.
		
		add(b1, BorderLayout.NORTH);
		add(b2, BorderLayout.CENTER);
		add(b3, BorderLayout.EAST);
		add(b4, BorderLayout.WEST);
		add(b5, BorderLayout.SOUTH);
		setSize(300, 300);
		setVisible(true);
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);			}
		});
	}
	
	public static void main(String[] args) {
		new BorderLayoutEx();
	}
}
