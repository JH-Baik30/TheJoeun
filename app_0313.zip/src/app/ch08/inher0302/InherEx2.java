package app.ch08.inher0302;

public class InherEx2 extends SuperClass2{
	
	int age = 10;
	String name;
	public void method() {
		System.out.println("SubClass Method");
	}
	
	public static void main(String[] args) {
		InherEx2 inher = new InherEx2();
		System.out.println(inher.age);
		inher.method();
		SuperClass2 superClass = inher;
		InherEx2 inher2 = (InherEx2) superClass;
		Object obj = inher;
		Object obj2 = superClass;
		InherEx2 inher3 = (InherEx2) obj;
		inher3.method();
		Object[] objArr = new Object[2];
		objArr[0] = inher;		//Object
		objArr[1] = superClass;	//Object
//		objArr[0].arr = 10;		//error
		InherEx2 inher4 = (InherEx2) objArr[0];
		inher4.age = 10;
		superClass.method();
		
	}
}

class SuperClass2 {
	int age = 20;			// 은닉변수
	public void method() {
		System.out.println("SuperClass Method");
	}
}