package app.ch20_0315_17;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

public class DBEx4 {
	public static void main(String[] args) {
		String driver = "com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/app";
		Connection conn = null;
		Statement stmt = null;
		
		try {
			Class.forName(driver);
			System.out.println("데이터베이스 드라이버 로딩성공!");
			conn = DriverManager.getConnection(url, "root", "java");	
			System.out.println("데이터베이스 연결성공!");
			stmt = conn.createStatement();
			
			String sql = insert();
			int result = stmt.executeUpdate(sql);
			String msg = result > -1 ? "성공" : "실패";
		} catch (Exception e) {
			System.out.println("데이터베이스 드라이버 로딩및 연결실패!");
			e.printStackTrace();
		} finally {
			try {
				if(stmt != null) stmt.close();		// 상태를 닫고
				if(conn != null) conn.close();		// 연결을 끊는다.
			} catch (Exception e2) {	}
		}
	}
	
	/**
	 * DATA INSERT
	 * @return sql
	 */
	
	public static String insert() {
		Scanner scan = new Scanner(System.in);
		System.out.println("DBTEST 테이블에 값 입력하기");
		System.out.print("ID : ");
		String id = scan.next();
		String sql = "INSERT INTO DBTEST VALUES('" + id + "')";
		// INSERT INTO DBTEST VALUES('id')		// mysql or oracle 동일
		return sql;
	}
	
}
