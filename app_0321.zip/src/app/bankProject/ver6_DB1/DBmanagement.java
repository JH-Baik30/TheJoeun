package app.bankProject.ver6_DB1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import com.mysql.cj.xdevapi.Result;

public class DBmanagement {
	String driver = "com.mysql.cj.jdbc.Driver";
	String url = "jdbc:mysql://localhost:3306/app";
	Connection conn = null;
	Statement stmt = null;
	private String msg;
	
	public String controlDB(String sql) {
		try {
			Class.forName(driver);
			System.out.println("데이터베이스 드라이버 로딩성공!");
			conn = DriverManager.getConnection(url, "root", "java");	
			System.out.println("데이터베이스 연결성공!");
			stmt = conn.createStatement();
			int result = stmt.executeUpdate(sql);
			msg = result > -1 ? "성공" : "실패";
		} catch (Exception e) {
			System.out.println("데이터베이스 드라이버 로딩및 연결실패!");
		} finally {
			try {
				if(stmt != null) stmt.close();		// 상태를 닫고
				if(conn != null) conn.close();		// 연결을 끊는다.
			} catch (Exception e2) {	}
		}
		return msg;
	}
//	Account, Name, PW, Balance
//	Create Read Update Delete
	public void readfromDB() {
		String sql = "SELECT * FROM BANKDB";
		msg = controlDB(sql);
		System.out.println("DB 로드에 " + msg + " 했습니다.");
	}
	
	public void insertToDB(int account, String name, String pw) {
		String sql = "INSERT INTO BANKDB(Name, PW) "
//				+ "VALUES('" + account + "', '" + name + "', '" + pw + "')";
				+ "VALUES('1234', 'name', 'pw')";
		msg = controlDB(sql);
		System.out.println("계좌 생성에 " + msg + " 했습니다.");
	}
	
	public void updateToDB() {
//		msg = controlDB(sql);
		System.out.println("DB 로드에 " + msg + " 했습니다.");
	}
	
	public void deleteToDB(int account) {
		String sql = "DELETE FROM BANKDB WHERE Account='"+ account + "'";
		msg = controlDB(sql);
		System.out.println("DB 삭제 " + msg + " 했습니다.");
	}
	public void deleteToDB(String name) {
		String sql = "DELETE FROM BANKDB WHERE Name='"+ name + "'";
		msg = controlDB(sql);
		System.out.println("DB 삭제 " + msg + " 했습니다.");
	}
	public void backupToDB(int acc, String name, String pw, int bal) {
		String sql = "UPDATE BANKDB SET Account='"+acc+"', "
				+ "Name='"+name+"', PW='"+pw+"', Balance='"+bal+"'";
		msg = controlDB(sql);
		System.out.println("DB에 저장이 " + msg + "되었습니다.");
	}
}

