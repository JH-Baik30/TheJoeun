package app.bankProject.ver1;

public class Member {
	private String name;
	private int account;
	private String pw;
	int balance = 0;
	public Member(int account) {
		super();
		this.account = account;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAccount() {
		return account;
	}
	public void setAccount(int account) {
		this.account = account;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String passward) {
		this.pw = passward;
	}
	
	
	
	

}
