package app.bankProject.ver6_DB2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;

public class DBmanagement {
	String driver = "com.mysql.cj.jdbc.Driver";
	String url = "jdbc:mysql://localhost:3306/app";
	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	private String msg;
	
	public String controlDB(String sql) {
		try {
			Class.forName(driver);
//			System.out.println("데이터베이스 드라이버 로딩성공!");
			conn = DriverManager.getConnection(url, "root", "java");	
			System.out.println("데이터베이스 연결성공!");
			stmt = conn.createStatement();
			int result = stmt.executeUpdate(sql);
			msg = result > -1 ? "성공" : "실패";
		} catch (Exception e) {
			System.out.println("데이터베이스 드라이버 로딩및 연결실패!");
		} finally {
			try {
				if(stmt != null) stmt.close();		// 상태를 닫고
				if(conn != null) conn.close();		// 연결을 끊는다.
			} catch (Exception e2) {	}
		}
		return msg;
	}
//	Account, Name, PW, Balance
//	Create Read Update Delete
	public ArrayList<Member> readfromDB() {
		ResultSet rfDB = null;
		ArrayList<Member> mem = new ArrayList<>();
		try {
			Class.forName(driver);
//			System.out.println("데이터베이스 드라이버 로딩성공!");
			conn = DriverManager.getConnection(url, "root", "java");	
			System.out.println("데이터베이스 연결성공!");
			stmt = conn.createStatement();
			String sql = "SELECT * FROM BANKDB";
			rfDB = stmt.executeQuery(sql);
			
			while (rfDB.next()) {
//				Member member = new Member();
				mem.add(new Member().setAccount(rfDB.getInt("account"))
									.setName(rfDB.getString("name"))
									.setPw(rfDB.getString("pw"))
									.setBalance(rfDB.getInt("balance")));
			}
			
			
//			System.out.println(1);
//			System.out.println(rfDB);
			return mem;
//			ResultSetMetaData rsmd = rs.getMetaData();
//			int result = stmt.executeUpdate(sql);
//			msg = result > -1 ? "성공" : "실패";
//			System.out.println("DB 로드에 " + msg + " 했습니다.");
		} catch (Exception e) {
			System.out.println("데이터베이스 드라이버 로딩및 연결실패!");
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();		// 상태를 닫고
				if(conn != null) conn.close();		// 연결을 끊는다.
			} catch (Exception e2) {	}
		}
//		System.out.println(2);
//		System.out.println(rfDB);
		return null;
	}
	
	public void insertToDB(int account, String name, String pw) {
//		String sql = "INSERT INTO BANKDB VALUES(aaa, '123', 10, NOW())";
		String sql = "INSERT INTO BANKDB VALUES('"
			+ account + "', '" + name + "', '" + pw + "', " + 0 + ", NOW())";
		msg = controlDB(sql);
		System.out.println("계좌 생성에 " + msg + " 했습니다.");
	}
	
	public void updateToDB() {
//		msg = controlDB(sql);
		System.out.println("DB 로드에 " + msg + " 했습니다.");
	}
	
	public void deleteToDB(int account) {
		String sql = "DELETE FROM BANKDB WHERE Account='"+ account + "'";
		msg = controlDB(sql);
		System.out.println("DB 삭제 " + msg + " 했습니다.");
	}
	public void deleteToDB(String name) {
		String sql = "DELETE FROM BANKDB WHERE Name='"+ name + "'";
		msg = controlDB(sql);
		System.out.println("DB 삭제 " + msg + " 했습니다.");
	}
	public void backupToDB(int acc, String name, String pw, int bal) {
		String sql = "UPDATE BANKDB SET Account='"+acc+"', "
				+ "Name='"+name+"', PW='"+pw+"', Balance='"+bal+"'";
		msg = controlDB(sql);
		System.out.println("DB에 저장이 " + msg + "되었습니다.");
	}
	
	// DBadmin 에서 test 용으로 사용하는 메소드
	public void sqlTestMethod(String sql) {
//		String sql = "INSERT INTO BANKDB VALUES(aaa, '123', 10, NOW())";
		msg = controlDB(sql);
		System.out.println("작업 결과 : " + msg);
	}
	
}

