package app.ch11_0310;

public class BalanceInsufficientException extends Exception{
	public BalanceInsufficientException() {	}
	public BalanceInsufficientException(String message) {
		super(message);
	} 
}
