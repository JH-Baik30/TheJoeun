package app.ch07_0227_28;

public class Car2 {
	int wheel;
	int speed;
	String name;
	public void display() {
		System.out.println();
	}
}
