package app.ch20_0321_alter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * Ex1) NOW, SYSDATE : 현재시간, 날짜정보 출력
 * Ex2) CURDATA, CURRENTDATE : 현재 날짜정보 출력
 * Ex3) CURTIME, CURRENTTIME : 현재 시간정보 출력
 */

public class DBEx19 {
	public static void main(String[] args) {
		Connection conn = DBAction.getInstance().getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		String sql = select();
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			rsmd = rs.getMetaData();
			int columnsCnt = rsmd.getColumnCount();
			for (int i = 1; i <= columnsCnt; i++) {
				String columnName = rsmd.getColumnName(i);
				System.out.print(columnName + "\t");
			}
			System.out.println("\n---------------------------------");
			
			while (rs.next()) {
				for (int i = 1; i <= columnsCnt; i++) {
					System.out.print(rs.getString(i) + "\t");
				}
				System.out.println();
			}
					
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	
	public static String select() {
//		Ex1) NOW, SYSDATE : 현재시간, 날짜정보 출력
		String sql = "SELECT SYSDATE() SYSDATE, NOW() NOW";
//		Ex2) CURDATA, CURRENTDATE : 현재 날짜정보 출력
//		String sql = "SELECT CURDATE() CURDATE, CURRENT_DATE() CURRENTDATE";
//		Ex3) CURTIME, CURRENTTIME : 현재 시간정보 출력
//		String sql = "SELECT CURTIME() CURTIME, CURRENT_TIME() CURRENTTIME";
		return sql;
		
		// 실습과제> 뱅크 사용자(회원) 가입일 기록하시오.
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
