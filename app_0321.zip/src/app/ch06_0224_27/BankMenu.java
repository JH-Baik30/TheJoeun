package app.ch06_0224_27;

import java.util.Scanner;

public class BankMenu {
	public static void main(String[] args) {
		boolean run = true;
		int balance = 0;
		Scanner scanner = new Scanner(System.in);
		
		do {
			System.out.println("-----------------------------------");
			System.out.println(" 1. 예금 | 2. 출금 | 3. 잔고 | 4. 총료 ");
			System.out.println("-----------------------------------");
			System.out.print("선택> ");
			int menuNum = scanner.nextInt();
			switch (menuNum) {
			case 1:
				System.out.println("예금액> ");
				balance += scanner.nextInt();
				System.out.println(" " + balance);
				break;
			case 2:
				System.out.println("출금액> ");
				int out = scanner.nextInt();
				if (out > balance) {
					System.out.println("잔고가 부족합니다.");
				} else {
					balance -= out;
					System.out.println("출금이 완료되었습니다.");
				}
				break;
			case 3:
				System.out.println("잔고> ");
				System.out.println(balance);
				break;
			case 4:
				run = false;
				break;
			default:
				System.out.println("Wrong answer");
			}			
			System.out.println();
		} while (run);
		System.out.println("프로그램 종료");
	}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
