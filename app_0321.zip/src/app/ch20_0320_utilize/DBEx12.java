// primary key		다른 테이블과 조인
package app.ch20_0320_utilize;

import java.sql.Connection;
import java.sql.Statement;

/*	CREATE TABLE TEST3(
			ID VARCHAR(10) PRIMARY KEY, 
			PW VARCHAR(30), 
			NAME VARCHAR(30), 
			MDate DATE,
			AGE INT
			);
*/
public class DBEx12 {
	public static void main(String[] args) {
		Connection conn = DBAction.getInstance().getConnection();
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
//			String sql = createTable();			// create table
			String sql = insert();				// add member
			
			stmt.executeUpdate(sql);
//			UNIQUE
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
			}
		}
	}
	public static String createTable() {
		String sql = "CREATE TABLE TEST3("
				+ "ID VARCHAR(10) PRIMARY KEY, "
				+ "PW VARCHAR(30), "
				+ "NAME VARCHAR(30), MDate DATE, AGE INT)"
				;
		return sql;
	}
	
	public static String insert() {
//		String sql = "INSERT INTO TEST3(PW) VALUES('123')";				// 1. NOT NULL 테스트
//		String sql = "INSERT INTO TEST3(ID, PW) VALUES('ABC', '123')";	// 2. UNIQUE 테스트
		String sql = "INSERT INTO TEST3(ID, PW) VALUES('ABC', '123', '홍길동', '2023-03-20', 10)";		// 2. UNIQUE 테스트
		return sql;
	}
}

