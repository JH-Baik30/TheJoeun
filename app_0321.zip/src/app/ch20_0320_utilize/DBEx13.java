// 순번 자동증가
package app.ch20_0320_utilize;

import java.sql.Connection;
import java.sql.Statement;
import java.util.Scanner;

public class DBEx13 {
	public static void main(String[] args) {
		Connection conn = DBAction.getInstance().getConnection();
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
//			String sql = createTable();			// create table
//			String sql = insert();				// add member
			String sql = delete();
			stmt.executeUpdate(sql);
//			UNIQUE
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	
	/**
	 * TABLE CREATE
	 * @return sql
	 */
	
	public static String createTable() {
//	CREATE SEQUENCE num_seq START WITH 1 INCREMENT BY 1 NOCACHE;// 오라클 순번 자동증가
//			객체
		String sql = "CREATE TABLE TEST4("
				+ "NUM INT AUTO_INCREMENT PRIMARY KEY, "		// 순번 자동증가
				+ "ID VARCHAR(10) UNIQUE, "
				+ "PW VARCHAR(30), "
				+ "NAME VARCHAR(30), "
				+ "MDate DATE, "
				+ "AGE INT)"
				;
		return sql;
	}
	
	/**
	 * DATA INSERT
	 * @return sql
	 */
	
	public static String insert() {
		Scanner scan = new Scanner(System.in);
		System.out.print("id : ");
		String id = scan.next();
		System.out.print("pw : ");
		String pw = scan.next();
		System.out.print("name : ");
		String name = scan.next();
		System.out.print("age : ");
		int age = scan.nextInt();
		
//		String sql = "INSERT INTO TEST4(ID, PW, NAME, MDate, AGE) "
//				+ "VALUES('ABC', '123', '홍길동', '2023-03-20', 10)";		// 2. UNIQUE 테스트
		String sql = "INSERT INTO TEST4(ID, PW, NAME, MDate, AGE) "
				+ "VALUES('" + id + "', '" + pw + "', '" + name + "', now(), " + age + ")";		// 2. UNIQUE 테스트
		return sql;
	}
	
	public static String delete() {
		Scanner scan = new Scanner(System.in);
		System.out.print("id : ");
		String id = scan.next();
		String sql = "DELETE FROM TEST4 WHERE ID='" + id + "'";
//		DELETE FROM DBTEST2 WHERE ID='b'";//, PASSWORD='2' WHERE ID='d' AND PASSWORD='4'
		return sql;
	}
}
