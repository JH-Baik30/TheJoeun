package app.bank;

public class Banking {
	public void deposit() {
		
	}
	
	public void withDraw() {
		
	}
	
	public void accountTransfer() {
		
	}
	
	public void balance() {
		
	}
}
