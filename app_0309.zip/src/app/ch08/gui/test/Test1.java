package app.ch08.gui.test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Scrollbar;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.text.TabableView;

public class Test1 extends JFrame implements AdjustmentListener{
	public Scrollbar s1, s2, s3;
		TextArea ta;
		TextField tf;
	public Test1() {
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();

		p1.setLayout(new GridLayout(10,1));
		
		JLabel la1 = new JLabel("");
		s1 = new Scrollbar(Scrollbar.HORIZONTAL, 0, 10, 0, 265);
		JLabel la2 = new JLabel("");
		s2 = new Scrollbar(Scrollbar.HORIZONTAL, 0, 10, 0, 265);
		JLabel la3 = new JLabel("");
		s3 = new Scrollbar(Scrollbar.HORIZONTAL, 0, 10, 0, 265);
		JLabel la4 = new JLabel("");
		JLabel la5 = new JLabel("현재 색상");
//		setLayout(new GridLayout(4, 2));
		tf = new TextField("R:255 G:255 B:255", 30);
		JLabel la6 = new JLabel("");
		
		p2.setLayout(new BorderLayout(3,1));
		JLabel la7 = new JLabel("");
		ta = new TextArea("", 100, 10);
		JLabel la8 = new JLabel("");
		
		setLayout(new GridLayout(1,2));
		p1.add(la1);
		p1.add(s1);
		p1.add(la2);
		p1.add(s2);
		p1.add(la3);
		p1.add(s3);
		p1.add(la4);
		p1.add(la5);
		p1.add(tf);
		p1.add(la6);
//		p2.add(la6);
		Label l8 = new Label("");
		Label l9 = new Label("");
		Label l10 = new Label("");
		Label l11 = new Label("");
		p2.add(l8, BorderLayout.NORTH);
		p2.add(l9, BorderLayout.EAST);
		p2.add(ta, BorderLayout.CENTER);
		p2.add(l10, BorderLayout.WEST);
		p2.add(l11, BorderLayout.SOUTH);
//		p2.add(la7);
		add(p1);
		add(p2);
		
		setSize(500, 400);
		setVisible(true);
		s1.addAdjustmentListener(this);
		s2.addAdjustmentListener(this);
		s3.addAdjustmentListener(this);	
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				super.windowClosing(e);
				System.exit(0);
			}
		});
		
	}
	@Override
	public void adjustmentValueChanged(AdjustmentEvent e) {
		int r = 255 - s1.getValue();
		int g = 255 - s2.getValue();
		int b = 255 - s3.getValue();
		
		Color color = new Color(r, g, b);
		ta.setBackground(color);
		tf.setText(" R : " + r + " G : " + g + " B : " + b);
	}
	
	public static void main(String[] args) {
		new Test1();
	}

}
