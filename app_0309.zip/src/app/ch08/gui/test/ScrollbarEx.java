package app.ch08.gui.test;
// Test1 답안
import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Scrollbar;
import java.awt.TextArea;
import java.awt.TextField;

public class ScrollbarEx extends Frame{
	public Panel p1, p2;
	public Scrollbar sb_r, sb_g, sb_b;
	public TextField tf;
	public TextArea ta;
	public ScrollbarEx() {
		setTitle("ScrollbarEx");
		tf = new TextField();
		ta = new TextArea();
		p1 = new Panel();
		p2 = new Panel();
		sb_r = new Scrollbar(0, 0, 10, 0, 265);
		sb_g = new Scrollbar(0, 0, 10, 0, 265);
		sb_b = new Scrollbar(0, 0, 10, 0, 265);
		
		Label la1 = new Label("");
		Label la2 = new Label("");
		Label la3 = new Label("");
		Label la4 = new Label("");
		Label la5 = new Label("");
		Label la6 = new Label("");
		Label la7 = new Label("");
		Label la8 = new Label("");
		Label la9 = new Label("");
		Label la10 = new Label("현재색상");
		
		p1.setLayout(new GridLayout(10, 1));
		p2.setLayout(new BorderLayout());
		setLayout(new GridLayout(1, 2));		// this가 생략되어있다.
		
		p1.add(la1);
		p1.add(sb_r);
		p1.add(la2);
		p1.add(sb_g);
		p1.add(la3);
		p1.add(sb_b);
		p1.add(la4);
		p1.add(la10);
		p1.add(tf);
		p1.add(la5);
		
		p2.add(la6, BorderLayout.EAST);
		p2.add(ta, BorderLayout.CENTER);
		p2.add(la7, BorderLayout.WEST);
		p2.add(la8, BorderLayout.NORTH);
		p2.add(la9, BorderLayout.SOUTH);
		
		add(p1);								// this 생략됨.
		add(p2);								// this 생략됨.
		setSize(300, 300);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new ScrollbarEx();
	}
}
