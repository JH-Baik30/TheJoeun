package app.ch12.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

public class ArrayListEx {
	public static void main(String[] args) {
		ArrayList<Integer> arr = new ArrayList<>();
		arr.add(1);			// auto boxing
		arr.add(2);
		arr.add(3);
		arr.add(4);
		arr.add(5);
		arr.add(6);
		//System.out.println(arr.get(0));
		
		for (int i = 0; i < arr.size(); i++) {
			System.out.println(i+ " : " + arr.get(i));
		}
		
		List<Integer> arr2 = Arrays.asList(1, 2, 3);
		for (int i = 0; i < arr2.size(); i++) {
			System.out.println("arr2[" + i + "] = " + arr2.get(i));
		}
		
		arr2.set(0, 100);
		arr2.set(1, 200);
		arr2.set(2, 300);
		for (int i = 0; i < arr2.size(); i++) {
			System.out.println("arr2[" + i + "] = " + arr2.get(i));
		}
		
		Vector<String> str = new Vector<>();
		for (int i = 0; i < str.size(); i++) {
			System.out.println("str[" + i + "] = " + str.get(i));
		}
		
		str.add("A");
		str.add("B");
		str.add("C");
		for (int i = 0; i < str.size(); i++) {
			System.out.println("str[" + i + "] = " + str.get(i));
		}
		for (String s : str) {
			System.out.println(s);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
