package app.banktest;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class CreateAccMenu2 {
	Scanner scanner = new Scanner(System.in);
//	Member[] member = new Member[100];
	ArrayList<Member> member = new ArrayList<>();
	int idx;
	int cnt = 267100;
	
	public Member logIn() {				//////// 로그인할때 인덱스값을 같이 날릴까???
		System.out.print("계좌 번호를 입력하세요.");
		int inputAcc = scanner.nextInt();
		System.out.print("비밀 번호를 입력하세요.");
		String inputPw = scanner.next();
			for (int i = 0; i < member.size(); i++) {
				if (member.get(i).getAccount() == inputAcc) {
					if (member.get(i).getPw().equals(inputPw)) {
						idx = i;
						return member.get(i);
					} //else {	System.out.println("비번 틀림");	}
				} //else {	System.out.println("아이디 틀림");		}
			}
			System.out.println("계좌번호와 비밀번호를 확인하세요.");
			return null;
	}

	public Member creatAccount() {
		System.out.println("이름을 입력하세요.");
		String name = scanner.next();
		System.out.println("비밀번호를 입력하세요.");
		String pw = scanner.next();
		member.add(new Member(cnt, name, pw));
		member.get(idx).info();
		idx++;
		cnt++;
		return member.get(idx);
	}
	
	public Member accountTransfer(int x) {
		System.out.println("이체할 대상의 계좌번호를 입력하세요.");
		int targetAcc = scanner.nextInt();
		System.out.println("이체할 금액를 입력하세요.");
		int transferMoney = scanner.nextInt();
		for (int i = 0; i < member.size(); i++) {
			if (member.get(i).getAccount() == targetAcc) {
				member.get(i).deposit(transferMoney);
//					System.out.println("대상자 "+ member[i].getName() + "님께 송금합니다.");
				member.get(x-267100).transfer(transferMoney);
				System.out.println(member.get(x-267100).getAccount() + "님께 " + transferMoney + "원 송금완료");
			}
		}
		return member.get(x-267100);
	}
	
	public void logInMenu() {
		boolean run = true;
		do {
			System.out.println();
			System.out.println("-------------------------------");
			System.out.println(" 1. 은행업무 | 2. 계좌생성 | 3. 종료 ");
			System.out.println("-------------------------------");
			System.out.print("선택 > ");
			int num = scanner.nextInt();

			switch (num) {
			case 1:
				Member member =	logIn();
				if (member != null) {
					bankMenu(member);
				}
				break;
			case 2:
				creatAccount();
				break;
			case 3:
				run = false;
				break;
			default:
				System.out.println("잘못입력했습니다");
			}
		} while (run);
	}
	
	public Member bankMenu(Member member) {
		boolean run = true;
		do {
			System.out.println();
			System.out.println(" " + member.getName() + "님 로그인중 ");
			System.out.println("-------------------------------------------");
			System.out.println(" 1. 입금 | 2. 출금 | 3. 잔고 | 4. 이체 | 5. 종료 ");
			System.out.println("-------------------------------------------");
			System.out.print("선택 > ");

			int main = scanner.nextInt();

			switch (main) {
			case 1:
				System.out.println("입금할 금액을 입력하세요.");
				int money = scanner.nextInt();
				member.deposit(money);
				break;
			case 2:
				System.out.println("출금할 금액을 입력하세요.");
				money = scanner.nextInt();
				member.withDraw(money);
				break;
			case 3:
				member.balance();
				break;
			case 4:
				accountTransfer(member.getAccount());
				break;
			case 5:
				run = false;
				break;
				
			default:
				System.out.println("잘못입력했습니다.");
			}

		} while (run);
		return member;

	}
	
}
