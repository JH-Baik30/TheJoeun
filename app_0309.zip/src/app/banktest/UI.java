package app.banktest;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class UI extends JFrame{
	public JButton bt1, bt2, btx, bt3, bt4, bt5, bt6, btLO;
	public TextArea tArea;
	public JPanel jpb1, jpt, jpb2;
	
	public UI() {
		bt1 = new JButton("은행 업무");
		bt2 = new JButton("계좌 개설");
		btx = new JButton(" 종  료 ");
		bt3 = new JButton(" 입  금 ");
		bt4 = new JButton(" 출  금 ");
		bt5 = new JButton("예금 조회");
		bt6 = new JButton("계좌 이체");
		btLO = new JButton("업무 종료");
		
		jpb1 = new JPanel();
		jpt = new JPanel();
		jpb2 = new JPanel();
//		jpb1.setLayout(null);
		jpb1.add(bt1);	jpb1.add(bt2);	jpb1.add(btx);
//		jpt.add(tArea, BorderLayout());
		jpb2.add(bt3);	jpb2.add(bt4);	jpb2.add(bt5);	jpb2.add(bt6);	jpb2.add(btLO);
		
		setLayout(new GridLayout(1, 3));
		add(jpb1);
		add(jpt);
		add(jpb2);
		
		setSize(500,400);
		setVisible(true);
		
		add(bt1);	add(bt2);	add(btx);	
		add(bt3);	add(bt4);	add(bt5);	add(bt6);	add(btLO);
		
		
		
		
	}
	
	
	
	
	public static void main(String[] args) {
		new UI();
	}
}
