package app.ch07.methodEx;

public class MethodEx_test2_1 {

}
