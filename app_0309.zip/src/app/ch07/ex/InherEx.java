package app.ch07.ex;

public class InherEx extends SuperClass {
	int a;
	String b;

	public InherEx() {
		super(10);
		System.out.println("InderEX");
	}

	public static void main(String[] args) {
		InherEx inher = new InherEx();
		inher.a = 10;
		inher.b = "A";
		inher.c = 10;
		inher.d = "B";
	}
}

class SuperClass {
	int c;
	String d;
	
	SuperClass(int a) {
		System.out.println("SuperClass " + a);
	}
	
	
	public SuperClass() {
		System.out.println("SuperClass ");
	}

}