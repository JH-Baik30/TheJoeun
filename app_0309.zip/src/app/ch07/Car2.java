package app.ch07;

public class Car2 {
	int wheel;
	int speed;
	String name;
	public void display() {
		System.out.println();
	}
}
