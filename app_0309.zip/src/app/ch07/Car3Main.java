package app.ch07;

public class Car3Main {
	public static void main(String[] args) {
		Car3 myCar = new Car3();
		myCar.display();
		Car3 myCar2 = new Car3("그랜저", 4);
		myCar2.setSpeed(300);
		myCar2.display();
		Car3 myCar3 = new Car3("에쿠스" , 500, 4);
		myCar3.display();
		myCar3.display("티코", 100, 4);
	}
}

class Car3{
	int wheel;
	int speed;
	String name;
	public Car3() {
		name = "GV80";
		speed = 200;
		wheel = 4;
	}
	
	public Car3(String name) {
		this.name = name;
	}
	public Car3(String name, int wheel) {
		this.name = name;
		this.wheel = wheel;
	}
	public Car3(String name, int speed,int wheel) {
		this.name = name;
		this.speed = speed;
		this.wheel = wheel;
	}
	public void setSpeed(int speed) {
		this.speed = speed;		
	}
	public int getSpeed() {
		return this.speed;
	}
	
	public void display() {
		System.out.println("차이름 : " + name + ", 최대 속도 : " + speed +
				", 바퀴수 : " + wheel);
	}
	public void display(String name, int speed, int wheel) {
		System.out.println("차이름 : " + name + ", 최대 속도 : " + speed +
				", 바퀴수 : " + wheel);
	}
}
