package test.bank;

class Account {
	private String accountNumber;
	private String name;
	private String pwd;
	private int balance;
	
	public Account() {
		
	}

	public Account(String accountNumber, String name, String pwd, int balance) {
		this.accountNumber = accountNumber;
		this.name = name;
		this.pwd = pwd;
		this.balance = balance;
	}
	
	public void printAccounts() {
		System.out.printf("계좌번호 : %s, 이름 : %s, 비밀번호 : %s, 잔고 : %,d원%n",
							accountNumber, name, pwd, balance);
	}
	
	public void deposit(int amount) {
		this.balance += amount;
	}
	
	public void withDraw(int amount) {
		this.balance -= amount;
	}
	
	public String getAccountNumber() {
		return this.accountNumber;
	}
	public int getBalance() {
		return this.balance;
	}

	
}
