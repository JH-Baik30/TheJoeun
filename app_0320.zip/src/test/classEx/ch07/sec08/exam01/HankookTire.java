package test.classEx.ch07.sec08.exam01;

public class HankookTire extends Tire {

	@Override
	public void roll() {
		System.out.println("한국타이어가 회전합니다.");
	}
}
