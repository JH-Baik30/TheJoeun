package app.ch05_0224;

import java.util.Scanner;

public class DoWhileEx {
	public static void main(String[] args) {
		int count = 0;
		/*do {
			count++;
			System.out.println("실행 구문 " + count);
		} while (count < 10);
		*/
		System.out.print("입력하세요~ : ");
		@SuppressWarnings("resource")
		int gugu = new Scanner(System.in).nextInt();
		int sum = 1;
		do {
			count++;
			sum = gugu * count;
			System.out.println(gugu + " * " + count + " = " + sum);
		} while (count < 9);
	}
}
