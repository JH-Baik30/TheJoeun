package app.ch05_0224;

public class ForEx2 {
	public static void main(String[] args) {
		
	}
}
