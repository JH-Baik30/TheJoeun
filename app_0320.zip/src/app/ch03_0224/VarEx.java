package app.ch03_0224;

public class VarEx {
	public static void main(String[] args) {
		int su = 0;
		su = 10;
		System.out.println(su);
		su = 20;
		System.out.println(su);
		su = 30;
		System.out.println(su);
		String str = "문자열의 값";
		System.out.println(str);
		str = "변경된 문자열 값";
		System.out.println(str);
	}
}
