package app.ch08_0302_12.gui;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class EventEx extends JFrame implements ActionListener{
	public JButton b1, b2, b3;
	public EventEx() {
		b1 = new JButton("b1");
		b2 = new JButton("b2");
		b3 = new JButton("b3");
		setLayout(new FlowLayout());
		add(b1);
		add(b2);
		add(b3);
		setSize(300, 300);
		setVisible(true);
		b1.addActionListener(this); 				// 1. 버튼을 누르면,
		b2.addActionListener(this);
		b3.addActionListener(this);
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {	//2. 호출
		// 선생님 풀이
		Object obj = e.getSource(); 							//객체를 가져온다.
		if (obj == b1) {
			System.out.println("이벤트 발생 1");
		} else if (obj == b2) {
			System.out.println("이벤트 발생 2");
		} else if (obj == b3) {
			System.out.println("이벤트 발생 3");
		}
		
//		Button str = (Button) obj;
//		
//		switch (str.getLabel()) {
//		case "b1":
//			System.out.println(1);
//			break;
//		case "b2":
//			System.out.println(2);
//			break;
//		case "b3":
//			System.out.println(3);
//			break;
//		}
		
		// 내 풀이(도움받음)
//		if (e.getSource().equals(b1)) {	System.out.println("1"); }
//		if (e.getSource().equals(b2)) {	System.out.println("2"); }
//		if (e.getSource().equals(b3)) {	System.out.println("3"); }		
	}
	
	public static void main(String[] args) {
		new EventEx();
	}

}
