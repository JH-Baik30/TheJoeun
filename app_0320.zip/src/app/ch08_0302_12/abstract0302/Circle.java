package app.ch08_0302_12.abstract0302;

public class Circle extends Shape {
	protected int r;
	
	public Circle(int r) {
		this.r = r;
	}
	
	@Override
	public double area() {
		return pi*r*r;
	}

	@Override
	public double circumference() {
		return pi*2*r;
	}
	
	public int getRadius() {
		return r;
	}
	public void setRadius(int r) {
		this.r = r;
	}

}
