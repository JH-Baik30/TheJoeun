package app.ch08_0302_12.abstract0302;
/*추상 (abstract)
 *  객체의 모호함을 class로 표현하기위함.
 *  특징
 *  - class에 사용시 추상 class의 의미(ex : abstract class).
 *  - 일반 메서드와 추상 메서드 사용 가능.
 *  - 객체 생성할 수 없음.
 *  - 상속관계에서 재정의 함.
 *  - 내부 익명 클래스로 객체생성 할 수 있음.
 *  - 추상 메소드는 구현하지 않는다.
 *  - 추상 메서드는 override로 사용.
 *  - 상솟시 extends keyword 사용.  
 */

public class AbstractEx {

}
