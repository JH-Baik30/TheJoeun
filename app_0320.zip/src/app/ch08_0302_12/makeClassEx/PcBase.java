package app.ch08_0302_12.makeClassEx;

public class PcBase {
	String cpuCompany;
	String cpuModel;
	String gpu;
	int ramSize;
	int psu;
	
	void spec() {
		System.out.println(cpuCompany);
		System.out.println(cpuModel);
		System.out.println(gpu);
		System.out.println(ramSize + "GB");
		System.out.println(psu + "W");
	}
	void powerOn() {
		System.out.println("전원을 켭니다.");
	}
	void powerOff() {
		System.out.println("전원을 끕니다.");
	}
}

class Amd extends PcBase{
	private String cpuCompany = "AMD";
	String cpuModel = "5600X";
	String gpu = "내장그래픽";
	int ramSize = 8;
	
	public Amd(String cpuModel) {
		this.cpuModel = cpuModel;	}
	
	public Amd(String cpuModel, String gpu) {
		this.cpuModel = cpuModel;
		this.gpu = gpu;	}

	public Amd(String cpuModel, String gpu, int ramSize) {
		this.cpuModel = cpuModel;
		this.gpu = gpu;
		this.ramSize = ramSize;	}
	
	public Amd(String cpuModel, String gpu, int ramSize, int psu) {
		super();
		this.cpuModel = cpuModel;
		this.gpu = gpu;
		this.ramSize = ramSize;
		this.psu = psu; }
		
	public String getCpuCompany() {
		return cpuCompany;
	}
	
}

class Intel extends PcBase{
	private String cpuCompany = "AMD";
	String cpuModel = "5600X";
	String gpu = "내장그래픽";
	int ramSize = 8;
	
	public Intel(String cpuModel) {
		this.cpuModel = cpuModel;	}
	
	public Intel(String cpuModel, String gpu) {
		this.cpuModel = cpuModel;
		this.gpu = gpu;	}

	public Intel(String cpuModel, String gpu, int ramSize) {
		this.cpuModel = cpuModel;
		this.gpu = gpu;
		this.ramSize = ramSize;	}
	
	public Intel(String cpuModel, String gpu, int ramSize, int psu) {
		super();
		this.cpuModel = cpuModel;
		this.gpu = gpu;
		this.ramSize = ramSize;
		this.psu = psu; }
		
	public String getCpuCompany() {
		return cpuCompany;
	}
	
}