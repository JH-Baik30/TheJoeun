package app.bankProject.ver5_UI1;

public class DbTrans {

}
