package app.bankProject.bankSuppoters.junghyun;

public class BankMain {
    public static void main(String[] args) {
        BankSystem bankSystem = new BankSystem();
        bankSystem.start();
    }
}
