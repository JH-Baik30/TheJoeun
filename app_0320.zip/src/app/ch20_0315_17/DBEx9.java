package app.ch20_0315_17;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DBEx9 {
	public static void main(String[] args) throws Exception {
		Properties properties = new Properties();
		properties.load(DBEx5_EX6use.class.getResourceAsStream("database.properties"));
		String driver = properties.getProperty("driver");
		String url = properties.getProperty("url");
		String id = properties.getProperty("username");
		String pw = properties.getProperty("password");
		Connection conn = null;		//
		Statement stmt = null;		// 상태
		ResultSet rs = null;		// 추출한 데이터를 담을 set 컬렉션
		
		try {
			Class.forName(driver);
			System.out.println("loading OK!");
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("connect OK!");
			stmt = conn.createStatement();
			// 생성
//			String sql = insert(); 
//			int result = stmt.executeUpdate(sql);
//			String msg = result > -1 ? "성공" : "실패";
//			System.out.println(msg);
			// 가져오기
			String sql = select();
			rs = stmt.executeQuery(sql);
			System.out.println(rs);
			ResultSetMetaData rsmd = rs.getMetaData();
			int cnt = rsmd.getColumnCount();
			while (rs.next()) {
				for (int i = 1; i <= cnt; i++) {
					System.out.print(rs.getString(i) + "\t");
				}
				System.out.println();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e2) {		}
		}
	}
	/**
	 * DATA INSERT
	 * @return sql
	 */
	
	public static String insert() {
		String sql = "INSERT INTO DBTEST3(ID, PW) VALUES('ABC', '123')";
		return sql;
	}
	/**
	 * DATA SELECT
	 * @return SQL
	 */
	public static String select() {
		String sql = "SELECT * FROM DBTEST3";
		return sql;
	}
	
}
