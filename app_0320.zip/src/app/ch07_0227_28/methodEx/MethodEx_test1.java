package app.ch07_0227_28.methodEx;

import java.util.Scanner;
// 연습 1 : 몇 단 곱하기 1~몇까지 의 구구단
public class MethodEx_test1 {
	public static void gugudan(int dan, int su) {
		for (int i = 1; i <= su; i++) {
			System.out.println(dan + " * " + i + " = " + dan*i);
		}
	}
	
	public static void main(String[] args) {
		System.out.print("단을 입력하세요. ");
		int dan = new Scanner(System.in).nextInt();
		System.out.print("수를 입력하세요. ");
		int su = new Scanner(System.in).nextInt();
		gugudan(dan, su);
	}
}
