package app.ch19_0314;

import java.net.ServerSocket;
import java.util.Vector;

public class ChatServer {
	private Vector handlers;
	
	// 서버가 사용자를 기다리는 메소드
	public ChatServer(int port) {
		try {
			ServerSocket server = new ServerSocket(port);
			handlers = new Vector<>();
			System.out.println("ChatServer is ready");
			while (true) {
				ChatHandler handler = new ChatHandler(this, server.accept());
				handler.start();
			}
			
		} catch (Exception e) {		}
	}
	public Object getHandler(int index) {
		return handlers.elementAt(index);
	}
	
	// 들어오는 사용자
	public void register(ChatHandler c) {
		handlers.addElement(c);				// vector 에 추가
	}
	// 나가는 사용자
	public void unRegister(Object o) {
		handlers.removeElement(o);			// vector 에서 삭제
	}
	// 전체에게 나간 사람 들어온사람 싱크로 메시지 보내는 메소드
	public void broadcast (String message) {
		synchronized (handlers) {			// 영역을 정해서 동기화
			int n = handlers.size();
			for (int i = 0; i < n; i++) {
				ChatHandler c = (ChatHandler) handlers.elementAt(i);
				try {
					c.println(message);
				} catch (Exception e) {	}
			}
		}
	}
	
	public static void main(String[] args) {
		new ChatServer(7979);
	}
	
}
