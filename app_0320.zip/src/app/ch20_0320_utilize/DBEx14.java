// table 연결  Foreign KEY
// 하위 관계, 같이 만들어야 한다.
package app.ch20_0320_utilize;

import java.sql.Connection;
import java.sql.Statement;
import java.util.Scanner;

/*	CREATE TABLE TEST5(
		ID INT AUTO_INCREMENT PRIMARY KEY, // AUTO_INCREMENT 자동증가 
		NAME VARCHAR(30), 
	);
	CREATE TABLE TEST5_1(
		TEST_1_id INT PRIMARY KEY,
		ID INT, 
		FOREIGN KEY (ID) REFERENCES TEST5(ID) 
	);
*/

public class DBEx14 {
	public static void main(String[] args) {
		Connection conn = DBAction.getInstance().getConnection();
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
//			String sql = createTable();			// create table
			String sql = insert();				// add member
//			String sql = delete();
			stmt.executeUpdate(sql);
//			UNIQUE
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	
	/**
	 * TABLE CREATE
	 * @return sql
	 */
	
	public static String createTable() {
//	CREATE SEQUENCE num_seq START WITH 1 INCREMENT BY 1 NOCACHE;// 오라클 순번 자동증가
//			객체
		String sql = "CREATE TABLE TEST5("
				+ "ID INT AUTO_INCREMENT PRIMARY KEY, "			// 주 키 
				+ "NAME VARCHAR(30))";
/*		String sql = "CREATE TABLE TEST5_1("
				+ "TEST_1_id AUTO_INCREMENT INT PRIMARY KEY, "
				+ "ID INT, "						// 주 키와 연결된다.
				+ "FOREIGN KEY (ID) REFERENCES TEST5(ID))";
*/		return sql;
	}
	
	public static String insert() {
//		Scanner scan = new Scanner(System.in);
//		System.out.print("id : ");
//		String id = scan.next();
//		System.out.print("pw : ");
		
		String sql = "INSERT INTO TEST5(ID, NAME) VALUES(1, 'a')";
//		String sql = "INSERT INTO TEST5(ID, PW, NAME, MDate, AGE) "
//				+ "VALUES('" + id + "', '" + pw + "', '" + name + "', now(), " + age + ")";		// 2. UNIQUE 테스트
		return sql;
	}

}

// insert 로 넣어보기. 전체 drop 해보기


