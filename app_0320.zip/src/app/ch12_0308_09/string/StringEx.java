package app.ch12_0308_09.string;

public class StringEx {
	public static void main(String[] args) {
		Object o = "obj";
		String s = "obj";
		String s2 = "obj";
		
		System.out.println(o.equals(s));
		System.out.println(o == s);
		System.out.println(s.equals(o));
		System.out.println(s == o);
		System.out.println(s.equals(s2));
		System.out.println(s == s2);
		System.out.println(o.hashCode());
		System.out.println(s.hashCode());
		System.out.println(s2.hashCode());
		o = "obj2";
		String z = null;
		String d = " ";
		System.out.println(o == s);
		System.out.println(o.equals(s));
		System.out.println(o.hashCode());
		
		if( o instanceof Object) {
			System.out.println("ok!\n");
		}
		System.out.println( o );
		System.out.println( z = o.toString());
		System.out.println( s.equals(d) );
		System.out.println( o == s);
		o = s;
		String s3 = new String("obj");
		System.out.println( "결과1 : " + (s == s3));
		System.out.println( "결과2 : " + (s.equals(s3)));
	}
}
