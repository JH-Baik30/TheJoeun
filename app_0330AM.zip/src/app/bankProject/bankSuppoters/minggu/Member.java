package app.bankProject.bankSuppoters.minggu;

public class Member {
	String name, id, pw;
	int account = 10000;
	int money;
//	ArrayList<Member> member = new ArrayList<>();
//	Member admin = new Member("admin","admin","admin",10000);

	public Member() {
	}

	public Member(String id, String pw, String name) {
		this.id = id;
		this.pw = pw;
		this.name = name;
	}

	public Member(String id, String pw, String name, int account) {
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.account = account;
	}

	public String getName()				 {	return name;		}
	public void setName(String name)	 {	this.name = name;	}

	public String getId() 				 {	return id;		}
	public void setId(String id) 		 {	this.id = id;	}

	public String getPw() 				 {	return pw;		}
	public void setPw(String pw) 		 {	this.pw = pw;	}

	public void deposit(int money)		 {	this.money += money;	}

	public void withDraw(int money) 	 {	this.money -= money;	}

	public int getMoney() 				 {	return money;	}
	public int getAccount() 			 {	return account;	}
	public void setAccount( int account) {	this.account = account;	}

}
