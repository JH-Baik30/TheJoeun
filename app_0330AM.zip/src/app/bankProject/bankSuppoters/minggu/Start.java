package app.bankProject.bankSuppoters.minggu;

import java.util.Scanner;

public class Start {
	int menuNum;
	Scanner sc = new Scanner(System.in);
	LoginSystem ls = new LoginSystem();
	BankMenu bm = new BankMenu();

	public void start() {
		// 어드민 계정 여기로 옮김
		Member admin = new Member("admin", "admin", "admin", 10000);
		ls.member.add(0, admin);
		do {
			System.out.println("1. 회원가입 | 2. 로그인 | 3. 회원정보");
			menuNum = sc.nextInt();
			switch (menuNum) {
			case 1: // 회원가입
				ls.creatAccount();
				break;
			case 2: // 로그인
				ls.loginAccount();
				break;
			case 3: // 회원 정보
				ls.information();
				break;
			default:
				System.out.println(" 메뉴 확인 ");
				break;
			}
//			bm.menu();
		} while (true);
	}

	public static void main(String[] args) {
		Start s = new Start();
		s.start();
	}
}
