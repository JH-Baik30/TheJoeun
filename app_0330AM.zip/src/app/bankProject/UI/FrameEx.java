// 선생님 주신 코드 0313
package app.bankProject.UI;

import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class FrameEx extends Frame{
	public Panel p1, p2, p3, p4;
	public FrameEx() {
		p1 = new Panel(); p2 = new Panel(); p3 = new Panel(); p4 = new Panel();
		
		// 좌측
//		p1.add(new Label("West"));

		// textarea 넣을 패널
		p3.add(new Label("Center"));
		
		// 우측패널
		p2.add(new Label("East"));
		
		// 하단 패널 (로그인 종료)
		p4.add(new Label("South"));
		
		// 좌측 패널
		p1.setLayout(new GridLayout(3, 1));		
		p1.add(new TextField("1", 20));
		p1.add(new TextField("2", 10));
		p1.add(new TextField("3", 10));
		add(p1, "West");				// 보더레이아웃
		add(p2, "East");				// 보더레이아웃
		add(p3, "Center");				// 보더레이아웃
		add(p4, "South");				// 보더레이아웃
		setSize(300, 300);
		setVisible(true);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}			
		});
	}
	public static void main(String args[]) {
		new FrameEx();
	}
}
