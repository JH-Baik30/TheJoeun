// 1-2
package app.ch17_0313;

public class TargetThread extends Thread{
	public void run() {
		for(long i=0; i<1_000_000_000; i++) {
			for (long j = 0; j < 1_000_000_000; j++) {
			}
		}
		
		try {
			//1.5초간 일시정지
			Thread.sleep(1500);
		} catch (Exception e) {	}
		
		for(long i=0; i<1_000_000_000; i++) {
			for (long j = 0; j < 1_000_000_000; j++) {
			}
		}
	}
}
