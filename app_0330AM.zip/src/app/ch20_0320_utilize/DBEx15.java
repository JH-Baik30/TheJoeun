package app.ch20_0320_utilize;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Iterator;
import java.util.Scanner;

/*
 *  - DEFAULT
 *  default 제약 조건은 해당 필드의 기본값을 설정할 수 있게 해줍니다.
 *  만약 레코드를 입력할 때 해당 필드 값을 전달하지 않으면,
 *  자동으로 설정된 기본값을 저장합니다.
 *  [데이블 생성]
 *  	CREATE TABLE TEST6(
 *  		ID		VARCHAR(10),
 *  		PW		VARCHAR(30),
 *  		NAME		VARCHAR(30) DEFAULT 'Anonymous',
 *  		MDate	DATE,
 *  		AGE		INT
 *  	);
 */
public class DBEx15 {
	public static void main(String[] args) {
		Connection conn = DBAction.getInstance().getConnection();
		Statement stmt = null;
		ResultSet rs = null;
	
		try {
			stmt = conn.createStatement();
//			String sql = createTable();			// create table
//			String sql = insert();				// add member
//			String sql = delete();
//			stmt.executeUpdate(sql);

//			출력 결과확인
			String sql = select();
			rs = stmt.executeQuery(sql);
			ResultSetMetaData rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			while (rs.next()) {
				for (int i = 1; i <= cols; i++) {
					System.out.print(rs.getString(i) + "\t");
				}
				System.out.println();
			}
		
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	
	/**
	 * TABLE CREATE
	 * @return sql
	 */
	
	public static String createTable() {
		String sql = "CREATE TABLE TEST6("
				+ " ID		VARCHAR(10),"
				+ " PW		VARCHAR(30),"
				+ " NAME		VARCHAR(30) DEFAULT 'Anonymous',"
				+ " MDate	DATE,"
				+ " AGE		INT)";
		return sql;
	}
	
	public static String insert() {
/*
		Scanner scan = new Scanner(System.in);
*/
		String sql = "INSERT INTO TEST6(ID, PW, MDate, AGE) "
				   + "VALUES('ABC', '123', '2023-03-20', 10)";
		return sql;
	}
	
	public static String select() {
		String sql = "SELECT * FROM TEST6";
		return sql;
	}
}
