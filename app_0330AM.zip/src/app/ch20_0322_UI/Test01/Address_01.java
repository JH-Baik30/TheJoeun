package app.ch20_0322_UI.Test01;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Component;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JComboBox;

public class Address_01 extends Frame{
	AddressDBContact adbc = new AddressDBContact();
	public Panel p1, p2, p3, p4;
	Label sidoLb, gugunLb, jusoLb;
	static JComboBox<String> sidoCb, gugunCb = null;
	static ArrayList<String> sido=null, gugun = null; 
	TextField sidoTf, gugunTf, jusoTf;
	Button searchBt, cancelBt, saveBt;
	String gugu = null;
	public Address_01 () {
		sido = adbc.getsido();
		p1 = new Panel(); p2 = new Panel(); p3 = new Panel(); p4 = new Panel();
		sidoLb = new Label("sido"); gugunLb = new Label("gungu"); jusoLb = new Label("juso");
		sidoCb = new JComboBox<String>(sido.toArray(new String[sido.size()]));
//		gugunCb = new JComboBox<String>(gugun.toArray(new String[gugun.size()]));
		p2.setLayout(new GridLayout(2,1));
		p2.add(sidoLb);		p2.add(jusoLb);
		p3.setLayout(new GridLayout(1,2));
		p3.add(sidoCb);		p3.add(gugunCb);
		
		add(p1, BorderLayout.NORTH);
		add(p2, BorderLayout.WEST);
		add(p3, BorderLayout.CENTER);
		add(p4, BorderLayout.EAST);
		setTitle("주소검색");
		setSize(300, 300);
		setVisible(true);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
				try {	adbc.closeDB();
				} catch (SQLException e1) {
					e1.printStackTrace();	}	}
		});
		
		sidoCb.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String gugu = (String) sidoCb.getSelectedItem();
//				System.out.println(gugu);
//				for (String string : adbc.getGugun(gugu)) {
//					gugunCb.add(string);
//					
//				}
				
			}
		});
	}
	public static void main(String[] args) {
		new Address_01();
	}
}
