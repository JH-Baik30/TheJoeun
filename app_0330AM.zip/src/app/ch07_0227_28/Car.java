package app.ch07_0227_28;

public class Car {
	//Field
	String color;
	String company;
	String type;
	
	//Method
	public void go() {
		System.out.println("전진하다");
	}
	public void back() {
		System.out.println("후진하다");
	}
}
