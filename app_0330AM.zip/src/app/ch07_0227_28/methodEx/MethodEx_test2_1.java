package app.ch07_0227_28.methodEx;

public class MethodEx_test2_1 {

}
