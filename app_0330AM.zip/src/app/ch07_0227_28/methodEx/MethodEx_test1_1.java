package app.ch07_0227_28.methodEx;

import java.util.Scanner;
// 응용 1 : 지정 범위의 구구단 출력
public class MethodEx_test1_1 {
	public static void method(int dan1, int dan2) {
		for (int i = dan1; i <= dan2; i++) {
			for (int j = 1; j < 9+1; j++) {
				System.out.println(i + " * " + j + " = " + i*j);
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		System.out.print("시작할 단을 입력하세요 : ");
		int dan1 = new Scanner(System.in).nextInt();
		System.out.print("몇 단까지 할까요 : ");
		int dan2 = new Scanner(System.in).nextInt();
		method(dan1, dan2);
	}
}
