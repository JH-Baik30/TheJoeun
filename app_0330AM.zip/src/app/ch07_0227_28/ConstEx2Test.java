package app.ch07_0227_28;

public class ConstEx2Test {
	ConstEx2Test() {
		this(10, "A");
	}
	ConstEx2Test(int a) {
		this(50, "B");
	}
	ConstEx2Test(int a, String b) {
		System.out.println(a);
		System.out.println(b);
	}
	
	public static void main(String[] args) {
		ConstEx2Test obj = new ConstEx2Test();
		System.out.println();
		ConstEx2Test obj1 = new ConstEx2Test(75);
		System.out.println();
		ConstEx2Test obj2 = new ConstEx2Test(100, "C");
		
	}
}
