package app.ch19_0314.jaehui;

import java.awt.BorderLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ChatClient extends JFrame implements Runnable, ActionListener {

	private BufferedReader i;
	private PrintWriter o;
	private JTextArea output;
	private JTextField input;
	private JLabel label;
	private Thread listener;
	private String host;
	private JScrollPane scroll;
	public ChatClient(String server) {
		super("채팅");
		host = server;
		listener = new Thread(this);
		input = new JTextField();
		output = new JTextArea();
		label = new JLabel("사용자");
		scroll = new JScrollPane(output);
		listener.start();
		output.setEditable(false);

		input.addActionListener(this);

		add(scroll, "Center");
		Panel bottom = new Panel(new BorderLayout());

		bottom.add(label, "West");
		bottom.add(input, "Center");
		add(bottom, "South");

		setSize(400, 300);
		setVisible(true);

	}

	public void run() {
		try {
			Socket s = new Socket(host, 7979);
			InputStream ins = s.getInputStream();
			OutputStream os = s.getOutputStream();
			i = new BufferedReader(new InputStreamReader(ins));
			o = new PrintWriter(new OutputStreamWriter(os), true);
			while (true) {
				String line = i.readLine();
				output.append(line + "\n");
				scroll.getVerticalScrollBar().setValue(scroll.getVerticalScrollBar().getMaximum());
				
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}

	public static void main(String[] args) {
		if (args.length > 0) {
			new ChatClient(args[0]);
		} else {
			new ChatClient("localhost");
//			new ChatClient("192.168.20.7");
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object c = e.getSource();
		if (c == input) {
			label.setText("메시지");
			o.println(input.getText());
			input.setText("");
		}

	}

}

/*
 * 스크롤바 핸들링 X
 * 이름공백없애기 
 * 사용자 리스트 출력
 */
