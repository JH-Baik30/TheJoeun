package test.classEx.ch07.sec10.exam02;

public class Dog extends Animal {

	@Override
	public void sound() {
		System.out.println("멍멍");
	}

}
