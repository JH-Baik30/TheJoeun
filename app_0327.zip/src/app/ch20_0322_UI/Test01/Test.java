package app.ch20_0322_UI.Test01;

import java.util.ArrayList;

public class Test {
	public static void main(String[] args) {
		ArrayList<String> str = new ArrayList<>();
		
		str.add("1111");
		str.add("2222");
		str.add("3333");
		str.add("4444");
		
		for (String string : str) {
			System.out.println(string);
		}
	}
}
