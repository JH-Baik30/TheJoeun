package app.ch20_0322_UI;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class AddressDBContact {
	ArrayList<String> arr = new ArrayList<>();
	Connection conn = DBAction.getInstance().getConnection();
	Statement stmt = null;
	ResultSet rs = null;
	ResultSetMetaData rsmd = null;
	
	public ArrayList<String> sidoDB (){
		try {
			String sql = getsido();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			arr.add("  ");
			while (rs.next()) {
				for (int i = 1; i <= cols; i++) {
					arr.add(rs.getString(i));
				}
			}
			return arr;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs !=  null) rs.close();
				if (stmt != null) stmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return null;
	}
	
	public static String getsido() {
		String sql = "SELECT DISTINCT sido FROM ZIPCODE";
		return sql;
	}
	
	public void closeDB() throws SQLException {
		if(conn != null) conn.close();
		System.out.println("종료");
	}
	
	

	
	
}
