package app.bankProject.ver5_UI2;
//package app.bankProject.ver6_UI;
//
//import java.awt.CardLayout;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//import javax.swing.JButton;
//import javax.swing.JFrame;
//import javax.swing.JPanel;
//
//public class CardLayOut extends JFrame implements ActionListener{
//	private JPanel contentPane;
//    private JButton b1;
//    private JButton b2;
//    JPanel panel;
////    View1 v1 = new View1();
////    View2 v2 = new View2();
//    CardLayout card = new CardLayout();
//
//    
//    
//    
//    
//    
//    
//    
//    
//    
//    
//    
//    
//    
//    
//    
//	
//	@Override
//	public void actionPerformed(ActionEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//	public static void main(String[] args) {
//		new CardLayOut();
//	}
//	
//	public CardLayOut() {
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		contentPane = new JPanel();
//		contentPane.setLayout(null);
//		
//		panel = new JPanel();
//		panel.add("view1", v1);  //화면에 이름붙임.
//		panel.add("view2", v2);
//	    card.show(panel, "view2");
//	}
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//
//}
