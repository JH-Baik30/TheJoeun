package app.bankProject.DBBase;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class BankDbCreate {
	public static void main(String[] args) throws IOException {
		Scanner scan = new Scanner(System.in);
		BankDbCreate create = new BankDbCreate();
		System.out.println("BankDB Creater");
		System.out.println("생성할 테이블을 선택하시오.");
		System.out.println("PK table 은 1번, FK table 은 2번");
		System.out.print(">>>>   ");
		int cho = scan.nextInt();
		switch (cho) {
		case 1:
            create.createPkTable();
			break;
		case 2:
            create.createfkTable();
			break;
		default:
			break;
		}
	}
	
	public void DBcreater(String sql) {
		Connection conn = DBAction.getInstance().getConnection();
		Statement stmt = null;
		
		try {
			stmt = conn.createStatement();
//			String sql = createTable();
			System.out.println(1);
			int result = stmt.executeUpdate(sql);
			String msg = result > -1 ? "성공" : "실패";
			System.out.println("DB Create Success");
		} catch (Exception e) {
			System.out.println("Connect Fail!!!!!!!");
		} finally {
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
				
			} catch (Exception e2) {	}
		}
	}
	
	public String createPkTable() {
		String sql = "CREATE TABLE BANKDB("
					+ "ACCOUNT INTEGER PRIMARY KEY, "
					+ "ID VARCHAR(10) UNIQUE, "
					+ "PW VARCHAR(10) NOT NULL, "
					+ "NAME VARCHAR(5) NOT NULL, "
					+ "BALANCE INTEGER DEFAULT 0, "
					+ "CREATE_DATE DATETIME + "
					+ "BIRTH_DAY DATE)"; 
		DBcreater(sql);
		return "pktable 생성";
	}
	
	public String createfkTable() {
		String sql = "CREATE TABLE TransactionDB ("
					+ "ACCOUNT INT NOT NULL, "
					+ "WITH_DRAW INT NULL DEFAULT 0, "
					+ "DEPOSIT INT NULL DEFAULT 0, "
					+ "transfer INT NULL DEFAULT 0, "
					+ "PRIMARY KEY (`ACCOUNT`), "
					+ "CONSTRAINT `ACCOUNT` FOREIGN KEY (`ACCOUNT`) "
					+ "REFERENCES bankdb (ACCOUNT) ON DELETE NO ACTION ON UPDATE NO ACTION)";
		DBcreater(sql);
		return "fktable 생성";
	}
}
