package app.bankProject.ver2;
// 정현도움!!!!
public class Member {
	
	String name;
	String account;
	String pw;
	int balance = 0;
	
	public Member(String pw, String account) {
		this.account = account;
		this.pw = pw;
	}
	
	public String getName() 		{	return name;		}
	public void setName(String name){	this.name = name;	}
	public String getAccount() 			{	return account;			}
	public String getPw() 			{	return pw;			}
	public void setPw(String pw) 	{	this.pw = pw;		}
	
	public void name(String name) {
		setName(name);
		System.out.println(getName() + " 님의 아이디는 " + getAccount() + " 입니다.");
	}
	
	// 패스워드 설정 메소드
	public void pw(String pw) {
		setPw(pw);
		System.out.println("패스워드는 " + getPw() + " 로 설정 되었습니다.");
	}	
	
	// 입금 메소드
	public void deposit(int deposit) {
		balance += deposit;
		System.out.println(deposit + " 원이 입급되었습니다.");
		balance();
	}
	
	public void withDraw(int withDraw) {
		balance -= withDraw;
		System.out.println(withDraw + " 원이 출금되었습니다.");
		balance();
	}
	
	public void balance() {
		System.out.println("현재 예금액은 " + balance + " 원입니다.");		
	}
}
