package app.ch20_0315_17;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class DBEx9_1 {
	public static void main(String[] args) throws IOException {
		Properties properties = new Properties();
		properties.load(DBEx5_EX6use.class.getResourceAsStream("database.properties"));
		String driver = properties.getProperty("driver");
		String url = properties.getProperty("url");
		String id = properties.getProperty("username");
		String pw = properties.getProperty("password");
		Connection conn = null;		//
		Statement stmt = null;		// 상태
		ResultSet rs = null;		// 추출한 데이터를 담을 set 컬렉션
		
		try {
			Class.forName(driver);
			System.out.println("loading OK!");
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("connect OK!");
			stmt = conn.createStatement();
			
			String sql = select();
			rs = stmt.executeQuery(sql);
			ArrayList<DBTest> data = new ArrayList<>();				// 1.
			System.out.println(rs);
			while (rs.next()) {
//				data.add(new DBTest().setId(rs.getString("ID")));	// 부터
/*				data.add(new DBTest().setId(rs.getString("ID"))
						.setPw(rs.getString("pw"))
						.setAge(rs.getInt("age"))
						.setCre_date(rs.getTimestamp("CRE_DATE")));
						.setCre_date(rs.getTimestamp("cre_date")));	// 까지 1에 담는다.
*/				
				DBTest dbTest = new DBTest();						// DBTest 객체 생성
				dbTest.setId(rs.getString("ID"));
				dbTest.setPw(rs.getString("PW"));
				dbTest.setAge(rs.getInt("AGE"));
				dbTest.setCre_date(rs.getTimestamp("CRE_DATE"));
				System.out.print(dbTest.getId() + "\t");
				System.out.print(dbTest.getPw() + "\t");
				System.out.print(dbTest.getAge() + "\t");
				System.out.println(dbTest.getCre_date());
				
			}
			/*
			if(rs.next()) {
				data.add(new DBTest().setId(rs.getString("ID"))
									 .setPw(rs.getString("PW")));
			}
			*/
			Iterator<DBTest> result = data.iterator();
			
			while (result.hasNext()) {
				DBTest userinfo = result.next();
				/*System.out.println(userinfo.getId());
				System.out.println(userinfo.getPw());*/
				System.out.println(
						userinfo.getId() + ", " +
						userinfo.getPw() + ", " +
						userinfo.getAge() + ", " + 
						userinfo.getCre_date());
			}
			/*
			if (rs.next()) {
				DBTest userinfo = result.next();
				System.out.println(userinfo.getId());
				System.out.println(userinfo.getPw());
			}*/
						
		} catch (Exception e) {
			System.out.println("연결 실패!!!!");
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	/**
	 * SELECT
	 * @return SQL
	 */
	public static String select() {
//		String sql = "SELECT ID FROM DBTEST3";
		String sql = "SELECT * FROM DBTEST3 ";//WHERE ID='abc'";
		
		return sql;
	}
}

class DBTest{
	private String id;
	private String pw;
	private int age;
	private Timestamp cre_date;
	
	public String getId()		 	{	return id;		}
	public String getPw()			{	return pw;		}
	public int getAge() 			{	return age;		}
	public Timestamp getCre_date()	{	return cre_date;}
	
	public DBTest setId(String id)	{	this.id = id;	return this;		}
	public DBTest setPw(String pw)	{	this.pw = pw;	return this;		}
	public DBTest setAge(int age) 	{	this.age = age;	return this;		}
	public DBTest setCre_date(Timestamp cre_date) {	this.cre_date = cre_date;	return this;}
	
}



