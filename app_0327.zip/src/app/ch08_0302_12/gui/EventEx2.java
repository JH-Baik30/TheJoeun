package app.ch08_0302_12.gui;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Scrollbar;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class EventEx2 extends JFrame implements AdjustmentListener {
	public Scrollbar sb_r, sb_g, sb_b;
	public EventEx2() {
		JPanel p = new JPanel();
		p.setLayout(new GridLayout(3, 1));
		
		sb_r = new Scrollbar( 0, 0, 10, 0, 265);
		sb_g = new Scrollbar( 0, 0, 10, 0, 265);
		sb_b = new Scrollbar( 0, 0, 10, 0, 265);
		p.add(sb_r);
		p.add(sb_g);
		p.add(sb_b);
		add(p);
		setSize(300, 300);
		setVisible(true);
		sb_r.addAdjustmentListener(this);
		sb_g.addAdjustmentListener(this);
		sb_b.addAdjustmentListener(this);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	@Override
	public void adjustmentValueChanged(AdjustmentEvent e) {
		Color color = new Color(sb_r.getValue(), sb_g.getValue(), sb_b.getValue());
		
		System.out.println(sb_r.getValue());
		System.out.println(sb_g.getValue());
		System.out.println(sb_b.getValue());
	}
	
	public static void main(String[] args) {
		new EventEx2();
	}


}
