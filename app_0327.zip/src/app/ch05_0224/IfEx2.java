package app.ch05_0224;

import java.util.Scanner;

public class IfEx2 {
	public static void main(String[] args) {
		/*
		 * int score = 70; score = 85; score = 95; if (score > 50 && score < 81) {
		 * System.out.println("실행 구문 1"); } else if (score < 91) {
		 * System.out.println("실행 구문 2"); } else if (score < 100) {
		 * System.out.println("실행 구문 3"); }
		 */

		// Ex

		System.out.print("점수를 입력하세요 : ");
		int score1;
		score1 = new Scanner(System.in).nextInt();
		if (score1 <= 100 && score1 > 80) {
			System.out.println("A");
		} else if (score1 <= 80 && score1 > 60) {
			System.out.println("B");
		} else if (score1 >= 0) {
			System.out.println("C");
		}

	}
}
