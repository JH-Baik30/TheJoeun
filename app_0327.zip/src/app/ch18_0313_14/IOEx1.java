// 1-1 stream node 기본 stream의 불편성
package app.ch18_0313_14;

import java.io.IOException;

public class IOEx1 {
	public static void main(String[] args) {
		System.out.println("입력 : ");
		char c = ' ';
			try {
				c = (char) System.in.read();
			} catch (IOException e) {
				e.printStackTrace();
			}
		System.out.println("출력 : " + c);
	}
}
