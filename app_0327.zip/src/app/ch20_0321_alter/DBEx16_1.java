package app.ch20_0321_alter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * ALTER 문
 * 	- TABLE 변경
 * 	[테이블 생성] : ATTEST
 * 	CREATE TABLE ATTEST(ID VARCHAER (10) NOT NULL, PW VARCHAR(10));
 * 	실습1) 테이블에 새로운 컬럼 추가
 */
public class DBEx16_1 {
	public static void main(String[] args) {
		Connection conn = DBAction.getInstance().getConnection();
//		PreparedStatement pstmt = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			String sql = alter();
			stmt = conn.createStatement();
			int result = stmt.executeUpdate(sql);
			String msg = result > -1 ? "성공" : "실패";
			System.out.println(msg);
		} catch (SQLException e) { e.printStackTrace();	}
		finally {
			try {
				if(rs != null) rs.close();
//				if(rstmt != null) rstmt.close();
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	public static String alter() {
//		ex1)
		String sql = "ALTER TABLE TEST5 ADD COLUMN AGE VARCHAR(10) NOT NULL";
		return sql;
	}
	
}
