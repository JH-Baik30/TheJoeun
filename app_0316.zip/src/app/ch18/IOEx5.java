package app.ch18;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class IOEx5 {
	public static void main(String[] args) {
		File file = new File("G:/work/file/IO.txt");
		FileInputStream fis;
		int readByte;
		
		try {
			fis = new FileInputStream(file);
			while (true) {
				readByte = fis.read();
				if(readByte == -1) {
					break;
				}
				System.out.print((char)readByte);
			}
			fis.close();				// 열었으면 닫아줘야한다.
		} catch (IOException e) {
			e.printStackTrace();
			
			
		}
		
	}
	
}
