// 1-2 stream node
package app.ch18;

import java.io.IOException;

public class IOEx2 {
	public static void main(String[] args) {
		int b = 0;
		try {
			System.out.println("입력 : ");
			b = System.in.read();
			while(b != -1) {				// -1 은 ctrl + z
				System.out.print((char) b);
				b=System.in.read();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("종료");
	}
}
