// 1-3 stream node 배열에 캐릭터를 하나씩 담아서 보냄 (드럽게 불편함)
package app.ch18;

import java.io.IOException;

public class IOEx3 {
	public static void main(String[] args) {
		byte b[] = new byte[5];				//문자 배열공간 확보
		System.out.println("입력 : ");
		char c = ' ';
		
		try {
			System.in.read(b, 0, 5);
//			String str = new String(b);		//쪼개진 바이트 배열가지고 문자열 생성
//			System.out.println("문자열 활용 " + str);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("출력 : ");
		System.out.write(b, 0, 5);
		
	}
}
