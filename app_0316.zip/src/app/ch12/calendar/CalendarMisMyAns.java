// 내가 작성한 코드

// 날자의 시작점이 다르다.
package app.ch12.calendar;
// getActualMaximum
// set method 를 이용하자.
// 구구단 수준

import java.util.Calendar;
import java.util.Scanner;

// cal.set(year, month, date); // 원하는 년, 월, 일 설정
// int date = Calendar.DAY_OF_WEEK // 월 시작 일 (DAY_OF_WEEK)
// getActualMinimum​(int field) // field 최대 일(DATE)
public class CalendarMisMyAns {
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		Scanner scan = new Scanner(System.in);

		// 입력받기
		System.out.print("연도는 입력하세요 : ");
		int year = Integer.parseInt(scan.next());
//		int year = scan.nextInt();
		System.out.print("월을 입력하세요 : ");
//		int mon = Integer.parseInt(scan.next());		
		int mon = scan.nextInt();		
//		cal.set(Calendar.YEAR, 2023);
//		cal.set(Calendar.MONTH, Calendar.MARCH);
		cal.set(year, mon-1, 1);
		System.out.println("" + year + "년 " +  mon + "월 ");
//		System.out.println("	" + 2023 + "년 " +  03 + "월 ");
		System.out.println();
		String[] days = { "일", "월", "화", "수", "목", "금", "토" };
		for (String day : days) {
			System.out.print(day + "\t");
		}
		System.out.println();
		
		// 시작 일자
		int startDay = cal.get(Calendar.DAY_OF_WEEK);
		int endDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		int week = endDay / 7;
		
		// 해당월 1일의 요일 숫자로 가져옴
//		System.out.println("startDay: " + startDay);
		// 매월 1일 요일의 시작앞에 tab
		for (int i = 1; i < endDay + startDay; i++) {
			if (i < startDay) {
			System.out.print("\t");
			} else {
			System.out.print((i - startDay + 1) + "\t");}
			if (i % 7 == 0) {
				System.out.println();
			}
		}
	}
}
