package app.ch12.calendar;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/*
 * Calender class는 1970년 1월 1일부터 특정 값으로 진보해 오면서
 * 날짜와 시각에 대한 조작을 수행할 수 있도록 제공되는 abstract class이다.
 * object 생성 법은 다음과 같다.
 * 	1) Calendar cal = Calendar.getInstance(); 
 *	2) GregroianCalnder ca1 -= new GregorianCalendar();
*/

public class CalendarEx {
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		int month = (cal.get(Calendar.MONTH) + 1);
		int date = cal.get(Calendar.DATE);
		System.out.println("년 : " + year);
		System.out.println("월 : " + month);
		System.out.println("일 : " + date);

		System.out.println(year + "년" + month + "월" + date + "일");
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd hh:mm:ss E a");
		System.out.println(sdf.format(now));

		int day1 = cal.get(Calendar.DAY_OF_YEAR);	// 오늘까지 날짜
		int day2 = cal.get(Calendar.DAY_OF_MONTH);	// 이번달 오늘 날짜
		int day3 = cal.get(Calendar.DAY_OF_WEEK);	// 오늘 요일
		int week = cal.get(Calendar.WEEK_OF_YEAR);	// 올해의 이번 주

		System.out.println("오늘은 올해의 : " + day1 + "날입니다.");
		System.out.println("오늘은 이번달의 : " + day2 + "일일니다.");
		String[] day = { "일", "월", "화", "수", "목", "금", "토" };
		System.out.println("오늘은 이번주의 : " + day[day3 - 1] + "요일입니다.");
		System.out.println("오늘은 올해의 : " + week + "주입니다.\n");

	}

}
