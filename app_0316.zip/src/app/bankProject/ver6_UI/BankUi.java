package app.bankProject.ver6_UI;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import app.bankProject.ver4.CreateAccMenu2;

public class BankUi extends JFrame implements ActionListener{
	Toolkit toolkit = Toolkit.getDefaultToolkit();
//	Menu menu = new Menu();
	public JPanel jp1, jp2, jp3, jp4;
	public JButton bt1, bt2, bt3, bt4, bt5, bt6, btLogIn, btExit;
	public JTextArea ta;
	public JLabel label;
	public JTextField tf;
	int pWidth = 500, pHeight = 300;
	public BankUi() {
		jp1 = new JPanel();	// west
		jp2 = new JPanel();	// center
		jp3 = new JPanel(new BorderLayout()); 	// east
		jp4 = new JPanel(new FlowLayout()); 	// south
		
		bt1 = new JButton("입  금");
		bt2 = new JButton("출  금");
		bt3 = new JButton("예금조회");
		jp1.setLayout(new GridLayout(3, 1));
		jp1.add(bt1);	jp1.add(bt2);	jp1.add(bt3);
//		
		jp2.setLayout(new BorderLayout());
//		label = new JLabel();
		tf = new JTextField();
		tf.setEditable(false);
		ta = new JTextArea("<< 안녕하세요 >>" + "\n" +"<< 당신의 이웃 당이 은행입니다~");
		ta.setEditable(false);
		jp2.add(tf, BorderLayout.NORTH); jp2.add(ta, BorderLayout.CENTER);
		
		
		
		bt4 = new JButton("계좌 이체");
		bt5 = new JButton("공 사 중");
		bt6 = new JButton("계좌 개설");
		jp3.setLayout(new GridLayout(3, 1));
		jp3.add(bt4);	jp3.add(bt5);	jp3.add(bt6);
		
		btLogIn = new JButton("로 그 인");
		btExit = new JButton("종   료");
		jp4.setLayout(new GridLayout(1, 4));

		JLabel imgLabel = new JLabel(), imgLabel2 = new JLabel();
		ImageIcon icon = new ImageIcon(BankUi.class.getResource("bank-transfer.png"));
		Image img = icon.getImage();
		Image updateImg = img.getScaledInstance(100, 60, Image.SCALE_SMOOTH);
		ImageIcon updateIcon = new ImageIcon(updateImg);
		ImageIcon updateIcon2 = updateIcon;
		imgLabel.setIcon(updateIcon);
		imgLabel2.setIcon(updateIcon2);
		imgLabel.setBounds(20, 220, 180, 100);
		imgLabel.setBounds(20, 220, 180, 100);
		imgLabel2.setBounds(370, 220, 180, 100);
		jp4.add(imgLabel);
		jp4.add(btLogIn); jp4.add(btExit);
		jp4.add(imgLabel2);
		
		add(jp1, "West");		//왼쪽
		add(jp2, "Center");		//중앙
		add(jp3, "East");		//오른쪽
		add(jp4, "South");		//아래
		
		setSize(pWidth, pHeight);
		setVisible(true);
		
		tf.addActionListener(this);
		bt1.addActionListener(this);
		bt2.addActionListener(this);
		bt3.addActionListener(this);
		bt4.addActionListener(this);
		bt5.addActionListener(this);
		bt6.addActionListener(this);
		btExit.addActionListener(this);
		btLogIn.addActionListener(this);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		Object obj = e.getSource();
		if (obj == bt1) {
			toolkit.beep();			
			ta.setText(" << 입금을 선택하셨습니다. >>");
			
		} else if (obj == bt2) {
			toolkit.beep();
			ta.setText(" << 출금을 선택하셨습니다. >>");
			
		} else if (obj == bt3) {
			toolkit.beep();
			ta.setText(" << 조회를 선택하셨습니다. >>");
		} else if (obj == bt4) {
			toolkit.beep();
			ta.setText(" << 계좌이체를 선택하셨습니다. >>");
		} else if (obj == bt5) {
			toolkit.beep();
			ta.setText(" << 서비스 준비중 >>");
			
		} else if (obj == bt6) {
			toolkit.beep();
			ta.setText(" << 계좌 개설을 선택하셨습니다. >>");
//			menu.creatAccount();
		}
		
	}

	public void time() {
		Thread thread = new Thread();
		while (true) {
			try {
				Date now = new Date();
//				SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd hh:mm:ss E a");
//				System.out.println(sdf.format(now));
//				String td = sdf;
				label.setText(now.toString());
				thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public String nowTime() {
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd hh:mm:ss E a");
		tf.setText(now.toString());
		return null;
	}
	
	
	public static void main(String[] args) {
//		Thread t = new Thread();
		new BankUi();
//		t.start();
	}

//	@Override
//	public void run() {
//		while (true) {
//			Date now = new Date();
//			tf.setText(now.toString());
//			System.out.println(now.toString());
//			try {
//				Thread.sleep(1000);
//			} catch (Exception e) {
//			}
//		}
//	}
}



//public static void time() {
//	Date now = new Date();
//	Thread timeThread = new Thread(()-> {
//		SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd hh:mm:ss E a");
//		sdf.format(now);
//		try {
//			Thread.sleep(1000);
//		} catch (Exception e) {
//		}
//	});
//	timeThread.start();
//}