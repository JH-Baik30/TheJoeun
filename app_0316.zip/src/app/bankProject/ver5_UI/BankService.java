package app.bankProject.ver5_UI;

public class BankService {
	public static void main(String[] args) {
		Menu bankGo = new Menu();
		try {
			bankGo.logInMenu();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
