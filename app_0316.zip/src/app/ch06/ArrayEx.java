package app.ch06;

import java.util.Scanner;

public class ArrayEx {
	public static void main(String[] args) {

		int dan[][] = new int[9][8];
		for (int i = 0; i < dan.length; i++) {
			for (int j = 0; j < dan[i].length; j++) { 
				dan[i][j] = (j + 2) * (i + 1);
			} 
		}
		
		for (int i = 0; i < dan.length; i++) {
			for (int j = 0; j < dan[i].length; j++) {
				System.out.print(dan[i][j] + "\t");
			} 
			System.out.println();
		}
		  
		/*  
		int[] score = new int[3];
		for (int i = 0; i < score.length; i++) {
			System.out.print("점수를 입력하세요. : ");
			score[i] = new Scanner(System.in).nextInt();
		}

		int sum = 0;
		for (int i : score) {
			sum += i;
		}
		int avg = sum / score.length;

		System.out.println();
		System.out.println("총합 : " + sum);
		System.out.println("평균 : " + avg);

		if (avg >= 90) {
			System.out.println("A학점");
		} else if (avg >= 80) {
			System.out.println("B학점");
		} else if (avg >= 70) {
			System.out.println("C학점");
		} else if (avg >= 60) {
			System.out.println("D학점");
		} else if (avg < 60) {
			System.out.println("끝나고 남아!!!!");
		}

		System.out.println();
		int 학점 = avg / 10;
		switch (학점) {
			case 9:
				System.out.println("A학점");
				break;
			case 8:
				System.out.println("B학점");
				break;
			case 7:
				System.out.println("C학점");
				break;
			case 6:
				System.out.println("D학점");
				break;
			case 5:
			case 4:
			case 3:
			case 2:
			case 1:
				System.out.println("끝나고 남아!!!!");
				break;
		}*/

//		int[] arr1 = {1, 2, 3};
//		int arr2[3];
//		int[] arr3 = new int[3];
//		int arr4[3] = new int[3];

	}
}
