package app.ch03;

public class IdentifiersEx {
	public static void main(String[] args) {
		int colorPen = 5 * 12;
		int studentCount = 27;
		int divColorPen = colorPen / studentCount;
		System.out.println(divColorPen);
		int remainColorPen = colorPen % studentCount;
		System.out.println(remainColorPen);
		
	}
}
