package app.ch03;

public class JavaTest {
	public static void main(String[] args) {
		System.out.println("자바테스트");
	}
}
