package test.uitest;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MultiPanelDemo implements ActionListener {
    private JFrame frame;
    private JPanel cardPanel;
    private JPanel panel1;
    private JPanel panel2;
    private JPanel panel3;

    public static void main(String[] args) {
        MultiPanelDemo demo = new MultiPanelDemo();
        demo.createGUI();
    }

    private void createGUI() {
        frame = new JFrame("MultiPanel Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 카드 레이아웃을 사용하는 JPanel 생성
        cardPanel = new JPanel(new CardLayout());

        // 첫번째 패널 생성
        panel1 = new JPanel();
        JButton button1 = new JButton("Panel 1 Button");
        button1.addActionListener(this);
        panel1.add(button1);

        // 두번째 패널 생성
        panel2 = new JPanel();
        JButton button2 = new JButton("Panel 2 Button");
        button2.addActionListener(this);
        panel2.add(button2);

        // 세번째 패널 생성
        panel3 = new JPanel();
        JButton button3 = new JButton("Panel 3 Button");
        button3.addActionListener(this);
        panel3.add(button3);

        // 카드 패널에 각 패널을 추가
        cardPanel.add(panel1, "Panel 1");
        cardPanel.add(panel2, "Panel 2");
        cardPanel.add(panel3, "Panel 3");

        // 프레임에 카드 패널 추가
        frame.getContentPane().add(cardPanel);

        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // 클릭한 버튼의 텍스트를 가져옴
        String buttonName = e.getActionCommand();

        // 카드 레이아웃의 다음 패널을 보여줌
        CardLayout cardLayout = (CardLayout) cardPanel.getLayout();
        switch (buttonName) {
            case "Panel 1 Button":
                cardLayout.show(cardPanel, "Panel 2");
                break;
            case "Panel 2 Button":
                cardLayout.show(cardPanel, "Panel 3");
                break;
            case "Panel 3 Button":
                cardLayout.show(cardPanel, "Panel 1");
                break;
            default:
                break;
        }
    }
}