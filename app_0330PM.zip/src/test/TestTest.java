package test;

import java.util.regex.Pattern;

public class TestTest {
	public static void main(String[] args) {
//		String regExp = "(02|010)-\\d{3,4}-\\d{4}";
//		String data = "010-1234-4567";
//		boolean result = Pattern.matches(regExp, data);
//		if (result) {
//			System.out.println("일치합니다.");
//		} else {
//			System.out.println("일치하지 않습니다.");		
//		}
//
//		regExp = "\\w+@\\w+\\.(com|co.kr)";
//		data = "angel@naver.co.kr";
//		result = Pattern.matches(regExp, data);
//		if (result) {
//			System.out.println("일치합니다.");
//		} else {
//			System.out.println("일치하지 않습니다.");		
//		}
		
//		char[] abc = {'p', 'a', 's', 's', 'w', 'o', 'r', 'd'};
//		System.out.println(String.valueOf(abc));
		
//		String da = "19931231";
//		SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
//		System.out.println(sd.format(da));
		
//		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
//		String sample = "19931231";
//		LocalDate date = LocalDate.parse(sample, DateTimeFormatter.ofPattern("yyyyMMdd"));
//		System.out.println(date);
		
		
		regexMobile("010-1234-1234", "asdf@asdf.com");
	}
	
	public static boolean regexMobile(String mobile, String email) {
		String regExpM = "(02|010)-\\d{3,4}-\\d{4}";
		String regExpE = "\\w+@\\w+\\.(com|co.kr|net|kr)";
//			boolean result;
		if (Pattern.matches(regExpM, mobile)) {
			if (Pattern.matches(regExpE, email)) {
				System.out.println(1);
				return true;
			}
		} return false;
	}
	
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
