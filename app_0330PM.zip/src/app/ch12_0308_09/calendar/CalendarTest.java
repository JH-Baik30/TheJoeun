// 연습 자료

package app.ch12_0308_09.calendar;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/*
 * Calender class는 1970년 1월 1일부터 특정 값으로 진보해 오면서
 * 날짜와 시각에 대한 조작을 수행할 수 있도록 제공되는 abstract class이다.
 * object 생성 법은 다음과 같다.
 * 	1) Calendar cal = Calendar.getInstance(); 
 *	2) GregroianCalnder ca1 -= new GregorianCalendar();
*/

public class CalendarTest {
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		int month = (cal.get(Calendar.MONTH)+1);
		int date = cal.get(Calendar.DATE);
		System.out.println("년 : " + year);
		System.out.println("월 : " + month);
		System.out.println("일 : " + date);
		
		System.out.println(year + "년" + month + "월" + date + "일");
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd hh:mm:ss E a");
		System.out.println( sdf.format(now) );
		
		int day1 = cal.get(Calendar.DAY_OF_YEAR);	// 오늘까지 날짜
		int day2 = cal.get(Calendar.DAY_OF_MONTH);	// 이번달 오늘 날짜
		int day3 = cal.get(Calendar.DAY_OF_WEEK);	// 오늘 요일
		int week = cal.get(Calendar.WEEK_OF_YEAR);	// 올해의 이번 주
		System.out.println();
		cal.set(year, month, date);
//		cal.set(2023, 2, 1);
		
		System.out.println(day1);
		System.out.println(day2);
		System.out.println(day3);
		System.out.println(week);
		
		System.out.println(cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		System.out.println(cal.getActualMinimum(Calendar.DAY_OF_MONTH));
		
	}
}
