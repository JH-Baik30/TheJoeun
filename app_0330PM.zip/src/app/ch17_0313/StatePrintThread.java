// 1-1
package app.ch17_0313;

public class StatePrintThread extends Thread{
	private Thread targetThread;						// 여기서
	public StatePrintThread(Thread targetThread) {		// 스프링에서 객체 주입할때
		this.targetThread = targetThread;				// 웹에서 많이 쓰임
	}													// 여기까지
	
	// 현재 상태가 어떤지 무한(true) 적으로 출력한다.
	@Override
	public void run() {
		while (true) {
			Thread.State state = targetThread.getState();
			System.out.println("타켓 스레드 상태: " + state);
			
			if (state == Thread.State.NEW) {
				targetThread.start();
			}
			if (state == Thread.State.TERMINATED) {
				break;
			}
			try {
				// 0.5초간 일시 정지
				Thread.sleep(500);
			} catch (Exception e) {	}
			
		}
		
	}
}
