package app.bankProject.DBBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class BankDBmanagement {
	String driver = "com.mysql.cj.jdbc.Driver";
	String url = "jdbc:mysql://localhost:3306/app";
	Connection conn = null;
	Statement stmt = null;
	
	public String DBload(String order) {
		try {
			Class.forName(driver);
			System.out.println("데이터베이스 드라이버 로딩성공!");
			conn = DriverManager.getConnection(url, "root", "java");	
			System.out.println("데이터베이스 연결성공!");
			stmt = conn.createStatement();
			
			switch (order) {
			case "read": 
				
				break;
			case "update": 
				
				break;
			case "delete": 
				
				break;
			}
			
			
		} catch (Exception e) {
			System.out.println("데이터베이스 드라이버 로딩및 연결실패!");
		} finally {
			try {
				if(stmt != null) stmt.close();		// 상태를 닫고
				if(conn != null) conn.close();		// 연결을 끊는다.
			} catch (Exception e2) {	}
		}
		return driver;
		
	}
//	Create Read Update Delete
	public String DBinsert() {
		
		return null;
	}
	
	
	public String DBread() {
		
		return null;
	}
	
	public String DBupdate() {
		
		return null;
	}
	
	public String DBdelete() {
		
		
		return null;
	}
	
	
}
