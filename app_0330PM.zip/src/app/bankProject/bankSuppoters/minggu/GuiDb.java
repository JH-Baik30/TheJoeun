package app.bankProject.bankSuppoters.minggu;

import java.sql.*;
import java.util.ArrayList;
import java.util.PrimitiveIterator;

public class GuiDb {
    String driver = "com.mysql.cj.jdbc.Driver";
    String url = "jdbc:mysql://localhost:3306/app";
    Connection conn;
    Statement stmt;
    ResultSet rs;

    public ArrayList<String> sidoSelect() {
        String sidoSql = "select sido from zipcode group by sido order by sido asc";
        ArrayList<String> sido = new ArrayList<>();
        try {
            conn = DriverManager.getConnection(url, "root", "java");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sidoSql);

            while (rs.next()) {
                sido.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return sido;
    }

    public ArrayList<String> gugunSelect(String sido) {
        String gugunSql = "select gugun from zipcode where sido = '" + sido + "' group by gugun order by gugun asc";
        ArrayList<String> gugun = new ArrayList<>();
        try {
            conn = DriverManager.getConnection(url, "root", "java");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(gugunSql);
            while (rs.next()) {
                gugun.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return gugun;
    }

    public ArrayList<String> dongSelect(String gugun) {
        String dongSql = "select dong from zipcode where gugun = '" + gugun + "' group by dong order by dong asc";
        ArrayList<String> dong = new ArrayList<>();
        try {
            conn = DriverManager.getConnection(url, "root", "java");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(dongSql);

            while (rs.next()) {
                dong.add(rs.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return dong;
    }

    public ArrayList<String> downSelect(String gugun , String dong) {
        String allSql = "select * from zipcode where (gugun like '%"+gugun+"%' and  dong like '%"+dong+"%') order by dong asc Limit 0,10";
        ArrayList<String> dongList = new ArrayList<>();
        try {
            conn = DriverManager.getConnection(url, "root", "java");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(allSql);
            ResultSetMetaData data = rs.getMetaData();
            int cols = data.getColumnCount();
            while (rs.next()) {
                String zipcode = rs.getString(1 );
                String sido = rs.getString(2 );
                String gugun1 = rs.getString(3);
                String dong1 = rs.getString(4 );
                String ri = rs.getString(5);
                String bldg = rs.getString(6);
                String bunji = rs.getString(7);
                String seq = rs.getString(8);
                dongList.add(zipcode+" "+sido+" "+gugun1+" "+dong1+" "+ri+" "+bldg+" "+bunji+" "+seq);

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return dongList;
    }
    public ArrayList<String> upPage(String gugun, String dong) {
        String upSql = "select * from zipcode where (gugun like '%"+gugun+"%' and  dong like '%"+dong+"%') order by dong asc Limit 10 offset 10";
        ArrayList<String> dongList = new ArrayList<>();
        try {
            conn = DriverManager.getConnection(url, "root", "java");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(upSql);
            ResultSetMetaData data = rs.getMetaData();
            int cols = data.getColumnCount();
            while (rs.next()) {
                String zipcode = rs.getString(1 );
                String sido = rs.getString(2 );
                String gugun1 = rs.getString(3);
                String dong1 = rs.getString(4 );
                String ri = rs.getString(5);
                String bldg = rs.getString(6);
                String bunji = rs.getString(7);
                String seq = rs.getString(8);
                dongList.add(zipcode+" "+sido+" "+gugun1+" "+dong1+" "+ri+" "+bldg+" "+bunji+" "+seq);

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return dongList;
    }
    public ArrayList<String> allSelect() {
        String allSql = "select * from zipcode order by dong asc";
//        StringBuilder sb = new StringBuilder();
        ArrayList<String> allList = new ArrayList<>();
        try {
            conn = DriverManager.getConnection(url, "root", "java");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(allSql);
            ResultSetMetaData data = rs.getMetaData();
            int cols = data.getColumnCount();
            while (rs.next()) {
                String zipcode = rs.getString(1 );
                String sido = rs.getString(2 );
                String gugun1 = rs.getString(3);
                String dong1 = rs.getString(4 );
                String ri = rs.getString(5);
                String bldg = rs.getString(6);
                String bunji = rs.getString(7);
                String seq = rs.getString(8);
                allList.add(zipcode+" "+sido+" "+gugun1+" "+dong1+" "+ri+" "+bldg+" "+bunji+" "+seq);

//                sb.append(rs.getString(1)).append(rs.getString(2)).append(rs.getString(3)).append(rs.getString(4))
//                        .append(rs.getString(5)).append(rs.getString(6)).append(rs.getString(7)).append(rs.getString(8));
//                String str = sb.toString();
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return allList;
    }

}

