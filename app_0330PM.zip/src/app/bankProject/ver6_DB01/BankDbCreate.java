package app.bankProject.ver6_DB01;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;

public class BankDbCreate {
	public static void main(String[] args) throws IOException {
		Properties properties = new Properties();
		String pro = "database.properties";
		properties.load(BankDbCreate.class.getResourceAsStream(pro));
		String driver = properties.getProperty("driver");
		String url = properties.getProperty("url");
		String id = properties.getProperty("username");
		String pw = properties.getProperty("password");
		Connection conn = null;
		Statement stmt = null;
	
		try {
			Class.forName(driver);
			System.out.println("DB Driver Loaded!");
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("DB Connect Success!");
			stmt = conn.createStatement();
			String sql = "CREATE TABLE BANKDB(Account INTEGER, Name VARCHAR(5),"
					+ " PW VARCHAR(10), Balance INTEGER, Create_Date DATETIME)";
			System.out.println(1);
			int result = stmt.executeUpdate(sql);
			String msg = result > -1 ? "성공" : "실패";
			
			System.out.println(2);
			System.out.println("DB Create Success");
		} catch (Exception e) {
			System.out.println("Connect Fail!!!!!!!");
		} finally {
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
				
			} catch (Exception e2) {	}
		}
	}	
	
}
