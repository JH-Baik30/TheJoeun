package app.bankProject.ver6_DB01;

import java.io.IOException;

public class BankService {
	public static void main(String[] args) {
		BankMenu bankGo = new BankMenu();
		try {
			bankGo.logInMenu();
		} catch (IOException e) {
			e.printStackTrace();
		}			
	}
}
