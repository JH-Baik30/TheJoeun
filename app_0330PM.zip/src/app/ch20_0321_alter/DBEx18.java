// 범위 조회
package app.ch20_0321_alter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * BETWWIN (범위): a AND b 에서 a와 b를 포함한(inclusive)
 * 				그 사이의 모든 값에 해당하는지 여부를 조건으로 한다.
 * [실습테이블 만들기] : BWTEST
 * CREATE TABLE BWTEST(
 * 			IDX INT,
 * 			BIRTH DATE,
 * 			NAME VARCHAR(10));
 *  [레코드 추가]
 *  INSERT INTO BWTEST VALUES(1, '2020-01-01', '홍길동');
 *  INSERT INTO BWTEST VALUES(2, '2020-01-02', '이순신');
 *  INSERT INTO BWTEST VALUES(3, '2020-01-03', '만득이');
 *  INSERT INTO BWTEST VALUES(4, '2020-02-01', '개똥이');
 *  INSERT INTO BWTEST VALUES(5, '2020-02-02', '칠득이');
 *  INSERT INTO BWTEST VALUES(6, '2020-03-01', '갑돌이');
 *  INSERT INTO BWTEST VALUES(7, '2020-03-02', '갑순이');
 */
public class DBEx18 {
	public static void main(String[] args) {
		Connection conn = DBAction.getInstance().getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		try {
//			String sql = createTable();
/*			String sql = insert();
			stmt = conn.createStatement();
			int result = stmt.executeUpdate(sql);
			String msg = result > -1 ? "성공" : "실패";
			System.out.println(msg);
*/			
//			Query
			String sql = select();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			while (rs.next()) {
				for (int i = 1; i <= cols; i++) {
					System.out.print(rs.getString(i) + "\t");
				}
				System.out.println();
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	
	public static String createTable() {
		String sql = "CREATE TABLE BWTEST("
								+ "IDX INT,"
								+ "BIRTH DATE,"
								+ "NAME VARCHAR(10))";
		return sql;
	}
	
	public static String insert() {
//		String sql = "INSERT INTO BWTEST VALUES(1, '2020-01-01', '홍길동')";
//		String sql = "INSERT INTO BWTEST VALUES(2, '2020-01-02', '이순신')";
//		String sql = "INSERT INTO BWTEST VALUES(3, '2020-01-03', '만득이')";
//		String sql = "INSERT INTO BWTEST VALUES(4, '2020-02-01', '개똥이')";
//		String sql = "INSERT INTO BWTEST VALUES(5, '2020-02-02', '칠득이')";
//		String sql = "INSERT INTO BWTEST VALUES(6, '2020-03-01', '갑돌이')";
		String sql = "INSERT INTO BWTEST VALUES(7, '2020-03-02', '갑순이')";
		return sql;
	}
	
	public static String select() {
//		String sql = "SELECT * FROM BWTEST WHERE IDX BETWEEN 2 AND 5";
//		String sql = "SELECT * FROM BWTEST WHERE IDX >= 2 AND IDX <= 5";
//		연습문제) 2020-01-02 ~ 2020-01-08 범위의 레코드를 추출하시오.
//		String sql = "SELECT * FROM BWTEST WHERE BIRTH BETWEEN '2020-01-02' AND '2020-01-08'";
//		limit : 범위 추출
//		ex1) 1 ~ n;
//		String sql = "SELECT * FROM BWTEST LIMIT 2";
//		ex2) 가져올 게시물 n개 ~ n 이후 부터.
//		String sql = "SELECT * FROM BWTEST LIMIT 2 OFFSET 5";
//		ex3) 게시물 n 이후 부터 ~ 가져올 게시물 n개;
		String sql = "SELECT * FROM BWTEST ORDER BY idx desc LIMIT 5, 2";
		return sql;
		
		// 실습과제> 뱅크 사용자(회원) 출력화면을 만들고 5명씩 페이지별로 출력하시오.
	}
	
}
