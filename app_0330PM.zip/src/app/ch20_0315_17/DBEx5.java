package app.ch20_0315_17;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class DBEx5 {
	// 연습문제) DBTEST2 TABLE 을 만들고 ID, PW 컬럼으로 데이터를 저장하시오.
	public static void main(String[] args) throws IOException {
//		String driver = "com.mysql.cj.jdbc.Driver";
//		String url = "jdbc:mysql://localhost:3306/app";

		Properties properties = new Properties();
		properties.load(DBEx5.class.getResourceAsStream("database.properties"));
		String driver = properties.getProperty("driver");
		String url = properties.getProperty("url");
		Connection conn = null;
		Statement stmt = null;
		
		try {
			Class.forName(driver);
			System.out.println("데이터베이스 드라이버 로딩성공!");
			conn = DriverManager.getConnection(url, "root", "java");
			System.out.println("데이터베이스 연결성공!");
			stmt = conn.createStatement();
			
			String sql = "CREATE TABLE DBTEST2(ID varchar(10),PassWord varchar(10))";
			stmt.executeUpdate(sql);
			String input = insert();
			int result = stmt.executeUpdate(input);
			String msg = result > -1 ? "성공" : "실패";

		} catch (Exception e) {
			System.out.println("연결 실패!!!!");
		} finally {
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	public static String insert() {
		Scanner scan = new Scanner(System.in);
		System.out.print("ID = ");
		String id = scan.next(); 
		System.out.print("PW = ");
		String pw = scan.next();
		String sql = "INSERT INTO DBTEST2 VALUES('" + id + "', '" + pw + "')";
		return sql;
	}
	
}
