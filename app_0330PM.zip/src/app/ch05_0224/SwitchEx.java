package app.ch05_0224;

import java.io.IOException;

public class SwitchEx {
	public static void main(String[] args) throws IOException {
		switch (2) {
		case 1:
			System.out.println("실행구문1");
			break;
		case 2:
			System.out.println("실행구문2");
			break;
		case 3:
			System.out.println("실행구문3");
			break;
		default:
			System.out.println("기본실행구문");
		}
		// yes or no example
		System.out.print("Yes/No ?");
		char c = (char) System.in.read();

		switch (c) {
		case 'y':
		case 'Y':
			System.out.println("Yes");
			break;
		case 'n':
		case 'N':
			System.out.println("No");
			break;

		default:
			System.out.println("Wrong answer");
		}
	}
}
