package app.ch08_0302_12.abstract0302;

public class Rect extends Shape {
	protected int width, height;

	public Rect() {
		this(0, 0);
	}

	public Rect(int w, int h) {
		width = w;
		height = h;
		x = getWidth();
		y = getHeight();
	}

	@Override
	public double circumference() {
		return 2 * (width + height);
	}

	@Override
	public double area() {
		return width * height;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public void setSize(int w, int h) {
		width = w;
		height = h;
	}

	public int getSize() {
		return x * y;
	}
}
/*
 * Annotation은 자바 소스 코드에 추가하여 사용할 수 있는 메타데이터의 일종입니다. 
 * 소스코드에 추가하면 단순 주석의 기능을 하는 것이 아니라 특별한 기능을 사용할 수 있습니다.
 * Annotation은 클래스와 메서드에 추가하여 다양한 기능을 부여하는 역할을 합니다.
 */
