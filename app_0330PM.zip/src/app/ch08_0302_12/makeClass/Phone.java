package app.ch08_0302_12.makeClass;

public class Phone {
	String name;
	String color;
	String company;
	
	void call() {
		System.out.println("전화를 건다.");
	}
	
	void receive() {
		System.out.println("전화를 받다.");
	}
}
