package app.ch08_0302_12.makeClass;

public class SmartPhone extends Phone{
	public void installApp() {
		System.out.println("앱 설치");
	}
}
