package test;

public class TestTest {
	
	
	
	public static void main(String[] args) {
		TestTest test = new TestTest();
		String a = String.valueOf(123);
		int i = 123;
		test.text11(i);
	
	}
	
	public void text11(int a) {
		System.out.println(a+""+"111");
	}
}
