package test.uitest;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Ex extends JFrame {

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ex frame = new Ex();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Ex() {
	    JPanel welcome = new JPanel() {
	        Image bgi = new ImageIcon(Ex.class.getResource(
	        				"welcome1.jpg")).getImage();

	        public void paintComponent(Graphics g) {
	            super.paintComponent(g);
	            g.drawImage(bgi, 0, 0, getWidth(), getHeight(), this);
	        }
	    };
	    
	    JButton button = new JButton("버튼");

	    welcome.setLayout(new BorderLayout()); // 레이아웃 매니저를 BorderLayout으로 설정합니다.
	    welcome.add(button, BorderLayout.SOUTH);
	    
	    setBounds(100, 100, 450, 300);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setContentPane(welcome); // JPanel을 JFrame의 컨텐트 팬으로 설정합니다.
	}

	
	
	
	
	
	
}
