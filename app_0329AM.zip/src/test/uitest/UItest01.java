package test.uitest;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.awt.CardLayout;
import javax.swing.JLabel;
import javax.swing.JSplitPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.UIManager;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import javax.swing.JTextPane;
import javax.swing.JTextArea;

public class UItest01 extends JFrame {
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_5;
	private JTextField textField_6;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;

	public UItest01() {
		setTitle("YN Bank");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		JPanel login = new JPanel();
		login.setBorder(UIManager.getBorder("Button.border"));
		contentPane.add(login, "login");
		login.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		login.add(panel);
		panel.setLayout(new GridLayout(3, 1, 0, 0));
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1);
		
		JPanel idpw = new JPanel();
		panel.add(idpw);
		idpw.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("");
		idpw.add(lblNewLabel, BorderLayout.NORTH);
		
		JLabel lblNewLabel_1 = new JLabel("");
		idpw.add(lblNewLabel_1, BorderLayout.SOUTH);
		
		JLabel lblNewLabel_2 = new JLabel("                          ");
		idpw.add(lblNewLabel_2, BorderLayout.WEST);
		
		JLabel lblNewLabel_3 = new JLabel("                          ");
		idpw.add(lblNewLabel_3, BorderLayout.EAST);
		
		JPanel panel_3 = new JPanel();
		idpw.add(panel_3, BorderLayout.CENTER);
		panel_3.setLayout(new GridLayout(3, 0, 0, 0));
		
		textField = new JTextField();
		textField.setText("아이디");
		panel_3.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("                     ");
		panel_3.add(lblNewLabel_4);
		
		textField_1 = new JTextField();
		textField_1.setText("비밀번호");
		panel_3.add(textField_1);
		textField_1.setColumns(10);
		
		JPanel buttons = new JPanel();
		panel.add(buttons);
		buttons.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_5 = new JLabel("                          ");
		buttons.add(lblNewLabel_5, BorderLayout.NORTH);
		
		JLabel lblNewLabel_6 = new JLabel("                          ");
		buttons.add(lblNewLabel_6, BorderLayout.WEST);
		
		JLabel lblNewLabel_7 = new JLabel("                          ");
		buttons.add(lblNewLabel_7, BorderLayout.SOUTH);
		
		JLabel lblNewLabel_8 = new JLabel("                          ");
		buttons.add(lblNewLabel_8, BorderLayout.EAST);
		
		JPanel panel_4 = new JPanel();
		buttons.add(panel_4, BorderLayout.CENTER);
		panel_4.setLayout(new GridLayout(1, 2, 0, 0));
		
		JButton btnNewButton = new JButton("로그인");
		panel_4.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("회원가입");
		panel_4.add(btnNewButton_1);
		
		JPanel membership = new JPanel();
		contentPane.add(membership, "membership");
		membership.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_9 = new JLabel("                      ");
		membership.add(lblNewLabel_9, BorderLayout.WEST);
		
		JLabel lblNewLabel_10 = new JLabel("                      ");
		membership.add(lblNewLabel_10, BorderLayout.EAST);
		
		JPanel panel_2 = new JPanel();
		membership.add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new GridLayout(7, 2, 0, 0));
		
		JLabel lblNewLabel_11 = new JLabel("아이디 입력");
		lblNewLabel_11.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("       ");
		panel_2.add(lblNewLabel_12);
		
		textField_2 = new JTextField();
		panel_2.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton_3 = new JButton("중복확인");
		panel_2.add(btnNewButton_3);
		
		JLabel lblNewLabel_14 = new JLabel("비밀번호");
		lblNewLabel_14.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel("비밀번호 확인");
		lblNewLabel_15.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblNewLabel_15);
		
		passwordField = new JPasswordField();
		panel_2.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		panel_2.add(passwordField_1);
		
		JLabel lblNewLabel_16 = new JLabel("이    름");
		lblNewLabel_16.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblNewLabel_16);
		
		JLabel lblNewLabel_17 = new JLabel("생 년 월 일");
		lblNewLabel_17.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblNewLabel_17);
		
		textField_5 = new JTextField();
		panel_2.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		panel_2.add(textField_6);
		textField_6.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("가    입");
		panel_2.add(btnNewButton_2);
		
		JButton btnNewButton_4 = new JButton("초 기 화");
		panel_2.add(btnNewButton_4);
		
		JLabel lblNewLabel_13 = new JLabel("  ");
		membership.add(lblNewLabel_13, BorderLayout.NORTH);
		
		JLabel lblNewLabel_18 = new JLabel("  ");
		membership.add(lblNewLabel_18, BorderLayout.SOUTH);
		
		JPanel banking = new JPanel();
		contentPane.add(banking, "banking");
		banking.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_19 = new JLabel("New label");
		banking.add(lblNewLabel_19, BorderLayout.WEST);
		
		JLabel lblNewLabel_20 = new JLabel("New label");
		banking.add(lblNewLabel_20, BorderLayout.EAST);
		
		JLabel lblNewLabel_21 = new JLabel("New label");
		banking.add(lblNewLabel_21, BorderLayout.NORTH);
		
		JTextArea textArea = new JTextArea();
		textArea.setText("ㅇㄹㅇㄴㅁㄹ");
		banking.add(textArea, BorderLayout.CENTER);
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
//		new UItest01();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UItest01 frame = new UItest01();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	
	
}
