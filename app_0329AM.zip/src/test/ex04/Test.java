package test.ex04;

public class Test {
	public static void main(String[] args) {
		
		int price = 187_000;
		int oman = price / 50000;
		int ilman = price % 50000 / 10000;
		int ochun = price % 10000 / 5000;
		int ilchun = price % 5000 / 1000;
		System.out.println(oman);
		System.out.println(ilman);
		System.out.println(ochun);
		System.out.println(ilchun);
	}
}
