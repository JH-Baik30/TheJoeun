package test.ex05;

import java.util.Scanner;

public class Excercise04 {
	public static void main(String[] args) {
		/*System.out.print("input number: ");
		int t = new Scanner(System.in).nextInt();
		for (int i = 0; i < input; i++) {
			for (int j = 0; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		//*
		System.out.println();*/
		int t = 5;
		System.out.println("우측 삼각");
		for (int i = 0; i < 4; i++) {
			for (int j = 4; j > i+1; j--) {
				System.out.print(" ");
			}
			for (int k = 0; k <= i; k++) {
				System.out.print("*");
			}
			System.out.println();
		}
		

		System.out.println();
		System.out.println("좌측 역삼각");
		for (int i = 0; i < t; i++) {
			for (int j = t; j > i; j--) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		System.out.println();
		System.out.println("좌삼각");
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}//*/
		
		System.out.println();	
		System.out.println("우측 역삼각");
		for (int i = 0; i < t; i++) {
			for (int j = 0; j < i; j++) {
				System.out.print(" ");
			}			
			for (int j = t; j > i; j--) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		System.out.println();
		System.out.println("트리");
		for (int i = 0; i < 5; i++) {
			for (int j = 5; j > i+1; j--) {
				System.out.print(" ");
			}
			for (int j = 0; j < i*2-1; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		System.out.println();
		System.out.println("역트리");
		for (int i = 0; i < t; i++) {
			if (t %2 ==1) {
				
			for (int j = 0; j < i; j++) {
				System.out.print(" ");
			}
			for (int j = 6; j > i*2-1; j--) {
				System.out.print("*");
			}
			System.out.println();
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
