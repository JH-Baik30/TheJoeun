package app.ch08_0302_12.inher0302;
/*
 * 기타 제어자(수정자)
 * 형식)
 * final : 
 * 	- class		: 상속 안됨
 *  - method	: 재사용 안됨
 *  - variable	: 상수화
 * 
 * static :
 * 	- 객체 생성없이 사용가능(정적 메모리에 생성)
 * abstract :
 * 	- class : 추상 클래스
 * 	- method: 추상 메소드  
 */
public class StaticEx {
	public final int A = 10;
	static int b = 10;
	public static void main(String[] args) {
		StaticEx obj = new StaticEx();
		System.out.println(obj.A);
		System.out.println(b);
	}
}
