package app.ch17_0311_13;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.util.Random;

import javax.swing.JFrame;

public class ThreadRectDraw extends JFrame implements Runnable{
	int x = 0;
	int y = 20;
	boolean xOrient, yOrient;
	public ThreadRectDraw(String title) {
		super(title);
		setSize(800, 600);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void paint(Graphics gr) {
		Toolkit beep = Toolkit.getDefaultToolkit();
		Random ran = new Random();
		Dimension d = this.getSize();		// container의 사이즈를 가져와라.
		// 창의 크기 안에서 튕기게 하는 좌표값
		if (xOrient) {
			x--;
			if (x < 05) {
				x = 05;
				xOrient = false;
				beep.beep();
			}
		} else {
			x++;
			if (x >= d.width - 20) {		// 창의 크기를 고려하여 튕김
				x = d.width - 20;
				xOrient = true;
				beep.beep();
			}
		}
		if (yOrient) {
			y--;
			if (y < 25) {
				y = 25;
				yOrient = false;
				beep.beep();
			}
		} else {
			y++;
			if (y >= d.height - 20) {
				y = d.height - 20;
				yOrient = true;
				beep.beep();
			}
		}
		int r = ran.nextInt(255);
		int g = ran.nextInt(255);
		int b = ran.nextInt(255);
		Color color = new Color(r, g, b);
		gr.setColor(color);
//		gr.drawRect(x, y, 20, 20);		// x, y 는 x,y의 시작 점title bar 때문에 20을 준다.
		gr.drawOval(x, y, 20, 20);
		gr.drawArc(10, 10, 10, 0, 0, 0);
	}
	
	public void update(Graphics g) {	// 지워주는 역할 override 해서 잔상이 남는다.
		paint(g);
	}
	
	public void run() {
		while (true) {
			repaint();
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		ThreadRectDraw t = new ThreadRectDraw("구슬튕기기");
		Thread thread = new Thread(t);
		thread.start();
	}
}
