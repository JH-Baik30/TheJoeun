package app.bankProject.recordData;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class Test {
	public static void main(String[] args) throws Exception{
		File file = new File("G:/work/app/src/app/bankproject/recordData/datafile.csv");
		File file2 = new File("G:/work/app/src/app/bankproject/recordData/datafile2.csv");
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		String[] str = new String[4];
		while (br.ready()) {
//			str = br.readLine().split(",");
//			System.out.println(str[0] + " _ " + str[1] + " _ " + str[2] + " _ " + (Integer.parseInt(str[3])));
			System.out.println(br.readLine().split(",")[0]);
		}
	}
}
