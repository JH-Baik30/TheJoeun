package app.bankProject.bankSuppoters.minggu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Gui extends JFrame {
    JComboBox<String> sidoBox , gugunBox, dongBox;
    GuiDb db;
    JScrollPane Js;
    JList<String> jList;
    DefaultListModel<String> model;
    public Gui(){
        db = new GuiDb();
        blankInit();
        mainInit();
        bottomInit();
        Init();
    }

    private void blankInit() {
        JPanel blankPanel = new JPanel();
        add(blankPanel, BorderLayout.NORTH);
    }
    private void mainInit() {
        JPanel mainPanel = new JPanel();
        JPanel sectionPanel, sidoPanel, gugunPanel, dongPanel, centerPanel, bottomPanel, pagePanel;
        JLabel sidoLabel, gugunLabel, dongLabel, bottomLabel;
        JTextArea addressTa;
        JButton downButton , upButton;
//        시 군 동 섹션 패널 만들기  (setlayout flowlayout)
        sectionPanel = new JPanel(new FlowLayout());
//        시 패널 및 라벨 콤보박스 만들기 및 섹션패널에 넣기
        sidoPanel = new JPanel();   sidoLabel = new JLabel("   시 도");     sidoBox = new JComboBox<>();
//        시도 콤보박스에 어레이 리스트 넣기
        for(String sido : db.sidoSelect()){
            sidoBox.addItem(sido);
        }
        sidoPanel.add(sidoLabel);   sidoPanel.add(sidoBox);
        sectionPanel.add(sidoPanel);
//        군 패널 및 라벨 콤보박스 만들기 및 섹셔패널에 넣기
        gugunPanel = new JPanel();  gugunLabel = new JLabel("    구 군");     gugunBox = new JComboBox<>();
        gugunPanel.add(gugunLabel); gugunPanel.add(gugunBox);
        sectionPanel.add(gugunPanel);
//        동 패널 및 라벨 콤보박스 만들기 및 섹션패널에 넣기
        dongPanel = new JPanel();   dongLabel = new JLabel("     동");   dongBox = new JComboBox<>();
        dongPanel.add(dongLabel);   dongPanel.add(dongBox);
        sectionPanel.add(dongPanel);
        mainPanel.add(sectionPanel);

//        센터 패널 만들고 거기에 textarea 넣기
        centerPanel = new JPanel(new BorderLayout());     addressTa = new JTextArea(10,50);   addressTa.setEditable(false);
        model = new DefaultListModel<>();
        jList = new JList<>(model);
        jList.setPreferredSize(new Dimension(500, 180));
//        Jl = new JList<>();
//        Js = new JScrollPane();
//        addressTa.add(jList);
        centerPanel.add(jList,BorderLayout.CENTER);
//        메인패널 하단에 페이지 업다운 버튼 추가하기
        pagePanel = new JPanel(new GridLayout(1,4));
        downButton = new JButton("이전");
        upButton = new JButton("다음");
        pagePanel.add(new JLabel()); pagePanel.add(downButton); pagePanel.add(upButton); pagePanel.add(new JLabel());


//        센터패널 하단에 라벨 추가하기 이 패널은 플로우 레이아웃 설정
        bottomPanel = new JPanel(new GridLayout(5,1));
        bottomLabel = new JLabel("상세 주소",JLabel.CENTER);
        JTextField tf = new JTextField(50);
        tf.setEditable(false);
        JTextArea ta = new JTextArea(3,50);
        bottomPanel.add(tf);
        bottomPanel.add(bottomLabel);
        bottomPanel.add(ta);
        centerPanel.add(pagePanel,BorderLayout.SOUTH);

//        메인패널에 섹션이랑 센터패널 넣어주기
        mainPanel.add(sectionPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel,BorderLayout.SOUTH);
        add(mainPanel,BorderLayout.CENTER);


        sidoBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String sido = (String) sidoBox.getSelectedItem();
                gugunBox.removeAllItems();  // 해주지않으면 어펜드 됌
                for(String gugun : db.gugunSelect(sido)){
                    gugunBox.addItem(gugun);
                }
            }
        });

        gugunBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String gugun = (String) gugunBox.getSelectedItem();
                dongBox.removeAllItems();
                for(String dong : db.dongSelect(gugun)){
                    dongBox.addItem(dong);
                }
            }
        });
        dongBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String dong = (String) dongBox.getSelectedItem();
                String gugun = (String) gugunBox.getSelectedItem();
                model.clear();
                for(String all : db.downSelect(gugun,dong)){
                    model.addElement(all+"\n");
                }
            }
        });downButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String dong = (String) dongBox.getSelectedItem();
                String gugun = (String) gugunBox.getSelectedItem();
                model.clear();
                for(String all : db.downSelect(gugun,dong)){
                    model.addElement(all+"\n");
                }
            }
        });

        upButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String gugun = (String) gugunBox.getSelectedItem();
                String dong = (String) dongBox.getSelectedItem();
                model.clear();
                for(String up : db.upPage(gugun, dong)){
                    model.addElement(up+"\n");
                }
            }
        });
    }
    private void bottomInit() {
        JPanel bottomPanel = new JPanel();
        JButton backButton, saveButton;
        backButton = new JButton("뒤로가기");
        saveButton = new JButton("저장하기");
        bottomPanel.add(backButton);        bottomPanel.add(saveButton);
        add(bottomPanel,BorderLayout.SOUTH);
    }
    private void Init() {
        String sido = (String) sidoBox.getSelectedItem();
        gugunBox.removeAllItems();  // 해주지않으면 어펜드 됌
        for(String gugun : db.gugunSelect(sido)){
            gugunBox.addItem(gugun);
        }
//        setEnabled(false);
        setTitle("주소 입력 창");
//        setResizable(false);
        setSize(600,500);
        setVisible(true);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new Gui();
        
    }
}
