package app.bankProject.bankSuppoters.jeahui;

//package ggg;

import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Synthesizer;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Test extends JFrame {
    JButton a;

    public Test() throws MidiUnavailableException {
        a = new JButton("학교종이 땡땡땡");

        Synthesizer synth = MidiSystem.getSynthesizer();
        synth.open();
        MidiChannel[] channels = synth.getChannels();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(a);
        setSize(300, 300);
        setVisible(true);

        a.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                channels[0].programChange(0); // 피아노 소리 선택
//                channels[0].noteOn(60, 100); // C4 음을 100 음량으로 재생
//                channels[0].noteOff(60); // C4 음 종료
//                System.out.println("피아노");
                channels[0].noteOn(67,100); //솔
                channels[0].noteOff(67); //솔
                delay();
                channels[0].noteOn(67,100); //솔
                channels[0].noteOff(67); //솔
                delay();
                channels[0].noteOn(69,100); //라
                channels[0].noteOff(69); //라
                delay();
                channels[0].noteOn(69,100); //라
                channels[0].noteOff(69); //라
                delay();
                channels[0].noteOn(67,100); //솔
                channels[0].noteOff(67); //솔
                delay();
                channels[0].noteOn(67,100); //솔
                channels[0].noteOff(67); //솔
                delay();
                channels[0].noteOn(64,100); //미
                delay();
                channels[0].noteOff(64); //미
                delay2();
                channels[0].noteOn(67,100); //솔
                channels[0].noteOff(67); //솔
                delay();
                channels[0].noteOn(67,100); //솔
                channels[0].noteOff(67); //솔
                delay();
                channels[0].noteOn(64,100); //미
                channels[0].noteOff(64); //미
                delay();
                channels[0].noteOn(64,100); //미
                channels[0].noteOff(64); //미
                delay();
                channels[0].noteOn(62,100); //레
                delay();
                channels[0].noteOff(62); //레
                delay2();
                channels[0].noteOn(67,100); //솔
                channels[0].noteOff(67); //솔
                delay();
                channels[0].noteOn(67,100); //솔
                channels[0].noteOff(67); //솔
                delay();
                channels[0].noteOn(69,100); //라
                channels[0].noteOff(69); //라
                delay();
                channels[0].noteOn(69,100); //라
                channels[0].noteOff(69); //라
                delay();
                channels[0].noteOn(67,100); //솔
                channels[0].noteOff(67); //솔
                delay();
                channels[0].noteOn(67,100); //솔
                channels[0].noteOff(67); //솔
                delay();
                channels[0].noteOn(64,100); //미
                delay();
                channels[0].noteOff(64); //미
                delay();
                channels[0].noteOn(67,100); //솔
                channels[0].noteOff(67); //솔
                delay();
                channels[0].noteOn(64,100); //미
                channels[0].noteOff(64); //미
                delay();
                channels[0].noteOn(62,100); //레
                channels[0].noteOff(62); //레
                delay();
                channels[0].noteOn(64,100); //미
                channels[0].noteOff(64); //미
                delay();
                channels[0].noteOn(60,100); //도
                channels[0].noteOff(60); //도
                delay();

                // 드럼 소리 재생
//                channels[9].programChange(25); // 드럼 소리 선택
//                channels[9].noteOn(38, 100); // Snare Drum 음을 100 음량으로 재생
//                channels[9].noteOff(38); // Snare Drum 음 종료
//                System.out.println("드럼");

            }
        });
    }
    public void delay(){
        try{
            Thread.sleep(300);
        }catch (Exception e){

        }
    }public void delay2(){
        try{
            Thread.sleep(800);
        }catch (Exception e){

        }
    }

    public static void main(String[] args) throws MidiUnavailableException {
        System.out.println("테스트 입니다");
        new Test();

        // 피아노 소리 재생

    }
}