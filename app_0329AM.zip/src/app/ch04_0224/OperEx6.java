package app.ch04_0224;

public class OperEx6 {
	public static void main(String[] args) {
		int a = 0;
		int b = 0;
		/*System.out.println(a++ + a++);
		System.out.println(a + --a + ++a); //2 1 2 = 5
		System.out.println(--a + a++);		// 1 1 = 2
		System.out.println(a);				// 2
		
		System.out.println();
		System.out.println(0 + a++);
		System.out.println(a++ + 0);
		System.out.println();
		System.out.println(b++ + 0);
		System.out.println(0 + b++);*/
		
		System.out.println(++a);
		System.out.println(a);
		System.out.println(a++);
		System.out.println(a);
		
	}
}
