package app.ch20_0320_utilize;

import java.sql.Connection;
import java.sql.Statement;

/*	String sql = "CREATE TABLE TEST1("
			+ "ID VARCHAR(10) UNIQUE, "
			+ "PW VARCHAR(30), "
			+ "NAME VARCHAR(30), "
			+ "MDate DATE, AGE INT)";
 */
public class DBEx11 {
	public static void main(String[] args) {
		Connection conn = DBAction.getInstance().getConnection();
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
			String sql = insert();
			stmt.executeUpdate(sql);
//			UNIQUE
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
			}
		}
	}
	
	public static String insert() {
		String sql = "INSERT INTO TEST2(ID, PW) VALUES('ABC', '123')"; 
		return sql;
	}
	
	
}
