package app.ch20_0320_utilize;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

/*
 * ex1) [테이블 생성]
 * 			CREATE TABLE TEST2(
 * 					ID	  VARCHAR(10) UNIQUE,
 * 					PW	  VARCHAR(30),
 * 					NAME  VARCHAR(30),
 * 					MDate DATE,
 * 					AGE   INT
 * 			);
 */

/*
 * 제약 조건(constraint) 교재 359p 참고
 */
public class DBEx10 {
	public static void main(String[] args) {
		String driver = "com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/app";
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			Class.forName(driver);
			System.out.println("데이터베이스 드라이버 로딩성공!");
			conn = DriverManager.getConnection(url, "root", "java");	
			System.out.println("데이터베이스 연결성공!");
			stmt = conn.createStatement();
			String sql = createTable();		// table 생성
//			String sql = insert();			// 
			
//			String sql = select();				// 1 부터
			rs = stmt.executeQuery(sql);
			ResultSetMetaData rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			while (rs.next()) {
				for (int i = 0; i < cols; i++) {
					System.out.println(rs.getString(i) + "\t");
				}
				System.out.println();
			}									// 1 까지 select문
			
			System.out.println(1);
			int result = stmt.executeUpdate(sql);
			System.out.println(2);
			String msg = result > -1 ? "성공" : "실패";
		} catch (Exception e) {
			System.out.println("데이터베이스 드라이버 로딩및 연결실패!");
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)rs.close();
				if(stmt != null) stmt.close();		// 상태를 닫고
				if(conn != null) conn.close();		// 연결을 끊는다.
			} catch (Exception e2) {	}
		}
	}
		
	public static String createTable() {
		String sql = "CREATE TABLE TEST1("
				+ "ID VARCHAR(10) UNIQUE, "
				+ "PW VARCHAR(30), "
				+ "NAME VARCHAR(30), "
				+ "MDate DATE, AGE INT)";
		return sql;
	}
	
	public static String insert() {
//		String sql = "INSERT INTO TEST2(ID, PW) VALUES('ABC', '123')";
		String sql = "INSERT INTO TEST2(PW) VALUES('123')";	// select 예제
		return sql;
	}
	
	public static String select() {
		String sql = "SELECT * FROM TEST2";
		return sql;
	}
}
