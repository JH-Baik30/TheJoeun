package app.ch07_0227_28;

public class ConstructorEx2 {
	ConstructorEx2() {
		this(100);
	}
	ConstructorEx2(int a) {
		this(100, "A");
	}
	ConstructorEx2(int a, String b) {
		System.out.println(a);
		System.out.println(b);
	}
	
	public static void main(String[] args) {
		ConstructorEx2 obj = new ConstructorEx2();
	}
}
