package app.ch20_0322_UI;

import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JFrame;

public class AddTest extends JFrame{
	static AddressDBContact adbc = new AddressDBContact();
	static ArrayList<String> sido = adbc.sidoDB();
	JComboBox<String> sidoCB;
	
	public AddTest() {
		sidoCB = new JComboBox<String>(sido.toArray(new String[sido.size()]));
//		String>(array .toArray(new String[array .size()]));
	}
	
	
	
	
}
