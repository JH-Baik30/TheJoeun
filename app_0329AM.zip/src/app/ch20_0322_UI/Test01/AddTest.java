package app.ch20_0322_UI.Test01;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JFrame;

public class AddTest extends JFrame{
	static AddressDBContact adbc = new AddressDBContact();
	static ArrayList<String> sido = adbc.getsido();
	ArrayList<String> gugun = new ArrayList<>(); 
	JComboBox<String> sidoCB, gugunCB;
	
	public AddTest() {
		sidoCB = new JComboBox<String>(sido.toArray(new String[sido.size()]));
		gugunCB = new JComboBox<String>(gugun.toArray(new String[gugun.size()]));
		
		setLayout(new FlowLayout());
		add(sidoCB);
		add(gugunCB);
		setTitle("주소검색");
		setSize(300, 300);
		setVisible(true);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
				try {
					adbc.closeDB();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}	
			}
		});
		
		sidoCB.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String gugu = sidoCB.getSelectedItem().toString();
				System.out.println(gugun);
//				gugun = AddressDBContact.getGugun(gugu);
//				System.out.println(gugun.get(1));
			}
		});
		
		
	}
	
//	 adbc.getGugun(getName());
	public static void main(String[] args) {
		new AddTest();
	}
	
}
