package app.ch19_0314.jaehui;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.Vector;

public class ChatServer {
	private Vector handlers;

	public ChatServer(int port) {
		try {
			ServerSocket server = new ServerSocket(port);
			handlers = new Vector<>();
			System.out.println("챗 서버 레디");
			while (true) {
				ChatHandler handler = new ChatHandler(this, server.accept());
				handler.start();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Object getHandler(int index) {
		return handlers.elementAt(index);
	}

	public void register(ChatHandler c) {
		handlers.addElement(c);// 벡터에 쌓는다

	}

	public void unregister(Object o) {
		handlers.removeElement(o);// 벡터에서 지운다
	}

	public void broadcast(String messager) {
		synchronized (handlers) { // 영역 정해서 동기화 처리

			int n = handlers.size();
			for (int i = 0; i < n; i++) {
				ChatHandler c = (ChatHandler) handlers.elementAt(i);
				try {
					c.println(messager);
				} catch (Exception e) {
				}
			}
			System.out.println(handlers.get(0).getClass().getName());
		}
	}

	public static void main(String[] args) {
		new ChatServer(7979);
	}

}
