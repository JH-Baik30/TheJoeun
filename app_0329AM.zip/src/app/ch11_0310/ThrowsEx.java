package app.ch11_0310;

public class ThrowsEx {
	public static void main(String[] args) throws Exception{
		
		try {
			a();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	static void a() throws Exception{
		Class clazz = Class.forName("java.lang.String2");
	}
	
	static void b() throws Exception{
		Class clazz = Class.forName("java.lang.String2");
		throw new Exception();
	}
}
