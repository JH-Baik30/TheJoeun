// 연습문제) 파일에 기록된 문자데이터를 화면에 출력하시오.

package app.ch18;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Excercise1 {
	public static void main(String[] args) throws IOException{

//		// 내 답안.		
		BufferedWriter bw = new BufferedWriter(new FileWriter("G:/work/file/IO1.txt"));
		BufferedReader br = new BufferedReader(new FileReader("G:/work/file/IO.txt"));
		String str;
		
		// solution 1
		while((str = br.readLine()) != null) {
			System.out.println(str);
			bw.write(str+"\n");
		}
		// solution 2
		while(br.ready()) {
//			str = br.readLine();
//			System.out.println(str);
			bw.write(br.readLine() + "\n");
		}
		
		bw.close();
		br.close();
		
//		// 쌤 답안.
//		FileReader fr = new FileReader("G:/work/file/IOIO.txt");
//		BufferedReader brfr = new BufferedReader(fr);
//		while(brfr.ready()) {
//			System.out.println(brfr.readLine());
//		}
//		brfr.close();
//		System.out.println("미션완료");
		
	}
}
