// record to file
package app.ch18;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class IOEx8 {
	public static void main(String[] args) throws IOException{
//		File file = new File("G:/work/file/IO.txt");
		File file = new File("J:/work/file/IO.txt");
		FileOutputStream fos = new FileOutputStream(file);
		System.out.println("입력 : ");
		int output = 0;
		while (output != -1) {
			output = System.in.read();
			fos.write(output);
		}
		fos.close();
	}
}
