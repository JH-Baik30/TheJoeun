package app.bankproject.UI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import app.bankProject.ver3.CreateAccMenu2;
import app.bankProject.ver3.Member;

public class UI3 extends JFrame implements ActionListener{
	Toolkit toolkit = Toolkit.getDefaultToolkit();
	public JButton bt1, bt2, bt3, bt4, bt5, bt6, btExit, btLogIn;
	public TextArea tArea;
	public JPanel jpb1, jpt, jpb2;
//	private JLabel label;
	String s1 = "입     금",
		   s2 = "출     금",
		   s3 = "예금 조회",
		   s4 = "계좌 이체",
		   s5 = "공 사 중",
		   s6 = "계좌 개설",
		   sLogIn = "로그 인",
		   sExit = "종     료";
	
	
	public UI3() {
		bt1 = new JButton(s1);//"은행 업무");
		bt1.setPreferredSize(new Dimension(50, 25));
		bt2 = new JButton(s2);
		bt2.setPreferredSize(new Dimension(50, 2));
		bt3 = new JButton(s3);
		bt3.setPreferredSize(new Dimension(100, 50));
		bt4 = new JButton(s4);
		bt4.setPreferredSize(new Dimension(100, 50));
		bt5 = new JButton(s5);
		bt5.setPreferredSize(new Dimension(100, 50));
		bt6 = new JButton(s6);
		bt6.setPreferredSize(new Dimension(100, 50));
		btExit = new JButton(sLogIn);
		btExit.setPreferredSize(new Dimension(50, 25));
		btLogIn = new JButton(sExit);
		btLogIn.setPreferredSize(new Dimension(100, 50));
		tArea = new TextArea();
		
		jpb1 = new JPanel(new BorderLayout(50, 50));
		jpt = new JPanel();
		jpb2 = new JPanel();
		jpb1.setLayout(new GridLayout(3, 1));
		jpb1.add(bt1);	jpb1.add(bt2);	jpb1.add(btExit);
		jpt.setLayout(new BorderLayout());
		jpt.add(tArea, BorderLayout.CENTER);
		jpb2.setLayout(new GridLayout(5, 1));
		jpb2.add(bt3);	jpb2.add(bt4);	jpb2.add(bt5);	jpb2.add(bt6);	jpb2.add(btLogIn);
		
		/*add(bt1, BorderLayout.WEST);
		add(bt2, BorderLayout.WEST);
		add(btx, BorderLayout.WEST);
		add(jpt, BorderLayout.CENTER);
		add(bt3, BorderLayout.EAST);
		add(bt4, BorderLayout.EAST);
		add(bt5, BorderLayout.EAST);
		add(bt6, BorderLayout.EAST);
		add(btLO, BorderLayout.EAST);*/
		
		
//		setLayout(new GridLayout(1, 3, 20, 20));
		setLayout(new GridLayout(1, 3));
		add(jpb1, BorderLayout.CENTER);
		add(jpt, BorderLayout.CENTER);
		add(jpb2, BorderLayout.CENTER);
		setTitle("ATM");
		setSize(500,400);
		setVisible(true);
		
		bt1.addActionListener(this);
		bt2.addActionListener(this);
		bt3.addActionListener(this);
		bt4.addActionListener(this);
		bt5.addActionListener(this);
		bt6.addActionListener(this);
		btExit.addActionListener(this);
		btLogIn.addActionListener(this);

//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		CreateAccMenu2 createAccMenu2 = new CreateAccMenu2();
		Object obj = e.getSource();
		if (obj == bt1) {
			toolkit.beep();
			tArea.setText(" << 입금을 선택하셨습니다. >>");
			createAccMenu2.logInMenu();
		} else if (obj == bt2) {
			toolkit.beep();
			tArea.setText(" << 출금을 선택하셨습니다. >>");
			
		} else if (obj == bt3) {
			toolkit.beep();
			tArea.setText(" << 조회를 선택하셨습니다. >>");
			createAccMenu2.logIn();
		} else if (obj == bt4) {
			toolkit.beep();
			tArea.setText(" << 계좌이체를 선택하셨습니다. >>");
			createAccMenu2.accountTransfer(00);
		} else if (obj == bt5) {
			toolkit.beep();
			tArea.setText(" << 서비스 준비중 >>");
			
		} else if (obj == bt6) {
			toolkit.beep();
			tArea.setText(" << 계좌 개설을 선택하셨습니다. >>");
//			Create.
			
			
			
		} else if (obj == bt2) {
			
		} else if (obj == bt2) {
			
		} else if (obj == bt2) {
			
		} else if (obj == bt2) {
			
		}
		
		
		
//		"은행 업무"
//		"계좌 개설"
//		"입     금"
//		"출     금"
//		"예금 조회"
//		"계좌 이체"
//		"종     료"
//		"업무 종료"		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	public static void main(String[] args) {
		new UI3();
	}
	
	class Create {
		Scanner scanner = new Scanner(System.in);
//		Member[] member = new Member[100];
		ArrayList<Member> member = new ArrayList<>();
		int idx;
		int cnt = 267100;
		
		public Member logIn() {				//////// 로그인할때 인덱스값을 같이 날릴까???
			System.out.print("계좌 번호를 입력하세요.");
			int inputAcc = scanner.nextInt();
			System.out.print("비밀 번호를 입력하세요.");
			String inputPw = scanner.next();
				for (int i = 0; i < member.size(); i++) {
					if (member.get(i).getAccount() == inputAcc) {
						if (member.get(i).getPw().equals(inputPw)) {
							idx = i;
							return member.get(i);
						} //else {	System.out.println("비번 틀림");	}
					} //else {	System.out.println("아이디 틀림");		}
				}
				System.out.println("계좌번호와 비밀번호를 확인하세요.");
				return null;
		}

		public Member creatAccount() {
			System.out.println("이름을 입력하세요.");
			String name = scanner.next();
			System.out.println("비밀번호를 입력하세요.");
			String pw = scanner.next();
			member.add(new Member(cnt, name, pw));
			member.get(idx).info();
			idx++;
			cnt++;
			return null;
		}
		
		public Member accountTransfer(int x) {
			System.out.println("이체할 대상의 계좌번호를 입력하세요.");
			int targetAcc = scanner.nextInt();
			System.out.println("이체할 금액를 입력하세요.");
			int transferMoney = scanner.nextInt();
			for (int i = 0; i < member.size(); i++) {
				if (member.get(i).getAccount() == targetAcc) {
					member.get(i).deposit(transferMoney);
//						System.out.println("대상자 "+ member[i].getName() + "님께 송금합니다.");
					member.get(x-267100).transfer(transferMoney);
					System.out.println(member.get(x-267100).getAccount() + "님께 " + transferMoney + "원 송금완료");
				}
			}
			return member.get(x-267100);
		}
		
		public void logInMenu() {
			boolean run = true;
			do {
				System.out.println();
				System.out.println("-------------------------------");
				System.out.println(" 1. 은행업무 | 2. 계좌생성 | 3. 종료 ");
				System.out.println("-------------------------------");
				System.out.print("선택 > ");
				int num = scanner.nextInt();

				switch (num) {
				case 1:
					Member member =	logIn();
					if (member != null) {
						bankMenu(member);
					}
					break;
				case 2:
					creatAccount();
					break;
				case 3:
					run = false;
					break;
				default:
					System.out.println("잘못입력했습니다");
				}
			} while (run);
		}
		
		public Member bankMenu(Member member) {
			boolean run = true;
			do {
				System.out.println();
				System.out.println(" " + member.getName() + "님 로그인중 ");
				System.out.println("-------------------------------------------");
				System.out.println(" 1. 입금 | 2. 출금 | 3. 잔고 | 4. 이체 | 5. 종료 ");
				System.out.println("-------------------------------------------");
				System.out.print("선택 > ");

				int main = scanner.nextInt();

				switch (main) {
				case 1:
					System.out.println("입금할 금액을 입력하세요.");
					int money = scanner.nextInt();
					member.deposit(money);
					break;
				case 2:
					System.out.println("출금할 금액을 입력하세요.");
					money = scanner.nextInt();
					member.withDraw(money);
					break;
				case 3:
					member.balance();
					break;
				case 4:
					accountTransfer(member.getAccount());
					break;
				case 5:
					run = false;
					break;
					
				default:
					System.out.println("잘못입력했습니다.");
				}

			} while (run);
			return member;

		}
		
	}
	
	

}
