package app.bankproject.UI;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import app.bankProject.ver3.CreateAccMenu2;

public class UI_only2 extends JFrame implements ActionListener{
	Toolkit toolkit = Toolkit.getDefaultToolkit();
	public JPanel jp1, jp2, jp3, jp4;
	public JButton bt1, bt2, bt3, bt4, bt5, bt6, btLogIn, btExit;
	public JTextArea ta;
	int pWidth = 500, pHeight = 380;
	public UI_only2() {
		jp1 = new JPanel();	// west
		jp2 = new JPanel();	// center
		jp3 = new JPanel(new BorderLayout()); 	// east
		jp4 = new JPanel(new FlowLayout()); 	// south
		
		bt1 = new JButton("입  금");
		bt1.setBounds(20, 20, 100, 50);
		bt2 = new JButton("출  금");
		bt2.setBounds(20, 100, 100, 50);
		bt3 = new JButton("예금조회");
		bt3.setBounds(20, 180, 100, 50);
		add(bt1);	add(bt2);	add(bt3);
		
		ta = new JTextArea();
		ta.setEditable(false);
		ta.setBounds(140, 20, 210, 230);
		add(ta);
		
		bt4 = new JButton("계좌 이체");
		bt4.setBounds(370, 20, 100, 50);
		bt5 = new JButton("공 사 중");
		bt5.setBounds(370, 100, 100, 50);
		bt6 = new JButton("계좌 개설");
		bt6.setBounds(370, 180, 100, 50);
		add(bt4);	add(bt5);	add(bt6);
		
		btLogIn = new JButton("로 그 인");
		btLogIn.setBounds(140, 270, 100, 50);
		btExit = new JButton("종   료");
		btExit.setBounds(250, 270, 100, 50);
		add(btLogIn); add(btExit);

		JLabel imgLabel = new JLabel(), imgLabel2 = new JLabel();
		ImageIcon icon = new ImageIcon(UI_only2.class.getResource("bank-transfer.png"));
		Image img = icon.getImage();
	    Image updateImg = img.getScaledInstance(100, 70, Image.SCALE_SMOOTH);
	    ImageIcon updateIcon = new ImageIcon(updateImg);
	    ImageIcon updateIcon2 = updateIcon;
        imgLabel.setIcon(updateIcon);
        imgLabel2.setIcon(updateIcon2);
        imgLabel.setBounds(20, 220, 165, 150);
		add(imgLabel);
		imgLabel2.setBounds(370, 220, 165, 150);
		add(imgLabel2);
		
		setLayout(null);
		setSize(pWidth, pHeight);
		setVisible(true);
		
		bt1.addActionListener(this);
		bt2.addActionListener(this);
		bt3.addActionListener(this);
		bt4.addActionListener(this);
		bt5.addActionListener(this);
		bt6.addActionListener(this);
		btExit.addActionListener(this);
		btLogIn.addActionListener(this);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		CreateAccMenu2 createAccMenu2 = new CreateAccMenu2();
		Object obj = e.getSource();
		if (obj == bt1) {
			toolkit.beep();
			ta.setText(" << 입금을 선택하셨습니다. >>");
		} else if (obj == bt2) {
			toolkit.beep();
			ta.setText(" << 출금을 선택하셨습니다. >>");
			
		} else if (obj == bt3) {
			toolkit.beep();
			ta.setText(" << 조회를 선택하셨습니다. >>");
		} else if (obj == bt4) {
			toolkit.beep();
			ta.setText(" << 계좌이체를 선택하셨습니다. >>");
		} else if (obj == bt5) {
			toolkit.beep();
			ta.setText(" << 서비스 준비중 >>");
			
		} else if (obj == bt6) {
			toolkit.beep();
			ta.setText(" << 계좌 개설을 선택하셨습니다. >>");
		}
	}

	public static void main(String[] args) {
		new UI_only2();
	}

}
