package app.bankProject.ver1;

public class Menu {

}
