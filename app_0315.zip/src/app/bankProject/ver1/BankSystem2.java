package app.bankProject.ver1;

import java.util.Scanner;

public class BankSystem2 {
	public static void main(String[] args) {
		Member[] member = new Member[3];
		int cnt = 256001;
		for (int i = 0; i < member.length; i++) {
			member[i] = new Member(cnt);
			member[i].setAccount(cnt);
			cnt++;
		}
		/* 졔좌번호를 가지는 객체가 생성되었나 확인하는 반복작업
		 * for (member member2 : member) {
			System.out.println(member2.getName());
		}*/
		
//		menu(member);
	}


/*
	public static member menu(member[] member) {
		Scanner scanner = new Scanner(System.in);
		boolean run = true;
		do {
			System.out.println("--------------------------------");
			System.out.println(" 1. 은행업무 | 2. 계좌생성 | 3. 종료 ");
			System.out.println("--------------------------------");
			System.out.print("선택 > ");
			int mainMenu = scanner.nextInt();
			
			switch (mainMenu) {
			case 1:
				System.out.println("계좌 번호 입력");
				String account = scanner.nextLine();
				int scanner2 = scanner.nextInt();
				System.out.println("비밀 번호 입력");
				String passward = scanner.nextLine();
				for (int i = 0; i < 10; i++) {
					if ((member[i].account == account) && (member[i].passward == passward)) {
						return member[i];
					} else break;
				}
				break;
			case 2:
				System.out.println("생성할 계좌 명의자 이름을 입력하세요: ");
				String name = new Scanner(System.in).nextLine();
				System.out.println("생성할 계좌번호를 입력하세요: ");
				scanner.nextLine();
				account = scanner.nextLine();
				System.out.println("생성할 계좌의 비밀번호를 입력하세요: ");
				passward = scanner.nextLine();
				//member member = new member();
				
				break;
			case 3:
				System.exit(0);
//				break;

			default:
				System.out.println("잘 못 입력하셨습니다.");
			}
			} while (run);
			
			
		}*/ 
	}
