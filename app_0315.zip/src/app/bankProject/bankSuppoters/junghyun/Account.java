package app.bankproject.bankSuppoters.junghyun;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class Account {
    private String name;
    private String id;   // id
    private int number;   // 계좌번호
    private String password;
    private int balance;
    private List<String> history;

    private final DecimalFormat df = new DecimalFormat("###,###");

    public int getBalance() {
        return balance;
    }

    public int getNumber() {
        return number;
    }

    public List<String> getHistory() {
        return history;
    }

    public void setPlusBalance(int balance) {
        this.balance += balance;
    }

    public Account(String name, String id, String password, int number) {
        this.name = name;
        this.id = id;
        this.password = password;
        this.number = number;
        this.history = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String info(){
        return "이름: " + name + ", 계좌번호: "+ number;
    }

    public boolean deposit(int money){
        if(money <= 0 || money % 1000 != 0){
            System.out.println("금액을 정확하게 입력하세요.");
            return false;
        }
        this.balance += money;
        this.history.add(formattingMoney(money)+"원 입금\n");
        return true;
    }
    public boolean withdraw(int money){
        if(money > balance){
            System.out.println("잔액이 부족합니다.");
            return false;
        }else if(money < 0){
            System.out.println("0원 및 마이너스 단위는 출금하실 수 없습니다.");
            return false;
        }else if(money % 1000 != 0){
            System.out.println("1000원 단위로 입력해주세요.");
            return false;
        }
        this.balance -= money;
        this.history.add(formattingMoney(money)+"원 출금\n");
        return true;
    }

    public boolean wireTransfer(Account receiveAccount, int money) {
        if(money > balance){
            System.out.println("잔액이 부족합니다.");
            return false;
        }else if(money < 0){
            System.out.println("0원 및 마이너스 단위는 출금하실 수 없습니다.");
            return false;
        }else if(money % 1000 != 0){
            System.out.println("1000원 단위로 입력해주세요.");
            return false;
        }
        this.balance -= money;
        receiveAccount.setPlusBalance(money);
        this.history.add(receiveAccount.getName()+"님에게 "+formattingMoney(money)+"원 송금\n");
        receiveAccount.history.add(this.getName()+"님으로부터 "+formattingMoney(money)+"원 입금\n");
        return true;
    }

    public String formattingMoney(int money){
        return df.format(money);
    }
}
