package app.bankproject.bankSuppoters.minggu;

import java.util.Scanner;

public class BankMenu {
	int menuNum, money, account;
	Scanner sc = new Scanner(System.in);
	LoginSystem ls = new LoginSystem();
	Member m;
	boolean run =true;
	
	public BankMenu() {
	}
	public BankMenu(Member selecMember) {
		this.m = selecMember;
	}
	void menu() {
		while (run) {
			System.out.println("1. 입금 | 2. 출금 | 3. 계좌이체 | 4. 잔고 | 5. 로그아웃");
			menuNum =sc.nextInt();
			switch (menuNum) {
			case 1:
				System.out.print("입금액 >");
				money = sc.nextInt();
				if (money > 999) {
					System.out.println("입금 완료");
					m.deposit(money);
				}
				else if (money < 1000) {
					System.out.println(" 1000원 미만 금액 입금 불가");
				}
				break;
			case 2:
				System.out.print("출금액 >");
				money = sc.nextInt();
				if (money > 999) {
					System.out.println("출금 완료");
					m.withDraw(money);
				}
				if (money < 1000) {
					System.out.println(" 1000원 미만 금액 출금 불가");
				}
				if (money > m.getMoney()) {
					System.out.println(" 잔고 부족 ");
				}
				break;
			case 3:
				System.out.println("계좌번호 입력");
				account = sc.nextInt();
				for(int i = 0 ; i < ls.member.size() ; i++) {
					
//					if(account == (ls.member.get(i).getAccount())) {
//						System.out.println("이체 하실 금액 입력");
//						money = sc.nextInt();
//						m.withDraw(money);
//						ls.member.get(i).deposit(money);
//						System.out.println(ls.member.get(i).getName()+"님 계좌로 이체완료");
//						run =false;
						System.out.println(ls.member.get(i).getAccount());
//					}
				}
				if(run) {
					System.out.println("계좌 불일치");
				break;
				}
				break;
			case 4:
				System.out.println(m.getMoney()); 
				break;
			case 5:
				System.out.println("로그아웃 완료");
				run = false;
				break;
			default:
				System.out.println("메뉴 확인 해주세요");
			}
		}
	}
//	public static void main(String[] args) {
//		LoginSystem lss = new LoginSystem();
//		for(int i = 0; i < lss.member.size(); i++) {
//			
//		}
//	}
}
