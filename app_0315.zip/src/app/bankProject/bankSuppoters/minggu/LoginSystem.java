package app.bankproject.bankSuppoters.minggu;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class LoginSystem {
	String name, id, pw;
	Scanner sc = new Scanner(System.in);
	int account = 10001;
	boolean run = false;
	ArrayList<Member> member = new ArrayList<>();
	// 여기있는 어드민 계정 생성을 빼서
	Date now = new Date();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh-MM-ss");

	void sdf() {
		sdf.format(now);
	}

	public void creatAccount() { // 스위치 1 회원가입 메소드 만들기
		System.out.println("아이디 입력");
		id = sc.next();
		// 중복검사
		for (int i = 0; i < member.size(); i++) {
			if (id.equals(member.get(i).getId())) {
				System.out.println("중복");
				return;
			}
		}
		System.out.println("사용가능한 아이디");
		System.out.println("패스워드 입력");
		pw = sc.next();
		System.out.println("이름 입력");
		name = sc.next();

		member.add(new Member(id, pw, name, account));
		System.out.println(name + "님 회원가입완료..\n" + "아이디 :" + id + "\n비번 :" + pw + "\n계좌번호 :" + account);
		account++;
	}

	public void loginAccount() {
		System.out.println("아이디 입력");
		id = sc.next();
		System.out.println("비번 입력");
		pw = sc.next();
		for (int i = 0; i < member.size(); i++) {
			if (id.equals(member.get(0).getId()) && pw.equals(member.get(0).getPw())) {
				System.out.println("관리자 로그인");
				run = true;
				break;
			} else if (id.equals(member.get(i).getId()) && pw.equals(member.get(i).getPw())) {
				System.out.println(member.get(i).getName() + "님 로그인 완료");
				Member selecMember = member.get(i);
				BankMenu bankMenu = new BankMenu(selecMember);
				bankMenu.menu();
				run = true;
				break; // 뱅크 메뉴로
			}
		}
		if (!run) {
			System.out.println("오기재");
		}
	}

	public void information() {
		for (int i = 0; i < member.size(); i++) {
			System.out.println(member.get(i).getId() + " , " + member.get(i).getAccount());
		}
	}
}
