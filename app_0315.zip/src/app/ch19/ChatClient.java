package app.ch19;

import java.awt.BorderLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ChatClient extends JFrame implements Runnable, ActionListener{
	private BufferedReader i;
	private PrintWriter o;
	private JTextArea output;
	private JTextField input;
	private JLabel label;
	private Thread listener;
	private String host;
	JScrollPane jp;
	JScrollBar jb;
	
	public ChatClient(String server) {
		super("채팅 프로그램");
		host = server;
		listener = new Thread(this);
		listener.start();
		output = new JTextArea();
		
		jp = new JScrollPane();
		jb = jp.getVerticalScrollBar();		// 스크롤바를 따로 운영하기 위한 변수 지정
		add(jp, "Center");
		add(new JScrollPane(output), "Center");	// 미션! 스크롤바를 생성하라!!
		output.setEditable(false);
		Panel bottom = new Panel(new BorderLayout());
		label = new JLabel("사용자 이름");
		bottom.add(label, "West");
		input = new JTextField();
		input.addActionListener(this);
		bottom.add(input, "Center");
		add(bottom, "South");
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(400, 300);
		setVisible(true);
	}
	@Override
	public void run() {
		try {
			Socket s = new Socket(host, 7979);
			InputStream ins = s.getInputStream();
			OutputStream os = s.getOutputStream();
			i = new BufferedReader(new InputStreamReader(ins));
			o = new PrintWriter(new OutputStreamWriter(os), true);
			
			// 서버에서 보내는 메시지 출력을 위한 스레드~~~~~~~
			while (true) {
				String line = i.readLine();
				output.append(line + "\n");
				// 스크롤바의 최대값 가져오기	아래일때 최대값이다.
				jb.setValue(jb.getMaximum());	// 메시지가 갱신될때마다 맥스값도 갱신
			}
			
		} catch (IOException ex) {	}
	}
	
	// 메시지 전송단.
	@Override
	public void actionPerformed(ActionEvent e) {
		Object c = e.getSource();
		if (c == input) {
			label.setText("메시지");
			o.println(input.getText());
			input.setText("");					// 메시지 전송후 textfield 지우기
		}
	}

	public static void main(String[] args) {
		if (args.length > 0) {
			new ChatClient(args[0]);
		}else {
			new ChatClient("localhost");
		}
	}
}

/*
 * 채팅 스크롤 이동
 * 익명 접근 불가
 * null 값. 어쩔?
 * 사용자 목록 보기
 * 
 * 
 * 
 * 채팅 심화
 * 메신저의 근간이 되어지는 문제
 * 사용자 정의 프로토콜을 정의 해야한다. (tcp, udp 같은)
 * 귓속말, 이미지 보내기와 같은.
 * 
 * 
 * 
*/
