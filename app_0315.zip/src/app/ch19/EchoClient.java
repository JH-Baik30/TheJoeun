package app.ch19;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

public class EchoClient {
	private Socket socket;
	public EchoClient(String host, int port) throws Exception{
		socket = new Socket(host, port);
	}
	
	public void echo() throws IOException{
		OutputStream os = socket.getOutputStream();
		InputStream is = socket.getInputStream();
		BufferedReader in = new BufferedReader(new InputStreamReader(is));	// 데이터 입력
		PrintWriter out = new PrintWriter(os, true);		// true -> autoFlush 데이터 출력
		BufferedReader con = new BufferedReader(
						new InputStreamReader(System.in));
		
		while (true) {
			String msg = con.readLine();
			out.println(msg);
			if(msg.equals("bye")) {
				break;
			}
			System.out.println(in.readLine());		// 서버에서 데이터가오면 데이터를 읽어들일 준비
		}
	}
	
	public void close() throws IOException{
		socket.close();
	}
	
	public static void main(String[] args) {
		try {
			EchoClient ec;
			System.out.println("메시지를 입력하세요");
			if (args.length > 0) {						// args 의 길이가 1 이상이면
				ec = new EchoClient(args[0], 1289);		// 
			} else {
				ec = new EchoClient("localhost", 1289);	// 내 pc로 접속하겠다. localhost는 내 pc의 ip이다.
			}
			
			ec.echo();
			ec.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
