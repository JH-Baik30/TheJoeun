package app.ch20;

public class DBEx {
	public static void main(String[] args) {
		String driver = "com.mysql.cj.jdbc.Driver";
		try {
			Class.forName(driver);
			System.out.println("데이터베이스 드라이버 로딩성공!");
		} catch (Exception e) {
			System.out.println("데이터베이스 드라이버 로딩실패!");
		}
	}
}
