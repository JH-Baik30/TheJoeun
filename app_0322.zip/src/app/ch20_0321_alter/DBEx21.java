package app.ch20_0321_alter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/*
	[형식]				[설명]
	컬럼명 LIKE '%CD%'		컬럼값 중 CD가 포함된 문자열 모두
		 LIKE 'CD%'
		 LIKE 'C%D'
	
		 LIKE '_CD_'		컬럼값 자리수가 4자리이고 1번째, 4번째 자리값은
						무엇이든 상관없고, 2~3번째에 CD가 들어간 문자열
	
	[실습테이블 만들기] : LSTEST
		CREATE TABLE LSTEST(
			PHONE VARCHAR(15),
			NAME VARCHAR(10));
	[레코드 추가]
		INSERT INTO LSTEST VALUES('011-1234-5678', '홍길동');
		INSERT INTO LSTEST VALUES('011-1234-5678', '이순신');
		INSERT INTO LSTEST VALUES('010-1234-5678', '만득이');
		INSERT INTO LSTEST VALUES('010-1234-5678', '개똥이');
		INSERT INTO LSTEST VALUES('010-1234-5678', '칠득이');
		INSERT INTO LSTEST VALUES('070-1234-5678', '갑돌이');
	
*/	
public class DBEx21 {
	public static void main(String[] args) {
		Connection conn = DBAction.getInstance().getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		try {
//			String sql = createTable();
//			String sql = insert();
			String sql = delete();
			stmt = conn.createStatement();
			int result = stmt.executeUpdate(sql);
			String msg = result > -1 ? "성공" : "실패";
			System.out.println(msg);
			
//			Query
/*			String sql = select();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				String columnName = rsmd.getColumnName(i);
				System.out.print(columnName + "\t");
			}
			System.out.println("\n---------------------------------");
			
			while (rs.next()) {
				for (int i = 1; i <= cols; i++) {
					System.out.print(rs.getString(i) + "\t");
				}
				System.out.println();
			}
*/						
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	
	public static String createTable() {
		String sql = "CREATE TABLE LSTEST("
					+ "PHONE VARCHAR(15), "
					+ "NAME VARCHAR(10))";
		return sql;
	}
	
	public static String insert() {
//		String sql = "INSERT INTO LSTEST VALUES('011-1234-5678', '홍길동')";
//		String sql = "INSERT INTO LSTEST VALUES('011-1234-5678', '이순신')";
//		String sql = "INSERT INTO LSTEST VALUES('010-1234-5678', '만득이')";
//		String sql = "INSERT INTO LSTEST VALUES('010-1234-5678', '개똥이')";
//		String sql = "INSERT INTO LSTEST VALUES('010-1234-5678', '칠득이')";
		String sql = "INSERT INTO LSTEST VALUES('070-1234-5678', '갑돌이')";
		return sql;
	}
	
	public static String select() {
//		Ex1)
//		String sql = "SELECT PHONE, NAME FROM LSTEST WHERE PHONE LIKE '%011'";
//		Ex2)
//		String sql = "SELECT PHONE, NAME FROM LSTEST WHERE PHONE LIKE '011%'";
//		Ex3)
//		String sql = "SELECT PHONE, NAME FROM LSTEST WHERE PHONE LIKE '%070%'";
//		Ex4)
//		String sql = "SELECT PHONE, NAME FROM LSTEST WHERE PHONE LIKE '0%8'";
//		Ex5)
//		String sql = "SELECT PHONE, NAME FROM LSTEST WHERE NAME LIKE '_순_'";
//		Ex6)
//		String sql = "SELECT PHONE, NAME FROM LSTEST WHERE NAME LIKE '칠__'";
//		Ex7)
//		String sql = "SELECT PHONE, NAME FROM LSTEST WHERE NAME LIKE '__이'";
//		Ex8)
		String sql = "SELECT PHONE, NAME FROM LSTEST WHERE NAME LIKE '갑_이'";
		return sql;
	}
	
	public static String delete() {
		String sql = "DELETE FROM LSTEST WHERE NAME='갑돌이'";
		return sql;
				
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
