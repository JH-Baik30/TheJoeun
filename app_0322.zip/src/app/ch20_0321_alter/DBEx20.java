package app.ch20_0321_alter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * 그룹화하여 데이터 조회 ( GROUP BY )
 * 	 : 대표적인 그룹 함수 COUNT( ), AVG( ), MIN( ), MAX( ), SUM( ) 함수 등과,
 *		HAVING 절(조건절)을 사용함.
 *		[연습 테이블 만들기] : GBTEST
 *		CREATE TABLE GBTEST(
 *			IDX	 INT,
 *			TYPE INT,
 *			NAME VARCHAR(10));
 *		[레코드 추가]
 *		INSERT INTO GBTEST VALUES(1, 1, '홍길동');
 *		INSERT INTO GBTEST VALUES(2, 1, '이순신');
 *		INSERT INTO GBTEST VALUES(3, 2, '만득이');
 *		INSERT INTO GBTEST VALUES(4, 2, '개똥이');
 *		INSERT INTO GBTEST VALUES(5, 3, '칠득이');
 *		INSERT INTO GBTEST VALUES(6, 3, '갑돌이');
 *		INSERT INTO GBTEST VALUES(7, 4, '갑순이');
 *		ex1) 유형(type)별로 갯수를 가져오고 싶은데, 단순히 COUNT 함수로 데이터를 조회하면 전체 갯수만을 가져옵니다.
 *		select count(ID) from tablename
 *		ex2) 컬럼 그룹화 : type 그룹화하여 name 갯수 조회 (컬럼 그룹화)
 *		ex3) type 1 초과인, type 그룹화하여 name 갯수 조회 (조건 처리 후 컬럼 그룹화);
 *		ex4) type 1 초과인, type 그룹화하여 name 갯수르르 가져온 후, 그 중에 갯수가 2개
 *  				이상인 데이터 조회 (조거 ㄴ처리 후에 컬럼 그룹화 후에 조건 처리)
 *		HAVING 사용
 *		연습문제)type 1 초과인, type 그룹화하여 name 갯수를 가져온 후,
 *  			그 중에 갯수가 2개 이상인 데이터를 type 내림차순 정렬로 조회 (내림차순 정렬)
 */
public class DBEx20 {
	public static void main(String[] args) {
		Connection conn = DBAction.getInstance().getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		try {
//			String sql = createTable();
/*			String sql = insert();
			stmt = conn.createStatement();
			int result = stmt.executeUpdate(sql);
			String msg = result > -1 ? "성공" : "실패";
			System.out.println(msg);
*/			
//			Query
			String sql = select();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				String columnName = rsmd.getColumnName(i);
				System.out.print(columnName + "\t");
			}
			System.out.println("\n---------------------------------");
			
			while (rs.next()) {
				for (int i = 1; i <= cols; i++) {
					System.out.print(rs.getString(i) + "\t");
				}
				System.out.println();
			}
						
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	
	public static String createTable() {
		String sql = "CREATE TABLE GBTEST(IDX INT, "
							+ "TYPE INT, NAME VARCHAR(10))";
		return sql;
	}
	
	public static String insert() {
//		String sql = "INSERT INTO GBTEST VALUES(1, 1, '홍길동')";
//		String sql = "INSERT INTO GBTEST VALUES(2, 1, '이순신')";
//		String sql = "INSERT INTO GBTEST VALUES(3, 2, '만득이')";
//		String sql = "INSERT INTO GBTEST VALUES(4, 2, '개똥이')";
//		String sql = "INSERT INTO GBTEST VALUES(5, 3, '칠득이')";
//		String sql = "INSERT INTO GBTEST VALUES(6, 3, '갑돌이')";
		String sql = "INSERT INTO GBTEST VALUES(7, 4, '갑순이')";
		return sql;
	}
	
	public static String select() {
//		ex1)
//		String sql = "SELECT COUNT(TYPE) FROM GBTEST";
//		ex2)
//		String sql = "SELECT TYPE, COUNT(NAME) AS CNT FROM GBTEST GROUP BY TYPE";
//		String sql = "SELECT TYPE, COUNT(NAME) AS CNT FROM GBTEST WHERE TYPE > 1 GROUP BY TYPE";
//		String sql = "SELECT TYPE, COUNT(NAME) AS CNT FROM GBTEST"
//				+ " WHERE TYPE > 1 GROUP BY TYPE"
//				+ " HAVING CNT >= 2";
		String sql = "SELECT TYPE, COUNT(NAME) AS CNT FROM GBTEST"
				+ " WHERE TYPE > 1 GROUP BY TYPE"
				+ " HAVING CNT >= 2 ORDER BY type DESC ";
		return sql;
// 실습과졔> 뱅크 사용자(회원) 회원등급별로 일반회원초과 회원의 생년월일(인원파악)을 출력하시오.(기념일)		

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
