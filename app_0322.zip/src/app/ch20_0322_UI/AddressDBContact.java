package app.ch20_0322_UI;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;

public class AddressDBContact {
	ArrayList<String> arr = new ArrayList<>();
	
	public ArrayList<String> contactDB (){
		Connection conn = DBAction.getInstance().getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		try {
			String sql = getsido();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
//			for (int i = 1; i <= cols; i++) {
//				String columnName = rsmd.getColumnName(i);
//				System.out.print(columnName + "\t");
//			}
//			System.out.println("\n----------------------------------------------");
			
			while (rs.next()) {
				for (int i = 1; i <= cols; i++) {
					arr.add(rs.getString(i));
//					System.out.print(rs.getString(i) + " ");
				}
//				System.out.print("");
			}
			return arr;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs !=  null) rs.close();
				if (stmt != null) stmt.close();
				if (conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return null;
	}
	
	public static String getsido() {
		String sql = "SELECT distinct sido FROM zipcode";
		return sql;
	}
	
	
	
	
	
	
	
	
	
	
}
