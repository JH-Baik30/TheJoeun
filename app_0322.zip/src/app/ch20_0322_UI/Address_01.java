package app.ch20_0322_UI;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JComboBox;

public class Address_01 extends Frame{
	public Panel p1, p2, p3, p4;
	Label sidoLb, gugunLb, jusoLb;
	JComboBox<String> sidoCb; JComboBox<String> gugunCb;
	TextField sidoTf, gugunTf, jusoTf;
	Button searchBt, cancelBt, saveBt;
	public Address_01 () {
		p1 = new Panel(); p2 = new Panel(); p3 = new Panel(); p4 = new Panel();
		sidoLb = new Label("시도"); gugunLb = new Label("시군구"); jusoLb = new Label("주소");
		
		p2.add(sidoLb);		p2.add(jusoLb);
		p3.add(cancelBt);
		
		add(p1, BorderLayout.NORTH);
		add(p2, BorderLayout.WEST);
		add(p3, BorderLayout.CENTER);
		add(p4, BorderLayout.EAST);
		setTitle("주소검색");
		setSize(300, 300);
		setVisible(true);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}			
		});
	}
	public static void main(String[] args) {
		new Address_01();
	}
}
