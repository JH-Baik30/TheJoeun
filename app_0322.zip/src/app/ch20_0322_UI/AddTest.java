package app.ch20_0322_UI;

import java.util.ArrayList;

public class AddTest {
	public static void main(String[] args) {
		AddressDBContact adbc = new AddressDBContact();
		ArrayList<String> sido = adbc.contactDB();
		for (String string : sido) {
			System.out.print(string + " ");
		}
	}
}
