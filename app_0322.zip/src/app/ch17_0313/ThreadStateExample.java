// 1-3
package app.ch17_0313;

public class ThreadStateExample {
	public static void main(String[] args) {
		StatePrintThread statePrintThread = 
				new StatePrintThread(new TargetThread());
		statePrintThread.start();
	}
}
