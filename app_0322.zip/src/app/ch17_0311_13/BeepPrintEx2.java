package app.ch17_0311_13;

public class BeepPrintEx2 {
	public static void main(String[] args) {
		Thread thread = new BeepThread();
		thread.start();
		for (int i = 0; i < 5; i++) {
			System.out.println("띵");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
