package app.bankProject.ver6_DB1;

public class DBadmin {
public static void main(String[] args) {
	DBmanagement dbm = new DBmanagement();
	int acc = 267100;
	String name = "aaa";
	String pw = "123";
	dbm.insertToDB(acc, name, pw);
	
//	dbm.deleteToDB(acc);
}
}
