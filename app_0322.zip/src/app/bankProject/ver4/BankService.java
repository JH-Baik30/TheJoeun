package app.bankProject.ver4;

import java.io.IOException;

public class BankService {
	public static void main(String[] args) {
		CreateAccMenu2 bankGo = new CreateAccMenu2();
		try {
			bankGo.logInMenu();
		} catch (IOException e) {
			e.printStackTrace();
		}			
	}
}
