// DB control tester
package app.bankProject.ver6_DB3;

import java.sql.SQLException;
import java.util.ArrayList;

public class DBadmin {
public static void main(String[] args) throws InterruptedException, SQLException {
	DBmanagement dbm = new DBmanagement();
	int acc = 12300;
	int[] arr = new int[10];
	for (int i = 0; i < arr.length; i++) {
		arr[i] = acc++; 
	}
	String name = "aaa";
	String pw = "123";
	String sql;
//	dbm.insertToDB(acc, name, pw);
	
//	sql = "INSERT INTO BANKDB VALUES(1234, 'aaa', '123', 10, NOW())";
//	sql = "INSERT INTO BANKDB VALUES(1234, 'aaa', '123', 10, NOW())";
//	sql = "INSERT INTO DBTEST3 VALUES('bbb', '111', 10, NOW())";
	
/*	for (int i = 0; i < 5; i++) {
		sql = "INSERT INTO BANKDB VALUES(" + 1230 + i +", 'aaa', '" + 1443+i+3 + "', " + i+5 + ", NOW())";
//		sql = "UPDATE BANKDB SET Balance=" + arr[6]
//				+ ", create_date=NOW() WHERE Account="+ acc +"'" ;
//		sql = "UPDATE DBTEST2 SET ID='A', PASSWORD='1' WHERE ID='Z'";
		dbm.sqlTestMethod(sql);
//		Thread.sleep(1000);
		
		System.out.println(arr[i]);
	}*/	
	
/*	//	DB 삭제
	for (int i = 0; i < 10+1; i++) {
		dbm.deleteToDB("aaa");
	}	*/
		
//  앱 종료시 전체 객체를 DB 에 올리기 할때 반복문을 사용하면 마지막 값으로 전부 저장되버림.		
/*	앱 실행시 전체 DB 가져오기 TEST 중 문제!!!
 * 		DBDBmanagement.readfromDB() 에서 rfDB의 내용 자체를 못 받아온다.
 * 		아래 코드 실행시 반환값은
 * 		Result set representing update count of 10 * 
 */

/*	// DB에서 하나하나 가져오기 #1
		ArrayList<Member> members = dbm.readfromDB();
		for (int i = 0; i < members.size(); i++) {
			if (members != null) {
				System.out.println(members.get(i).getAccount()
						+ " : "+ members.get(i).getName());
			}			
		}
*/	// #1 까지
	
//		ArrayList<Member> members = new ArrayList<>();
//		System.out.println(rs);
//		while (rs.next()) {
//			System.out.println(rs);
//		}
		
//		System.out.println(.getString("name"));
		
//		while (rs.next()) {
//			members.add(new Member().setAccount(rs.getInt("account"))
//									.setName(rs.getString("Name"))
//									.setPw(rs.getString("Pw"))
//									.setBalance(rs.getInt("Balance")));
//		}
	}
}
