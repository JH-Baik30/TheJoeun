package app.ch03_0224;

public class JavaTest {
	public static void main(String[] args) {
		System.out.println("자바테스트");
	}
}
