package app.ch07_0227_28.methodEx;

public class MethodEx {
//[접근 제어자] - private, default, protected, public
//[수정자] - static, final, abstract, native....
//[반환형] - (return type), void

	public static int intA() {
		System.out.println("A");
		return 10;
	}

	public static void intB(int a) {
		System.out.println("B");
	}

	public static int intC(int su, int su2) {
		int result = su;
		result += su2;
		return result;
	}

	public static void main(String[] args) {
		int result = intA();
		System.out.println(result);
		intB(50);
		result = intC(10, 20);
		System.out.println(result);
	}

}
