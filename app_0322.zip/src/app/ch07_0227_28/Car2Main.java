package app.ch07_0227_28;

public class Car2Main {

}
