package app.ch20_0315_17;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBEx2 {
	public static void main(String[] args) {
		String driver = "com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/app";
//											port no, 
//		String url = "jdbc:oracle:thin:@localhost:1521:orcl";	// Oracle
//					       데이터베이스 연결           포트,system ID
		Connection conn = null;			// DB에 연결되는 객체 생성. 객체가 생성되면 연결된것.
		
		try {
			Class.forName(driver);
			System.out.println("데이터베이스 드라이버 로딩성공!");
			conn = DriverManager.getConnection(url, "root", "java");	
			// .getConnection -> 드라이버 연결 메소드
			System.out.println("데이터베이스 연결성공!");
		} catch (ClassNotFoundException e) {
			System.out.println("데이터베이스 드라이버 로딩실패!");
		} catch (SQLException e) {
			System.out.println("데이터베이스 연결실패!");
		} finally {
			try {
				if(conn != null) conn.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
	}
}
