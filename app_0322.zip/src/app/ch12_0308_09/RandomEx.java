package app.ch12_0308_09;

import java.util.Random;

public class RandomEx {
	public static void main(String[] args) {
		Random ran = new Random();
		// way1
		int su = ran.nextInt(3);
		int su2 = (int) (Math.random() * 3);
		int su3 = (int) (Math.random() * 45 + 1);
//		System.out.println(su3);
		// lo[0] = 32;
//		System.out.println(lo[0]);

		int[] temp = new int[6];
		for (int i = 0; i < temp.length; i++) {
			temp[i] = ran.nextInt(45) + 1;
			for (int j = 0; j < i; j++) {
				if (temp[i] == temp[j]) {
					temp[i] = ran.nextInt(45) + 1;
					j = -1;
				}
			}
		}

		for (int i : temp) {
			System.out.println(i);
		}

	}
}
