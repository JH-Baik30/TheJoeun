package app.ch12_0308_09.collection;

import java.io.FileReader;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

public class HashMapEx {
	public static void main(String[] args) throws Exception{
		Map<String , String> map = new HashMap<>();
		
		Properties properties = new Properties();
		String path = HashMapEx.class.getResource("database.properties").getPath();
		path = URLDecoder.decode(path, "utf-8");
		properties.load(new FileReader(path));
		String driver = properties.getProperty("driver");
		String url = properties.getProperty("url");
		String username = properties.getProperty("username");
		String password = properties.getProperty("password");
		
		System.out.println("driver : " + driver);
		System.out.println("url : " + url);
		System.out.println("username : " + username);
		System.out.println("password : " + password);
		System.out.println();
		String adminId = properties.getProperty("username");
		String adminPw = properties.getProperty("password");
		
		map.put(adminId, adminPw);
		System.out.println(map.keySet());
//		Enumeration<String> e = map.merge(adminId, adminPw, null)
		
		
	/*	Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("아이디와 비밀번호를 입력해주세요.");
			System.out.print("아이디 : ");
			String id = scanner.next();
			System.out.print("비밀번호 : ");
			String pw = scanner.next();
			if (map.containsKey(id)) {
				if (map.get(id).equals(pw)) {
					System.out.println("로그인 되었습니다.");
					break;
				} else {
					System.out.println("비밀번호를 다시 입력해주세요.;");
				}
			} else {
				System.out.println("입력하신 아이디가 존재하지 않습니다.");
			}
		}
		scanner.close(); */
		// key value 로 가져와보기
		// properties.getproperty 를 foreach로???
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
