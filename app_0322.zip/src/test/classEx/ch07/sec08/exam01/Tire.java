package test.classEx.ch07.sec08.exam01;

public class Tire {
	public void roll() {
		System.out.println("회전합니다.");
	}
}
