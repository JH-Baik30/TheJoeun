package test.classEx.ch07.sec08.exam01;

public class CarExmaple {
	public static void main(String[] args) {
		Car myCar = new Car();
		
		// 필드 다형성
		myCar.tire = new Tire();
		myCar.run();
		
		
		myCar.tire = new HankookTire();
		myCar.run();
		
		myCar.tire = new KumhoTire();
		myCar.run();
		
		// 매개변수 다형성
		HankookTire hanTire = new HankookTire();
		myCar.run(hanTire);
		
		KumhoTire kumTire = new KumhoTire();
		myCar.run(kumTire);
		
	}
}
