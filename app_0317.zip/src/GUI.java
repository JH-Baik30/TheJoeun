
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class GUI {

	// Make the User Interface
	private static JFrame MyJFrame = new JFrame("ATM Machine");
	private static JButton Withdraw = new JButton("Withdraw");
	private static JButton Deposit = new JButton("Deposit");
	private static JButton Transferto = new JButton("Transfer To");
	private static JButton Balance = new JButton("Balance");
	private static JRadioButton Checking = new JRadioButton("Checking");
	private static JRadioButton Savings = new JRadioButton("Savings");
	private static JTextField MyJTextField = new JTextField();
	
	public static void main(String[] args) {
		
		// Basic set of base frame.
		MyJFrame.setLayout(null);
		MyJFrame.setBounds(200,100,300,200);
		MyJFrame.setVisible(true);
		MyJFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Put the functions on the base frame.
		Withdraw.setBounds(40, 10, 100, 30);
		Deposit.setBounds(150, 10, 100, 30);
		Transferto.setBounds(40, 50, 100, 30);
		Balance.setBounds(150, 50, 100, 30);
		Checking.setBounds(50, 80, 80, 30);
		Savings.setBounds(160, 80, 80, 30);
		MyJTextField.setBounds(40, 120, 210, 30);
		MyJFrame.add(Withdraw);
		MyJFrame.add(Deposit);
		MyJFrame.add(Transferto);
		MyJFrame.add(Balance);
		MyJFrame.add(Checking);
		MyJFrame.add(Savings);
		MyJFrame.add(MyJTextField);
		
		// Make the account
		Account CheckingAccount = new Account();
		Account SavingsAccount = new Account();
		
		// Make the Action Listeners.
		Withdraw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{CheckTextField(MyJTextField.getText());
				try
				{WithdrawException(MyJTextField.getText());
				if (CheckingAccount.CheckNumber() == 3)
				{
					try 
					{
						CheckingAccount.CheckWithdraw();
						SavingsAccount.CheckWithdraw();
						CheckingAccount.Decrease(1.5);
						SavingsAccount.Decrease(1.5);
						CheckingAccount.ServiceCharge();
					}
					catch (InsufficientFunds IFe)
					{
						IFe.ServiceCharge();
					}
				}
				try
				{
				if(Checking.isSelected())
					CheckingAccount.Withdraw(Double.parseDouble(MyJTextField.getText()));
				else if(Savings.isSelected())
					SavingsAccount.Withdraw(Double.parseDouble(MyJTextField.getText()));
				}
				catch (InsufficientFunds IFe)
				{
					IFe.Withdraw();
					if(CheckingAccount.CheckNumber() == -1)
					{
						CheckingAccount.Check = 3;
						CheckingAccount.Deposit(1.5);
						SavingsAccount.Deposit(1.5);
					}
				}
				MyJTextField.setText(null);
				}
				catch(InsufficientFunds IFe)
				{
					IFe.Multiple();
				}
				}
				catch(InsufficientFunds IFe)
				{
					IFe.CheckTextField();
				}
			}
		});
		
		Deposit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{CheckTextField(MyJTextField.getText());
				if(Checking.isSelected())
					CheckingAccount.Deposit(Double.parseDouble(MyJTextField.getText()));
				else if(Savings.isSelected())
					SavingsAccount.Deposit(Double.parseDouble(MyJTextField.getText()));
				MyJTextField.setText(null);
				}
				catch(InsufficientFunds IFe)
				{
					IFe.CheckTextField();
				}
			}
		});
		
		Transferto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{CheckTextField(MyJTextField.getText());
				if(Checking.isSelected())
				try
				{
					CheckingAccount.Transferto(Double.parseDouble(MyJTextField.getText()));
					SavingsAccount.Transferfrom(Double.parseDouble(MyJTextField.getText()));
				}
				catch(InsufficientFunds IFe)
				{
					IFe.InsufficientFunds();
					CheckingAccount.Decrease(Double.parseDouble(MyJTextField.getText()));
				}
				if(Savings.isSelected())
				try
				{
					SavingsAccount.Transferto(Double.parseDouble(MyJTextField.getText()));
					CheckingAccount.Transferfrom(Double.parseDouble(MyJTextField.getText()));
				}
				catch(InsufficientFunds IFe)
				{
					IFe.InsufficientFunds();
					SavingsAccount.Decrease(Double.parseDouble(MyJTextField.getText()));
				}
				}
				catch(InsufficientFunds IFe)
				{
					IFe.CheckTextField();
				}
				MyJTextField.setText(null);
			}
		});
		Balance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Checking.isSelected())
					MyJTextField.setText(Double.toString(CheckingAccount.GetFunds()));
				else if(Savings.isSelected())
					MyJTextField.setText(Double.toString(SavingsAccount.GetFunds()));
			}
		});
		
		Checking.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Savings.isSelected())
					Savings.setSelected(false);
				MyJTextField.setText(null);
			}
		});
		
		Savings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Checking.isSelected())
					Checking.setSelected(false);
				MyJTextField.setText(null);
			}
		});
	}
	
	private static void CheckTextField(String TextField) throws InsufficientFunds
	{
		double Check;
		try {
			Check = Double.parseDouble(TextField);
		}
		catch (NumberFormatException e)
		{
			throw new InsufficientFunds();
		}
	}
	
	private static void WithdrawException(String TextField) throws InsufficientFunds
	{
		double 	Check = Double.parseDouble(TextField);
		if((Check%20) != 0)
			throw new InsufficientFunds();
	}
}

class Account {
	
	private double Funds;
	static int Check = 0;
	
	public Account(int Funds)
	{
		this.Funds = Funds;
	}
	
	public Account()
	{
		this.Funds = 0;
	}
	
	double GetFunds()
	{
		return Funds;
	}
	
	void SetFunds(double Funds)
	{
		this.Funds = Funds;
	}
	
	void Decrease(double d)
	{
		this.Funds = Funds - d;
	}
	
	void Withdraw(double withdraw) throws InsufficientFunds
	{
		if(withdraw > Funds)
			throw new InsufficientFunds();
		else{
			Funds = Funds - withdraw;
			Check++;
		}
	}
	
	void Deposit(double deposit)
	{
		Funds = Funds + deposit;
	}
	
	void CheckWithdraw() throws InsufficientFunds
	{
		if(Funds - 1.5 < 0)
			throw new InsufficientFunds();
	}
	
	void Transferfrom(double transferfrom) throws InsufficientFunds
	{
		if(transferfrom > Funds)
			throw new InsufficientFunds();
		else{
			Funds = Funds - transferfrom;
		}
	}
	
	void Transferto(double transferto)
	{
		Deposit(transferto);
	}
	
	static int CheckNumber()
	{
		return Check;
	}
	
	static void ServiceCharge()
	{
		JOptionPane.showMessageDialog(null, "Service charge occurs","Information",JOptionPane.INFORMATION_MESSAGE);
		Check = -1;
	}
}

class InsufficientFunds extends Exception {
	void InsufficientFunds(){
		JOptionPane.showMessageDialog(null, "Funds is insufficient","Error",JOptionPane.ERROR_MESSAGE);
	}
	void ServiceCharge(){
		JOptionPane.showMessageDialog(null, "Funds is insufficient to pay service charge","Error",JOptionPane.ERROR_MESSAGE);
	}
	void Withdraw(){
		JOptionPane.showMessageDialog(null, "Funds is insufficient to withdraw","Error",JOptionPane.ERROR_MESSAGE);
	}
	void Multiple() {
		JOptionPane.showMessageDialog(null, "You must withdraw funds in increments of $20","Error",JOptionPane.ERROR_MESSAGE);
	}
	void CheckTextField() {
		JOptionPane.showMessageDialog(null, "Text Field must be numberic","Error",JOptionPane.ERROR_MESSAGE);
	}
}