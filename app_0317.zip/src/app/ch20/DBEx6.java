package app.ch20;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Scalar;

public class DBEx6 {
	public static void main(String[] args) throws IOException {
		Properties properties = new Properties();
		properties.load(DBEx6.class.getResourceAsStream("database.properties"));
		String driver = properties.getProperty("driver");
		String url = properties.getProperty("url");
		String id = properties.getProperty("username");
		String pw = properties.getProperty("password");
		Connection conn = null;
		Statement stmt = null;
		
		try {
			Class.forName(driver);
			System.out.println("loading OK!");
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("connect OK!");
			stmt = conn.createStatement();
			
			String sql = update();
			int result = stmt.executeUpdate(sql);
			String msg = result > -1 ? "OK" : "fail";
			System.out.println(msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) stmt.close();
				if (conn != null) conn.close();
				
			} catch (Exception e2) {	}
		}
	}
	
	/** 
	 * DATA UPDATE
	 * @return sql
	 */
	
	public static String update() {
//		String sql = "UPDATE DBTEST2 SET ID='a'";	//UPDATE 는 DML에 포함
//					   갱신   타겟DB  변경  속성컬럼 , .... 해당 테이블의 전체 컬럼이 바뀜
//		String sql = "INSERT DBTEST2 SET ID='d', PASSWORD='4'";
//		String sql = "UPDATE DBTEST2 SET ID='홍길동', PASSWORD='으적' WHERE ID='a'";
//																	ID a 타겟팅
//		String sql = "UPDATE DBTEST2 SET ID='A', PASSWORD='1' WHERE ID='Z'";
//		String sql = "UPDATE DBTEST2 SET ID='b', PASSWORD='2' WHERE ID='A' AND PASSWORD='1'";
//		String sql = "UPDATE DBTEST2 SET ID='c', PASSWORD='3' WHERE ID='d' AND PASSWORD='4'";
//		String sql = "DELETE FROM DBTEST2 WHERE ID='b'";//, PASSWORD='2' WHERE ID='d' AND PASSWORD='4'";
//		응용실습>
		Scanner scan = new Scanner(System.in);
		System.out.print("ID : ");
		String id = scan.next();
		System.out.print("PW : ");
		String pw = scan.next();
		String sql = "UPDATE DBTEST3 SET PW='" + pw + "'"
				+ ", CRE_DATE=now() WHERE ID='" + id + "'";
		return sql;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
