package app.ch20;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class DBEx7 {
	public static void main(String[] args) throws IOException {
		Properties properties = new Properties();
		properties.load(DBEx5_EX6use.class.getResourceAsStream("database.properties"));
		String driver = properties.getProperty("driver");
		String url = properties.getProperty("url");
		String id = properties.getProperty("username");
		String pw = properties.getProperty("password");
		Connection conn = null;
		Statement stmt = null;
		
		try {
			Class.forName(driver);
			System.out.println("loading OK!");
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("connect OK!");
			stmt = conn.createStatement();
			
			String sql = delete();
			int result = stmt.executeUpdate(sql);
			String msg = result > -1 ? "성공" : "실패";
			System.out.println(msg);
		} catch (Exception e) {
			System.out.println("연결 실패!!!!");
		} finally {
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	/**
	 *  DATA DELETE
	 * @return sql
	 */
	public static String delete() {
//		String sql = "DELETE FROM DBTEST";
//		DML -> delete  해당 테이블의 모든 데이터를 지움
//		String sql = "DELETE FROM DBTEST2 WHERE ID='c'";
//		Scanner scan = new Scanner(System.in);
//		System.out.print("ID = ");
//		String id = scan.next(); 
//		String sql = "DELETE FROM DBTEST3 WHERE ID='" + id + "'";
		String sql1 = "DELETE FROM DBTEST3 WHERE ID='a'";		// 연습문제 1
		String sql2	= "DELETE FROM DBTEST3 WHERE PW='b'";		// 연습문제 2
		String sql3	= "DELETE FROM DBTEST3 WHERE AGE >= 20";	// 연습문제 3
		return sql3;
	}
	/*
	 * 연습문제1> ID가 a인 사용자 모두 삭제
	 * 연습문제2> PW가 b인 사용자 모두 삭제
	 * 연습문제2> 나이가 20인 사용자 모두 삭제
	 * 
	 * DELETE DBTEST3 WHERE ID='a'
	 * DELETE DBTEST3 WHERE PW='b'
	 * DELETE DBTEST3 WHERE AGE=>20
	 */
	
	
	
//	DBEx5_EX6use 사용
//	입력1 a, a, 10
//	입력2 b, b, 11
//	입력3 c, c, 12
//	입력4 d, d, 20
//	입력5 e, e, 30
	
	
	
	
	
	
	
	
	
	
}
