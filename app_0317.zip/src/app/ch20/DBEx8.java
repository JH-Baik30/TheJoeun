package app.ch20;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Properties;


public class DBEx8 {
	public static void main(String[] args) throws IOException {
		Properties properties = new Properties();
		properties.load(DBEx5_EX6use.class.getResourceAsStream("database.properties"));
		String driver = properties.getProperty("driver");
		String url = properties.getProperty("url");
		String id = properties.getProperty("username");
		String pw = properties.getProperty("password");
		Connection conn = null;		//
		Statement stmt = null;		// 상태
		ResultSet rs = null;		// 추출한 데이터를 담을 set 컬렉션
		
		try {
			Class.forName(driver);
			System.out.println("loading OK!");
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("connect OK!");
			stmt = conn.createStatement();
			
			String sql = select();
			rs = stmt.executeQuery(sql);
			ResultSetMetaData rsmd = rs.getMetaData();		// 컬럼값 저장
			int cols = rsmd.getColumnCount();
			while (rs.next()) {
//			if(rs.next()) {
//				System.out.print("ID : " + rs.getString("id"));
//				System.out.print("  PW : " + rs.getString("pw"));
//				System.out.print("  Age : " + rs.getInt(3));
//				System.out.println("  Date : " + rs.getString(4));
				for (int i = 1; i <= 4; i++) {
					System.out.print(rs.getString(i) + "  ");
				}
				System.out.println();
			}
			
		} catch (Exception e) {
			System.out.println("연결 실패!!!!");
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	/**
	 * SELECT
	 * @return SQL
	 */
	
	public static String select() {
		String sql = "SELECT * FROM DBTEST3";
//							컬럼		  테이블명
		return sql;
	}
	
	
	
	
	
	
	
	
}
