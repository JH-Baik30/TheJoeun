package app.ch20;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class DBEx5_EX6use {
	public static void main(String[] args) throws IOException {
		Properties properties = new Properties();
		properties.load(DBEx5_EX6use.class.getResourceAsStream("database.properties"));
		String driver = properties.getProperty("driver");
		String url = properties.getProperty("url");
		Connection conn = null;
		Statement stmt = null;
		
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, "root", "java");
			stmt = conn.createStatement();
//			String sql = "CREATE TABLE DBTEST4(ID varchar(10),PassWord varchar(10))";
//			stmt.executeUpdate(sql);
			String input = insert();
			int result = stmt.executeUpdate(input);
			String msg = result > -1 ? "성공" : "실패";

		} catch (Exception e) {
			System.out.println("연결 실패!!!!");
		} finally {
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	public static String insert() {
		Scanner scan = new Scanner(System.in);
		System.out.print("ID = ");
		String id = scan.next(); 
		System.out.print("PW = ");
		String pw = scan.next();
		System.out.print("AGE = ");
		String age = scan.next();
		String sql = "INSERT INTO DBTEST3 VALUES('" + id + "', '" + pw + "', '" + age + "', NOW())";
//		String sql = "INSERT INTO DBTEST4 VALUES('a', 'a')";
		return sql;
	}
	
//	입력1   a, a, 10
//	입력2   b, b, 11
//	입력3   c, c, 12
//	입력4   d, d, 20
//	입력5   e, e, 30
	
	
	
	
	
	
	
	
	
}
