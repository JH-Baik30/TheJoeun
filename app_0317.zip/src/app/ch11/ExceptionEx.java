package app.ch11;
/* 형식 
  try {
  예외 발생 예상지역
  } catch (Exception e) {
  } finally {
  반드시 실행처리
  }
*/
public class ExceptionEx {
	public static void main(String[] args) {
		// 실행시 발생하는 예외 상황 Ex)
		int[] array = new int[3];
		array[0] = 0;
		array[1] = 10;
		array[2] = 20;
		
		// 고의로 에러유발
		for (int i = 0; i < array.length + 1; i++) {
			System.out.println("array[" + i + "] = " + array[i]);
		}
	}
}

