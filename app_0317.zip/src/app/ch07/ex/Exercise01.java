package app.ch07.ex;

import java.util.Scanner;

public class Exercise01 {
	public static void main(String[] args) {
		boolean run = true;

		int student = 0;
		int[] scores = null;

		Scanner scanner = new Scanner(System.in);

		while (run) {
			System.out.println("----------------------------------------------");
			System.out.println("1.학생수 | 2.점수입력 | 3.점수리스트 | 4.분석 | 5.종료");
			System.out.println("----------------------------------------------");
			System.out.print("선택> ");
			int num = scanner.nextInt();
			if (num == 1) {
				System.out.print("학생수를 입력하세요> ");
//				student = scanner.nextInt();
//				scores = new int[student];
				scores = new int[scanner.nextInt()];
			} else if (num == 2) {
				try {
					for (int i = 0; i < scores.length; i++) {
						System.out.print("scores[" + i + "]> ");
						int score = scanner.nextInt();
						scores[i] = score;
					}
				} catch (NullPointerException e) {
					System.out.println("학생수 미지정");
				}
			} else if (num == 3) {
				try {
					for (int i : scores) {
						System.out.println(i);
					}
				} catch (Exception e) {
					System.out.println("학생수 미지정");
				}
			} else if (num == 4) {
				try {
					int max = 0;
					for (int score : scores) {
						//max = (max < score) ? score : max; // 3항연산자
						if (max < score)
							max = score;
					}
					System.out.println("최고 점수: " + max);
					int sum = 0;
					for (int score : scores) {
						sum += score;
					}
					double avg = sum / scores.length;
					System.out.println("평균 점수: " + avg);
				} catch (Exception e) {
					System.out.println("학생수 미지정");
				}

			} else if (num == 5) {
				run = false;
			} else {
				System.out.println("잘 못 입력했음");
			}
		}
	}

}
