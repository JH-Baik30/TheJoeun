package app.ch04;

public class OperEx3 {
	public static void main(String[] args) {
		int su1 = 10, su2 = 20;
		String result = su1 < su2 ? "참" : "거짓";
		System.out.println(result);

	}

}
