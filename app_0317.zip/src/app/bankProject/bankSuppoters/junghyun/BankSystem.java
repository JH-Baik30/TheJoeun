package app.bankProject.bankSuppoters.junghyun;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class BankSystem {
    Scanner sc;
    AccountService accountService;

    public BankSystem(){
        sc = new Scanner(System.in);
        accountService = new AccountService();
    }

    public void start(){
        boolean run = true;
        while(run){
            System.out.println("===========================================");
            System.out.println("1.회원가입 | 2. 로그인 | 3.회원목록 | 0.종료");
            System.out.println("===========================================");
            System.out.print("선택> ");
            int choice = sc.nextInt();
            switch (choice){
                case 1 ->{
                    accountService.createAccount();
                }
                case 2->{
                    Account account = accountService.userLogin();
                    if(account != null){
                        this.bankMenu(account);
                    }
                }
                case 3-> {
                    accountService.getAccountList();
                }
                case 0 ->{
                    run = false;
                    System.out.println("프로그램 종료");
                }
                default -> {
                    System.out.println("잘못된 입력입니다.");
                }
            }
        }
    }

    public void bankMenu(Account account) {
        boolean run = true;
        while(run){
            System.out.println("===================="+account.getName()+"님 환영합니다======================");
            System.out.println("1.예금 | 2.출금 | 3.송금 | 4.거래내역조회 | 5.계좌정보 | 0.로그아웃");
            System.out.println("============================================================");
            System.out.print("선택> ");
            int choice = sc.nextInt();
            switch(choice){
                case 1 -> {
                        accountService.depositService(account);
                }
                case 2 -> {
                        accountService.withdrawService(account);
                }
                case 3-> {
                        accountService.TransferService(account);
                }
                case 4 -> {
                        accountService.showHistory(account);
                }
                case 5-> {
                    accountService.showAccountInfo(account);
                }
                case 0 -> {
                    System.out.println("초기화면으로 돌아갑니다.");
                    run = false;
                }
                default -> {
                    System.out.println("잘못된 입력입니다.");
                }
            }
        }
    }






}
