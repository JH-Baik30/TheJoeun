package app.bankProject.bankSuppoters.junghyun;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class AccountService {
    List<Account> accounts;
    Scanner sc;

    public AccountService() {
        accounts = new LinkedList<>();
        sc = new Scanner(System.in);
    }

    public void createAccount(){
        System.out.print("이름: ");
        String name = sc.next();
        System.out.print("아이디: ");
        String id = sc.next();
        if(isDuplicateId(id)){
            System.out.print("비밀번호: ");
            String password = sc.next();
            int number = 1000+ accounts.size();     //순차적으로 계좌번호 생성
            Account account = new Account(name,id,password,number);
            accounts.add(account);
            System.out.println(name+"님의 계좌가 개설되었습니다. 계좌번호: "+ account.getNumber());
        }else{
            System.out.println(id +" (은)는 중복된 아이디입니다. 다시 시도해주세요.");
        }
    }

    private boolean isDuplicateId(String id) {
        for(Account account : accounts){
            if(account.getId().equals(id)){
                return false;
            }
        }
        return true;
    }

    public Account userLogin() {
        System.out.print("아이디를 입력하세요: ");
        String id = sc.next();
        System.out.print("비밀번호를 입력하세요: ");
        String pw = sc.next();
        Account account = checkId(id,pw);
        if(account == null){
            System.out.println("아이디 / 비밀번호를 다시 확인해주세요.");
            return null;
        }
        return account;
    }
    public Account checkId(String id, String pw){
        for (Account account : accounts) {
            if (account.getId().equals(id) && account.getPassword().equals(pw)) {
                return account;
            }
        }
        return null;
    }

    public void getAccountList() {
        System.out.println("회원목록-");
        for(Account account : accounts){
            System.out.println(account.info());
        }
        System.out.println("-------");
    }

    public void depositService(Account account) {
        System.out.print(account.getName()+"님, 입금할 금액을 입력해주세요: ");
        int money = sc.nextInt();
        if(account.deposit(money)){
            System.out.println(account.formattingMoney(money)+"원 입금 완료");
        }
    }

    public void withdrawService(Account account) {
        if(checkPw(account)){
            System.out.print(account.getName()+"님, 출금할 금액을 입력해주세요: ");
            int money = sc.nextInt();
            if(account.withdraw(money)){
                System.out.println(account.formattingMoney(money)+"원 출금 완료");
            }
        }
    }

    private boolean checkPw(Account account) {
        for(int cnt=0; cnt < 3; cnt++){
            System.out.print("비밀번호를 입력하세요: ");
            String pw = sc.next();
            if(account.getPassword().equals(pw)){
                return true;
            }else{
                System.out.println("비밀번호가 일치하지않습니다.("+(cnt+1)+"/3)");
            }
        }
        return false;
    }

    public void TransferService(Account account) {
        System.out.print("송금할 계좌번호를 입력하세요: ");
        int number = sc.nextInt();
        int index = checkNumber(number);
        if(index == -1){
            System.out.println("존재하지 않는 계좌번호입니다.");
        }else{
            if(checkPw(account)){
                Account receiveAccount = accounts.get(index);
                System.out.print(account.getName()+"님, 송금할 금액을 입력해주세요: ");
                int money = sc.nextInt();
                if(account.wireTransfer(receiveAccount, money)){
                    System.out.println(account.formattingMoney(money)+"원 송금 완료");
                }
            }
        }
    }

    private int checkNumber(int number) {
        for(int i = 0; i < accounts.size(); i++){
            if(accounts.get(i).getNumber() == number){
                return i;
            }
        }
        return -1;
    }


    public void showHistory(Account account) {
        System.out.println(account.getName()+"님의 거래내역==================");
        for(String str : account.getHistory()){
            System.out.print(str);
        }
        System.out.println("잔고: " + account.formattingMoney(account.getBalance()));
        System.out.println("==================================");
    }

    public void showAccountInfo(Account account) {
        System.out.println("아이디: " + account.getId());
        System.out.println("비밀번호: " + account.getPassword());
        System.out.println("이름: " + account.getName());
        System.out.println("계좌번호: " + account.getNumber());
        System.out.println("잔고: " +account.formattingMoney(account.getBalance()));
    }
}
