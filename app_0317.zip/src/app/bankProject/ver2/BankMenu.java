package app.bankProject.ver2;
//정현도움!!!!
import java.util.Scanner;

public class BankMenu {
	Member[] members = new Member[10];
	Scanner scan = new Scanner(System.in);
	int idx = 0;
	
	public Member logIn() {
		System.out.print(" account > ");
		String account = scan.next();
		System.out.print(" pw > ");
		String pw = scan.next();		
		for (int i = 0; i < members.length; i++) {
			if (members[i].getAccount().equals(account) && members[i].getPw().equals(pw)) {
				return members[i];
			}
		}
		return null;
	}
	
	public void creatAccount() {
		System.out.print(" account > ");
		String account = scan.next();
		System.out.print(" pw > ");
		String pw = scan.next();
		
		members[idx] = new Member(pw, account);
		idx++;
	}
	
	
	public void memberSystem() {
		boolean run = true;
		while(run) {
			System.out.println("-------------------------------");
			System.out.println(" 1. 로그인 | 2. 회권가입 | 3. 종료");
			System.out.println("-------------------------------");
			System.out.println(">");
			int num = scan.nextInt();
			switch (num) {
			case 1:
				Member member = logIn();
				if (member != null) {
					bankMenu(member);
				}
				break;
			case 2:
				creatAccount();
				break;
			case 3:
				System.exit(0);

			default:
				break;
			}
		}
	}

	public void bankMenu(Member member) {
		boolean run = true;

		do {
			System.out.println("--------------------------------------------");
			System.out.println(" 1. 입금 | 2. 출금 | 3. 잔고 | 4. 이체 | 5. 종료 ");
			System.out.println("--------------------------------------------");
			System.out.print("선택 > ");

			int main = scan.nextInt();

			switch (main) {
			case 1:
				System.out.println("입금할 금액을 넣으세요.");
				int money = scan.nextInt();
				member.deposit(money);
				break;
			case 2:
				System.out.println("출금할 금액을 넣으세요.");
				money = scan.nextInt();
				member.withDraw(money);
				break;
			case 3:
				member.balance();
				break;
			case 5:
				System.out.print("종료하시겠습니까? (Y/N)");
				String quitChck = scan.next();
				switch (quitChck) {
				case "Y": 
				case "y":
					System.out.println("종료합니다.");
					run = false;
					System.exit(0);
				case "N":
				case "n":
					System.out.println("메뉴로 돌아갑니다.");
					break;
				default:
					System.out.println("잘 못 입력했습니다.");
					break;
				}
				
			default:
				System.out.println("잘 못 입력했습니다.");
			}

		} while (run);

	}
}
