package app.bankProject.ver6_UI;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Clock {
	public static void main(String[] args) {
		Thread thread = new Thread();
		while (true) {
			try {
				Date now = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd HH:mm:ss");
				String dateTime = sdf.format(now);
//				System.out.println(sdf.format(now));
				thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
