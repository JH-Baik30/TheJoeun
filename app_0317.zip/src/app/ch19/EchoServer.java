package app.ch19;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class EchoServer {
	private ServerSocket server;
	public EchoServer(int port) throws IOException{
		server = new ServerSocket(port);    // 통신준비 끝
	}
	
	
	public void service() throws IOException{
//		Vector<> vector = new Vector<>();
		Thread thread = new Thread();
//		while(vector.size()) {
			thread.start();
			Socket client = server.accept();					// 통신소켓 수락
			// 데이터 통신 IO 구문 시작
			InputStream is = client.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			
			BufferedReader in = new BufferedReader(isr);		// 클라이언트 데이터 받기
			OutputStream os = client.getOutputStream();
			PrintWriter out = new PrintWriter(os, true);		// 클라이언트에게 출력하는 라이터
			// 데이터 통신 IO 구문 끝
			
			while (true) {
				String msg = in.readLine();
				System.out.println(msg);
				if (msg.equals("bye")) {
					break;
				}
				out.println(">> " + msg);						// 클라이언트 화면에 출력
			}
			
		}
//	}
	
	public void close() throws IOException{
		server.close();
	}
	
	public static void main(String[] args) {
		try {
			EchoServer es = new EchoServer(1289);
			es.service();
			es.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
}
