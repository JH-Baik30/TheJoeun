package app.ch05;

import java.util.Scanner;

public class ForEx {
	public static void main(String[] args) {

//		int a = 2;
//		for (int i = 1; i < 10; i++) {
//			System.out.println(a + " * " + " = " + a * i);
//		}

//		System.out.println();
//		System.out.print("단을 입력하세요: ");
//		int scan = new Scanner(System.in).nextInt();

//		int dan = 2;
//		for (int i = 0; i < 5; i++) {
//			for (int j = 0; j < 5; j++) {
//				System.out.println(i + ", "+ j);
//			}
//		}
//		int i = 1;
//		if (i < 10) {
//			System.out.println();
//		}
//		

		for (int i = 1; i < 10; i++) {
			for (int j = 2; j < 10; j++) {
				System.out.print(j + " * " + i + " = " + j * i + "\t");
			}
			System.out.println();
		}

	}

}
