package app.ch08.inher0302;

// C에 대한 subClass B
// A에 대한 superClass
class C{
	public C() {
		System.out.println("Constructor C");
	}
	int num = 10;
	String msg = "msg...";
	public void method() {
		System.out.println("method " + num);
	}
	public void method_C() {
		System.out.println("method_C " + msg);
	}
}

class B extends C{
	public B() {
		super();
		System.out.println("Constructor B");
	}
	int num = 50;
	
	public void method() {
		super.method_C();
		this.method_C();
		System.out.println("method " + num);
	}
	public void method_B() {
		System.out.println("method_B " + msg);
	}
}

class A extends B{
	public A() {
		System.out.println("Constructor A");
	}
	
	public void method() {
//		System.out.println("method " + super.super.num);
	}
	public void method_A() {
		System.out.println("method_A " + msg); // this.msg 이지만 this가 새략된 상태
	}
}

public class InherEx3 {
	public static void main(String[] args) {
		A a = new A();
		B b = a;
		C c = b;
		a.method_A();
	}
}






