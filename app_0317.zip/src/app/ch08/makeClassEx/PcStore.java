package app.ch08.makeClassEx;

public class PcStore {
	public static void main(String[] args) {
		PcBase basicPc = new PcBase();
		basicPc.cpuCompany = "AMD";
		basicPc.cpuModel = "3200g";
		basicPc.gpu = "내장그래픽";
		basicPc.psu = 500;
		basicPc.ramSize = 8;
		basicPc.spec();
		System.out.println();
		
		OfficePc officePc = new OfficePc();
		officePc.cpuCompany = "AMD";
		officePc.cpuModel = "5700g";
		officePc.gpu = "내장그래픽";
		officePc.psu = 500;
		officePc.ramSize = 8;
		officePc.spec();
		officePc.work();
		System.out.println();
		
		GamePc gamePc = new GamePc();
		gamePc.cpuCompany = "INTEL";
		gamePc.cpuModel = "13700k";
		gamePc.gpu = "RTX 3080TI";
		gamePc.psu = 1000;
		gamePc.ramSize = 16;
		gamePc.spec();
		officePc.work();
		System.out.println();
		
		WorkPc workPc = new WorkPc();
		workPc.cpuCompany = "INTEL";
		workPc.cpuModel = "13900k";
		workPc.gpu = "RTX4090";
		workPc.psu = 1200;
		workPc.ramSize = 64;
		workPc.spec();
		officePc.work();
		System.out.println();
			
	}
}
