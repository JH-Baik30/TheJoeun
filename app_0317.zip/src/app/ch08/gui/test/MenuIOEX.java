// 쌤 풀이

package app.ch08.gui.test;

import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class MenuIOEX extends Frame implements ActionListener{
	public MenuBar mb;
	public Menu m;
	public MenuItem[] mi;
	public TextArea ta;
	public FileDialog fd_open, fd_save;
	public String save_file;
	public MenuIOEX() {
		fd_open = new FileDialog(this, "파일 열기", FileDialog.LOAD);
		fd_save = new FileDialog(this, "파일 저장", FileDialog.SAVE);
//		fd_open.setVisible(true);
		ta = new TextArea();
		ta.setEditable(true);		// 입력창 비활성화
		mb = new MenuBar();
		m = new Menu("File");
		mi = new MenuItem[5];
		mi[0] = new MenuItem("New File");
		mi[1] = new MenuItem("Open File");
		mi[2] = new MenuItem("Save File");
		mi[3] = new MenuItem("Save As File");
		mi[4] = new MenuItem("Exit");
		for (int i = 0; i < mi.length; i++) {
			m.add(mi[i]);
			mi[i].addActionListener(this);
			if ( i != 2 && i != (mi.length -1) ) {
				m.addSeparator();
			}
		}
		
		mb.add(m);
		setMenuBar(mb);
		add(ta, "Center");
		setSize(500, 500);
		setVisible(true);
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}			
		});
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == mi[0]) {
			ta.setEditable(true);
			ta.setText("");
			setTitle("제목없음");
		} else if (obj == mi[1]) {
			try {
				fd_open.setVisible(true);
				String open_file = fd_open.getDirectory() + fd_open.getFile();
				File file = new File(open_file);
				FileReader fr = new FileReader(file);
				BufferedReader br = new BufferedReader(fr);
				ta.setText("");
				while(br.ready()) {
					ta.append(br.readLine() + "\n");
				}
				br.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} else if (obj == mi[2]) {
			fd_save.setVisible(true);
			
			
			
		} else if (obj == mi[3]) {
			try {
				fd_save.setVisible(true);
				String save_as_file = fd_save.getDirectory()+fd_save.getFile();
				File file = new File(save_as_file);
				FileWriter fw = new FileWriter(file);
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write(ta.getText());
				bw.close();
			} catch (IOException e2) {
				e2.printStackTrace();
			}
			
		} else if (obj == mi[4]) {
			System.exit(0);
		}
	}
	
	public static void main(String[] args) {
		new MenuIOEX();
	}
}
