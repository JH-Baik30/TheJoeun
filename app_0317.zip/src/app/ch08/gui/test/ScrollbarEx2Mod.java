package app.ch08.gui.test;
// Test1 답안
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Scrollbar;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ScrollbarEx2Mod extends JFrame{
	public JPanel p1, p2;
	public Scrollbar sb_r, sb_g, sb_b;
	public JTextField tf;
	public JTextArea ta;
	public ScrollbarEx2Mod() {
		setTitle("ScrollbarEx");
		tf = new JTextField();
		ta = new JTextArea();
		p1 = new JPanel();
		p2 = new JPanel();
		sb_r = new Scrollbar(0, 0, 10, 0, 265);
		sb_g = new Scrollbar(0, 0, 10, 0, 265);
		sb_b = new Scrollbar(0, 0, 10, 0, 265);
		
		JLabel la1 = new JLabel("");
		JLabel la2 = new JLabel("");
		JLabel la3 = new JLabel("");
		JLabel la4 = new JLabel("");
		JLabel la5 = new JLabel("");
		JLabel la6 = new JLabel("");
		JLabel la7 = new JLabel("");
		JLabel la8 = new JLabel("");
		JLabel la9 = new JLabel("");
		JLabel la10 = new JLabel("현재색상");
		
		p1.setLayout(new GridLayout(10, 1));
		p2.setLayout(new BorderLayout());
		setLayout(new GridLayout(1, 2));		// this가 생략되어있다.
		
		p1.add(la1);
		p1.add(sb_r);
		p1.add(la2);
		p1.add(sb_g);
		p1.add(la3);
		p1.add(sb_b);
		p1.add(la4);
		p1.add(la10);
		p1.add(tf);
		p1.add(la5);
		
		p2.add(la6, BorderLayout.EAST);
		p2.add(ta, BorderLayout.CENTER);
		p2.add(la7, BorderLayout.WEST);
		p2.add(la8, BorderLayout.NORTH);
		p2.add(la9, BorderLayout.SOUTH);
		
		add(p1);								// this 생략됨.
		add(p2);								// this 생략됨.
		setSize(300, 300);
		setVisible(true);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		new ScrollbarEx2Mod();
	}
}
