package app.ch08.gui.test;
// 제희코드
import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Choice;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Shade extends Frame implements ItemListener{

	Panel[] p = new Panel[3];
	CheckboxGroup checkboxGroup;
	Checkbox ch0, ch1, ch2, ch3, ch4, ch5;
	TextArea textArea;
	Choice choice;
	Label[] spaceLabels = new Label[8];

	public Shade() {
		checkboxGroup = new CheckboxGroup();
		ch0 = new Checkbox("아침", false, checkboxGroup);
		ch1 = new Checkbox("점심", false, checkboxGroup);
		ch2 = new Checkbox("저녁", false, checkboxGroup);
		ch3 = new Checkbox("사과");
		ch4 = new Checkbox("딸기");
		ch5 = new Checkbox("배");
		textArea = new TextArea("<<자바 수강생 식생활>>", 8, 22, 3);
		choice = new Choice();
		for (int i = 0; i < spaceLabels.length; i++)
			spaceLabels[i] = new Label();
		for (int i = 0; i < p.length; i++)
			p[i] = new Panel();

		choice.add("아침");
		choice.add("점심");
		choice.add("저녁");

		p[0].setLayout(new GridLayout(3, 4));
		p[0].add(spaceLabels[0]);
		p[0].add(ch0);
		p[0].add(ch1);
		p[0].add(ch2);
		p[0].add(spaceLabels[1]);
		p[0].add(ch3);
		p[0].add(ch4);
		p[0].add(ch5);
		p[0].add(spaceLabels[2]);
		p[0].add(spaceLabels[3]);
		p[0].add(spaceLabels[4]);
		p[0].add(spaceLabels[5]);
		p[1].add(textArea);

		p[2].add(choice);

		add(spaceLabels[6], BorderLayout.WEST);
		add(spaceLabels[7], BorderLayout.EAST);
		add(p[0], BorderLayout.NORTH);
		add(p[1], BorderLayout.CENTER);
		add(p[2], BorderLayout.SOUTH);
		
		ch0.addItemListener(this);
		ch1.addItemListener(this);
		ch2.addItemListener(this);
		ch3.addItemListener(this);
		ch4.addItemListener(this);
		ch5.addItemListener(this);
		choice.addItemListener(this);
		
		setSize(280, 300);
		setVisible(true);

		addWindowListener(new WindowAdapter() { // 내부 익명 클래스
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}

	public static void main(String[] args) {
		new Shade();
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		String str[] = {"아침","점심","저녁"};
		int i=0;
		
		if(ch0.getLabel().equals(e.getItem())) {
			choice.select(0);
			i=0;
		}
		if (ch1.getLabel().equals(e.getItem())) {
			choice.select(1);
			i=1;
		}
		if (ch2.getLabel().equals(e.getItem())) {
			choice.select(2);
			i=2;
		}
		switch (choice.getSelectedIndex()) {
		case 0: 
			ch0.setState(true);
			i=0;
			break;
		case 1: 
			ch1.setState(true);
			i=1;
			break;
		case 2: 
			ch2.setState(true);
			i=2;
			break;
		}
//		choice.select(checkboxGroup.getSelectedCheckbox().getLabel());
		textArea.setText(" <<"+str[i]+" >>\n\n사과 : "+ch3.getState() + "\n딸기 : "
							+ch4.getState() + "\n배 : "+ ch5.getState());
	}
}