package app.ch06;

public class ArrayEx2 {
	public static void main(String[] args) {
		int[][] arr = new int[3][2];
		arr[0][0] = 1;
		arr[0][1] = 2;
		arr[1][0] = 3;
		arr[1][1] = 4;
		arr[2][0] = 5;
		arr[2][1] = 6;
		
		System.out.println("ssss:  " + arr.length);
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				 
				System.out.println(arr[i][j]);
			}
		}
//
//		System.out.println();
//		int[][] arr2 = { { 10, 20 }, 
//						 { 30, 40, 50 },
//						 { 60, 70, 80, 90 } };
//
//		for (int i = 0; i < arr2.length; i++) {
//			for (int j = 0; j < arr2[i].length; j++) {
//				System.out.print(arr2[i][j] + ", ");
//			}
//			System.out.println();
//		}
		
		/*String[] name = { "홍길동", "고길동", "서길동" };
		int[][] scores = {{80, 90, 80},
					      {85, 92, 95},
						  {78, 88, 85}};
		
		int sum = 0;
		for (int i = 0; i < scores.length; i++) {
			System.out.println(name[i]);
			for (int j = 0; j < scores.length; j++) {
				sum += scores[i][j];
			}
			System.out.println("총 점 : " + sum);
			System.out.printf("평 균 : %.2f%n" , (double) sum / scores.length);
			sum = 0;
			System.out.println();
		}*/

	}
}
