package app.ch05;

public class IfEx {
	public static void main(String[] args) {
		int num = 10;
		if (num > 10) {
			System.out.println("참입니다.");
		} else {
			System.out.println("거짓입니다.");
		}
		System.out.println("실행 구문");
	}
}
