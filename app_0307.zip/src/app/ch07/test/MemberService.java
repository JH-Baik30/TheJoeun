package app.ch07.test;

public class MemberService {
	public Member member;
	
	public MemberService() {
		member = new Member("홍길동", "abc", "123");
	}
	public boolean login(String id, String pw) {
		boolean result = false;
		if(member.getId().equals(id)) { 
			 if(member.getPw().equals(pw)) {
				 System.out.println(member.getName() + "님 로그인 성공!");
				 result = true;
			 } else {
				 System.out.println("pw X");
			 }
		} else {
			System.out.println("id X");
		}
		return result;
	}

//	login("abc", "123");
	
}
