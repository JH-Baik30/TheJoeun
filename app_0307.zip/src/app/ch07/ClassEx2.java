package app.ch07;

// 객체의 3단계 원칙 -> 설계, 정의, 생성
public class ClassEx2 {
	public static void main(String[] args) {
		ObjectA obj1 = new ObjectA();
		System.out.println( "고객1 이름 : " + obj1.name);
		System.out.println( "고객1 나이 : " + obj1.age);
		System.out.println();
		ObjectB obj2 = new ObjectB();
		System.out.println( "고객2 이름 : " + obj2.name);
		System.out.println( "고객2 나이 : " + obj2.age);
		
	}
}

class ObjectA {
	int age = 10;
	String name = "홍길동";
}

class ObjectB {
	int age = 20;
	String name = "개똥이";
}