package app.bank;

import java.util.Scanner;

public class BankSystem {
	public static void main(String[] args) {
		boolean run = true;
		Scanner scanner = new Scanner(System.in);

		// 계좌 생성 코드
		Member[] member = new Member[3];
		
		int cnt = 256001;
		for (int i = 0; i < member.length; i++) {
			member[i] = new Member(cnt);
			member[i].setAccount(cnt);
			cnt++;
		}

//	public static void mainMenu(int num){
		do {
			System.out.println("-------------------------------");
			System.out.println(" 1. 은행업무 | 2. 계좌생성 | 3. 종료 ");
			System.out.println("-------------------------------");
			System.out.print("선택 > ");
			int mainMenu = scanner.nextInt();
			
			// 1.은행업무
			if (mainMenu == 1) {
				System.out.print("본인 계좌번호 입력하세요.");
				int acc = scanner.nextInt();
				for (int i = 0; i < member.length; i++) {
					if (member[i].getAccount() == acc) {
						System.out.print("비밀번호 입력하세요.");
						String pw = scanner.nextLine();
						if (member[i].getPw() == pw) {
							return; // member[i];
						} else {
							System.out.println("비밀번호가 틀렸습니다.");
							continue;
						}
					} else {
						System.out.println("계좌번호가 틀렸습니다.");
						continue;
					}
				}
				
				do {
					System.out.println("---------------------------------------------");
					System.out.println(" 1. 잔고확인 | 2. 입금 | 3. 출금 | 4. 이체 | 5. 종료 ");
					System.out.println("---------------------------------------------");
					System.out.print("선택 > ");
					int subMenu = scanner.nextInt();
					switch (subMenu) {
					case 1:
							
						break;
					case 2:
						
						break;
					case 3:
						
						break;
					case 4:
						
						break;
					case 5:
						run = false;
						break;
						
					default:
						System.out.println("잘못 입력 하셨습니다.");
					}
					
				} while (run);
				
				
			} else if (mainMenu == 2){	
				for (int i = 0; i < member.length; i++) {
					if(member[i].getName() == null) {
						System.out.println("명의자 이름을 입력하세요: ");
						member[i].setName(scanner.nextLine());
						System.out.println("비밀번호를 설정하세요: ");
						member[i].setPw(scanner.nextLine());
					}
				}
			} else if (mainMenu == 3) {
				System.exit(0);
			}


		} while (run);

	}

}
