package app.bank;

import java.util.Scanner;

public class MainMenu {
	public static void menu() {
		Scanner scanner = new Scanner(System.in);
		boolean run = true;
		do {
			System.out.println("--------------------------------");
			System.out.println(" 1. 은행업무 | 2. 계좌생성 | 3. 종료 ");
			System.out.println("--------------------------------");
			System.out.print("선택 > ");
			int mainMenu = scanner.nextInt();
			/*
			switch (mainMenu) {
			case 1:
				System.out.println("계좌 번호 입력");
				String account = scanner.nextLine();
				System.out.println("비밀 번호 입력");
				String passward = scanner.nextLine();
				for (int i = 0; i < 10; i++) {
					if ((person[i].getAccount == account) && (person[i].getPassward == passward)) {
						return Person[i];
					} else break;
				}
				break;
			case 2:
				System.out.println("생성할 계좌 명의자 이름을 입력하세요: ");
				name = new Scanner(System.in).nextLine();
				System.out.println("생성할 계좌번호를 입력하세요: ");
				scanner.nextLine();
				account = scanner.nextLine();
				System.out.println("생성할 계좌의 비밀번호를 입력하세요: ");
				passward = scanner.nextLine();
				//Person person = new Person();
				
				break:
			case 3:
				run = false:
				break:

			default:
				break;
			}
			}
			}*/
			
		} while (run);
	}
}
