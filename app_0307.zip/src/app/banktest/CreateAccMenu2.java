package app.banktest;

import java.util.InputMismatchException;
import java.util.Scanner;

public class CreateAccMenu2 {
	Scanner scanner = new Scanner(System.in);
	Member[] member = new Member[10];
	int idx;
	int cnt = 267100;
//	int cnt = 1;
	
	public Member logIn() {
		System.out.print("계좌 번호를 입력하세요.");
		int inputAcc = scanner.nextInt();
		System.out.print("비밀 번호를 입력하세요.");
		String inputPw = scanner.next();
		try {
			for (int i = 0; i < member.length; i++) {
				if (member[i].getAccount() == inputAcc) {
					if (member[i].getPw().equals(inputPw)) {
						idx = i;
						return member[i];
					} //else {	System.out.println("비번 틀림");	}
				} //else {	System.out.println("아이디 틀림");		}
			}
			return null;
		} catch (NullPointerException e) {
			System.out.println("계좌번호와 비밀번호를 확인하세요.");
			return null;
		} catch (InputMismatchException e) {
			System.out.println("계좌번호와 비밀번호를 확인하세요.");
			return null;
		}	
	}

	public Member creatAccount() {
		System.out.println("이름을 입력하세요.");
		String name = scanner.next();
		System.out.println("비밀번호를 입력하세요.");
		String pw = scanner.next();
		member[idx] = new Member(cnt, name, pw);
		member[idx].info();
		idx++;
		cnt++;
		return member[idx];
	}
	
	public void accountList() {
		try {
			for (Member mem : member) {
				System.out.println("계좌번호: " + mem.getAccount() + " 소유자 이름: " + mem.getName());
			}
		} catch (Exception e) {
		}
	}
	
	public void logInMenu() {
		boolean run = true;
		do {
			System.out.println();
			System.out.println("-------------------------------");
			System.out.println(" 1. 은행업무 | 2. 계좌생성 | 3. 종료 ");
			System.out.println("-------------------------------");
			System.out.print("선택 > ");
			int num = scanner.nextInt();

			switch (num) {
			case 1:
				Member member =	logIn();
				if (member != null) {
//					BankMenu bankMenu = new BankMenu(member);
					bankMenu(member);
				}
				break;
			case 2:
				creatAccount();
				break;
			case 3:
				run = false;
				break;
			default:
				System.out.println("잘못입력했습니다");
			}
		} while (run);
	}
	
	public Member bankMenu(Member member) {
		boolean run = true;
		do {
			System.out.println();
			System.out.println(" " + member.getName() + "님 로그인중 ");
			System.out.println("----------------------------------------------");
			System.out.println(" 1. 입금 | 2. 출금 | 3. 잔고 | 4. 계좌 목록 | 5. 종료 ");
			System.out.println("----------------------------------------------");
			System.out.print("선택 > ");

			int main = scanner.nextInt();

			switch (main) {
			case 1:
				System.out.println("입금할 금액을 입력하세요.");
				int money = scanner.nextInt();
				member.deposit(money);
				break;
			case 2:
				System.out.println("출금할 금액을 입력하세요.");
				money = scanner.nextInt();
				member.withDraw(money);
				break;
			case 3:
				member.balance();
				break;
			case 4:
				accountList();
				break;
			case 5:
				run = false;
				break;
				
			default:
				System.out.println("잘못입력했습니다.");
			}

		} while (run);
		return member;

	}
	
}
