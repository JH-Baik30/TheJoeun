package app.banktest;

import java.awt.TextArea;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;

public class UI extends JFrame{
	public JButton bt1, bt2, btx, bt4, bt5, bt6, bt7, btLO;
	public TextArea tArea;

	
	public UI() {
		
		
		
		
		setSize(500,400);
		setVisible(true);
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent e) {
				// TODO Auto-generated method stub
				super.windowClosed(e);
			}
		});
	}
}
