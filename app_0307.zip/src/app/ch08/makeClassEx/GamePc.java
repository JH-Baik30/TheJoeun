package app.ch08.makeClassEx;

public class GamePc extends PcBase{	
	
	void work() {
		powerOn();
		game();
		mom();
		powerOff();
		study();
	}
	void game() {
		System.out.println("롤을 합니다.");
	}
	void study() {
		System.out.println("과제를 합니다.");
	}
	void mom() {
		System.out.println("엄마한테 혼납니다.");
	}
}
