package app.ch03;

public class DataTypeEx {
	public static void main(String[] args) {
		byte byte1 = 127;
		short short1 =10000;
		char char1 ='a';
		int int1 = 1234567890;
		long long1 = 1000000000000000000L;
		float float1 = 0.1f;
		double double1 = 1.0;
		boolean boolean1 =true;
		System.out.println("byte : " + byte1);
		System.out.println("short : " + short1);
		System.out.println("char : " + char1);
		System.out.println("int : " + int1);
		System.out.println("long : " + long1);
		System.out.println("float : " + float1);
		System.out.println("double : " + double1);
		System.out.println("boolean : " + boolean1);
		
		int a = 10;
		int b = 20;
		System.out.println(a == b);
	}
}
