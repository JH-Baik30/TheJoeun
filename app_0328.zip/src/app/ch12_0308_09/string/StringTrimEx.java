package app.ch12_0308_09.string;

public class StringTrimEx {
	public static void main(String[] args) {
		String tel1 = "  02";
		String tel2 = "123  ";
		String tel3 = "   1234   ";
		String tel_old = tel1 + tel2 + tel3;
		String tel = tel1.trim() + tel2.trim() + tel3.trim();
		System.out.println(tel_old);
		System.out.println(tel);
	}
}
