package app.ch11_0310;

public class NumberFormatEx {
	public static void main(String[] args) {
		String data1 = "100";
		String data2 = "100";
		int value1 = Integer.parseInt(data1);
		int value2 = Integer.parseInt(data2);
		int result = value1 + value2;
		System.out.println(data1 + "+" + data2 + "=" + result);
//		int su =  Integer.parseInt(args[0]);
//		System.out.println(su);
		Integer.toString(10 + 10);
//		System.out.println();
//		System.out.println(10);
	}
}
