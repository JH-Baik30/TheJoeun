package app.ch20_0315_17;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DBEx3 {
	public static void main(String[] args) {
		String driver = "com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/app";
		Connection conn = null;				// connection으로 하여금 db의 상태를 가져온다.
		Statement stmt = null;				//db 상태를 가져오는 객체
		
		try {
			Class.forName(driver);
			System.out.println("데이터베이스 드라이버 로딩성공!");
			conn = DriverManager.getConnection(url, "root", "java");	
			// .getConnection -> 드라이버 연결 메소드
			System.out.println("데이터베이스 연결성공!");
			stmt = conn.createStatement();			// connection 객체를 통해서 상태를 가져와라.
			String sql = "CREATE TABLE DBTEST(ID varchar(5))";		// 대소문자 안가림.
//			String sql = "create Tabel DBTEST(ID varchar2(5))";		// Oracle
//						DBTEST => 식별자(내맘대로), ID varchar => 컬럼(변수와 데이터 타입지정)
//					varchar(5) 5개 이하로 생성가능, char(5) 딱 5개.
			int result = stmt.executeUpdate(sql);	// SQL 문을 수행해라.
			// -1 => 실패, 0 = DDL 관련 성공, 1 = DML 관련 성공
			if(result < 0) {
				System.out.println("Fail !!");
			} else {
				System.out.println("Success !!");
			}
			
//			String id;
		} catch (Exception e) {
			System.out.println("데이터베이스 드라이버 로딩및 연결실패!");
		} finally {
			try {
				if(stmt != null) stmt.close();		// 상태를 닫고
				if(conn != null) conn.close();		// 연결을 끊는다.
			} catch (Exception e2) {	}
		}
	}
}
