package app.ch07_0227_28.methodEx;

import java.util.Scanner;
// 연습 3 : 홀수 짝수 합.
public class MethodEx_test3 {
	public static int odd(int start, int end) {
		int sum = 0;
		for (int i = start; i <= end; i++) {
			if (i % 2 == 1) {
				sum += i;
			}
		}
		return sum;		
	}

	public static int even(int start, int end) {
		int sum = 0;
		for (int i = start; i <= end; i++) {
			if (i % 2 == 0) {
				sum += i;
			}
		}
		return sum;		
	}
	
	public static void main(String[] args) {
		boolean run = true;
//		Scanner scanner = new Scanner(System.in);
		do {
			System.out.println("-------------------------------");
			System.out.println("1. 홀수의 합 | 2. 짝수의 합 | 3. 종료 ");
			System.out.println("-------------------------------");
			System.out.print("선택> ");
			int choice = new Scanner(System.in).nextInt();
			
			switch (choice) {
			case 1:
				System.out.print("몇 부터 시작할까요? : ");
				int start = new Scanner(System.in).nextInt();
				System.out.print("몇 까지 더 할까요? : ");
				int end = new Scanner(System.in).nextInt();
				System.out.println(odd(start, end));
				break;
			case 2:
				System.out.print("몇 부터 시작할까요? : ");
				start = new Scanner(System.in).nextInt();
				System.out.print("몇 까지 더 할까요? : ");
				end = new Scanner(System.in).nextInt();
				System.out.println(even(start, end));
				break;
			case 3:
				run = false;
				break;
			default:
				System.out.println("잘 못 입력했습니다.");
			}
			System.out.println();
		}while (run);
			System.out.println("종료");	
	}	
}
