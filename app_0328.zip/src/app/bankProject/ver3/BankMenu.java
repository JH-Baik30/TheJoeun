package app.bankProject.ver3;

import java.util.Scanner;

public class BankMenu {
	static Scanner scanner = new Scanner(System.in);
	static boolean run = true;
/*
	public Member bankMenu(Member member) {

		do {
			System.out.println("-------------------------------------------");
			System.out.println(" 1. 입금 | 2. 출금 | 3. 잔고 | 4. 이체 | 5. 종료 ");
			System.out.println("-------------------------------------------");
			System.out.print("선택 > ");

			int main = scanner.nextInt();

			switch (main) {
			case 1:
				System.out.println("입금할 금액을 입력하세요.");
				int money = scanner.nextInt();
				member.deposit(money);
				break;
			case 2:
				System.out.println("출금할 금액을 입력하세요.");
				money = scanner.nextInt();
				member.withDraw(money);
				break;
			case 3:
				member.balance();
				break;
			case 4:
				// 미구현
			case 5:
				run = false;
				break;
				
			default:
				System.out.println("잘못입력했습니다.");
			}

		} while (run);
//		return idx;

	}
	*/
}
