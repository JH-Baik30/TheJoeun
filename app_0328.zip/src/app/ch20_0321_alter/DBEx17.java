package app.ch20_0321_alter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * ORDER BY 문 - ORDER BY (ASC[ACSENDING], DESC[DESCENDING])
 * 정렬 [테이블 생성] : OBTEST
 * CREATE TABLE OBTEST( NUM INT, ID VARCHAR(10));
 */
public class DBEx17 {
	public static void main(String[] args) {
		Connection conn = DBAction.getInstance().getConnection();
//		PreparedStatement pstmt = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			
			String sql = insert();
			int result = stmt.executeUpdate(sql);
			String msg = result > -1 ? "성공" : "실패";
			System.out.println(msg);
			
			/*
			String sql = orderBy();
			rs = stmt.executeQuery(sql);
			ResultSetMetaData rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				String columnName = rsmd.getCatalogName(1);
				System.out.println(columnName = "\t");
			}
			System.out.println("\n---------------------------------");
			
			while (rs.next()) {
				for (int i = 1; i <= cols; i++) {
					System.out.println(rs.getString(i) + "\t");
				}
				System.out.println();
			}*/
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
		
	}
	
	public static String insert() {
		String sql = "INSERT INTO test5 VALUES(1, 'abc')";
//		String sql = "INSERT INTO test4 VALUES(2, 'edf')";
//		String sql = "INSERT INTO test4 VALUES(3, 'ghi')";
		
		return sql;
	}
	
	public static String orderBy() {
//		String sql = "SELECT * FROM OBTEST ORDER BY NUM ASC"; // 오름차순
		String sql = "SELECT * FROM OBTEST ORDER BY ID DESC"; // 내림차순
		return sql;
	}
	
	// 실습과제> 뱅크 사용자 등급별로 VIP 기준 내림차순으로 정렬하여 출력하시오.
}
