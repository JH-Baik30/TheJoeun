package app.ch20_0322_UI.Test01;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class AddressDBContact {
	static ArrayList<String> arr = new ArrayList<>();
	static Connection conn = DBAction.getInstance().getConnection();
	static Statement stmt = null;
	static ResultSet rs = null;
	static ResultSetMetaData rsmd = null;
	
	public static ArrayList<String> sidoDB (String sql){
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			arr.add("  ");
			while (rs.next()) {
				for (int i = 1; i <= cols; i++) {
					arr.add(rs.getString(i));
				}
			}
			return arr;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs !=  null) rs.close();
				if (stmt != null) stmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return null;
	}

	public static ArrayList<String> gugunDB (String sql){
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			arr.add("  ");
			while (rs.next()) {
				for (int i = 1; i <= cols; i++) {
					arr.add(rs.getString(i));
				}
			}
			return arr;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs !=  null) rs.close();
				if (stmt != null) stmt.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return null;
	}
	

	public ArrayList<String> getsido() {
		String sql = "SELECT DISTINCT sido FROM ZIPCODE";
		return sidoDB(sql);
	}
	
	public ArrayList<String> getGugun(String si) {
		String sql = "SELECT DISTINCT GUGUN FROM ZIPCODE WHERE SIDO='" + si + "'";
		return gugunDB(sql);
	}
	
	public void closeDB() throws SQLException {
		if(conn != null) conn.close();
		System.out.println("종료");
	}
	
	
	
	
	
	
	
	
}
