package test.uitest;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class DualPanelDemo extends JFrame {

    private JPanel leftPanel;
    private JPanel rightPanel;
    private JButton button1;
    private JButton button2;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            DualPanelDemo frame = new DualPanelDemo();
            frame.setVisible(true);
        });
    }

    public DualPanelDemo() {
        initializeLeftPanel();
        initializeRightPanel();

        setLayout(new BorderLayout());
        add(leftPanel, BorderLayout.WEST);
        add(rightPanel, BorderLayout.CENTER);

        setBounds(100, 100, 450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void initializeLeftPanel() {
        leftPanel = new JPanel();
        leftPanel.setBackground(Color.WHITE);
        button1 = new JButton("Panel 1");
        button2 = new JButton("Panel 2");
        leftPanel.add(button1);
        leftPanel.add(button2);

        // 버튼에 ActionListener 추가
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rightPanel.removeAll();
                rightPanel.add(new JButton("Button in Panel 1"));
                rightPanel.revalidate();
                rightPanel.repaint();
            }
        });

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rightPanel.removeAll();
                rightPanel.add(new JButton("Button in Panel 2"));
                rightPanel.revalidate();
                rightPanel.repaint();
            }
        });
    }

    private void initializeRightPanel() {
        rightPanel = new JPanel();
        rightPanel.setBackground(Color.LIGHT_GRAY);
        rightPanel.add(new JPanel());
    }
}