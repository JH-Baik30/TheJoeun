package app.ch05;

public class ForEx3 {
	public static void main(String[] args) {
		for (String str : args) {
			System.out.println(str);
		}
	}
}
