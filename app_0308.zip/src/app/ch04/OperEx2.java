package app.ch04;

public class OperEx2 {
	public static void main(String[] args) {
		int x = 30;
		int y = 20;
		boolean result1 = x < y;
		System.out.println("결과1 : " + result1);
		boolean result2 = x > y;
		System.out.println("결과2 : " + result2);
		boolean result3 = x <= y;
		System.out.println("결과3 : " + result3);
		boolean result4 = x >= y;
		System.out.println("결과4 : " + result4);
		boolean result5 = x == y;
		System.out.println("결과5 : " + result5);
		boolean result6 = x != y;
		System.out.println("결과6 : " + result6);
		boolean result7 = !result1;
		System.out.println("결과7 : " + result7);
	}
}
