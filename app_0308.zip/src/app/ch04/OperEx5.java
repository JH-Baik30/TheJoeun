package app.ch04;

public class OperEx5 {
	public static void main(String[] args) {
		int su1 = 10;
		int su2 = 20;
		int sum;
		sum = su1 + su2;
		System.out.println(sum);
		sum += su1;
		System.out.println(sum);
		sum -= su1;
		System.out.println(sum);
		sum *= su1;
		System.out.println(sum);
		sum /= su1;
		System.out.println(sum);
		sum %= su1;
		System.out.println(sum);

		sum = 0;
		int i = 1;
		sum += i++;
		sum += i++;
		sum += i++;
		sum += i++;
		sum += i++;
		sum += i++;
		sum += i++;
		sum += i++;
		sum += i++;
		sum += i;
		System.out.println(sum);
	}

}
