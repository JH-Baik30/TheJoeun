package app.ch12;
// 날자의 시작점이 다르다.
// getActualMaximum
// set method 를 이용하자.
// 구구단 수준

import java.util.Calendar;
import java.util.Scanner;

// cal.set(year, month, date); // 원하는 년, 월, 일 설정
// int date = Calendar.DAY_OF_WEEK // 월 시작 일 (DAY_OF_WEEK)
// getActualMinimum​(int field) // field 최대 일(DATE)
public class CalendarUi {
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		Scanner scan = new Scanner(System.in);
//		System.out.println("연");
//		int year = scan.nextInt();
//		System.out.println("월");
//		int mon = scan.nextInt();		
//		cal.set(year, mon, 1);
		cal.set(2023, 03, 1);
		
//		System.out.println("	" + year + "년 " +  mon + "월 ");
		System.out.println("	" + 2023 + "년 " +  03 + "월 ");
		System.out.println();
		String[] days = { "일", "월", "화", "수", "목", "금", "토" };
		for (String day : days) {
			System.out.print(day + "\t");
		}
		System.out.println();
		
		// 시작 일자
		int tab = cal.getActualMinimum(Calendar.DAY_OF_MONTH);
		int endDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		int week = endDay / 7;
		System.out.println(tab);
		for (int i = 1; i < tab; i++) {
			System.out.print("1 " + "\t");
		}
		for (int i = 1; i < week; i++) {
			System.out.println(11);
			for (int j = 0; j < args.length; j++) {
			}
		}
	}
}
