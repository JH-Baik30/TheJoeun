package app.ch03;

public class CastEx {
	public static void main(String[] args) {
		long a = 1000000000000000000L;
		int b = 100;
		b = (int)a;
		System.out.println(a);
		System.out.println(b);
		
		double d = 3.4587468468;
		System.out.println(Math.round(d));
	}
}
