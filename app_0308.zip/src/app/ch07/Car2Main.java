package app.ch07;

public class Car2Main {

}
