package app.ch07.test.test2;

import app.ch07.test.*;

public class ClassC extends ClassA{
	public static void main(String[] args) {
		
		ClassA ca = new ClassA();
		ca.print();
//		ClassB cb = new ClassB();
	}
}
