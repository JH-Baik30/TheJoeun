package app.ch08.makeClassEx;

public class OfficePc extends PcBase{
	
	void workPC() {
		Amd amd = new Amd("5700");
		Intel intel = new Intel("12400");
		
		powerOn();
		work();
		exel();
		powerOff();
	}
	
	void work() {
		System.out.println("업무를 시작합니다.");
	}
	void exel () {
		System.out.println("엑셀을 굴립니다.");
	}
}
