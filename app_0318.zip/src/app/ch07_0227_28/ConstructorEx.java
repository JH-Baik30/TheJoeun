package app.ch07_0227_28;

public class ConstructorEx {
	int a;
	String b;
	
	//overload 성립조건
	ConstructorEx() {
		
	}
	ConstructorEx(int b) {
		a = b;
	}
	ConstructorEx(String b) {
		this.b = b;        // this -> 멤버를 가리킨다.
	}
	ConstructorEx(int b, int c) {
		a = b;
	}
	ConstructorEx(int b, String c) {
		a = b;
	}
	ConstructorEx(String b, int c) {
		a=c;
	}
	
	
	public static void main(String[] args) {
		ConstructorEx obj = new ConstructorEx();
		System.out.println(obj.a);
	}
}
