package app.ch07_0227_28;

public class ClassEx {
	public static void main(String[] args) {
		Member m = new Member();
		Member m2 = new Member();
		
		if (m == m2) {
			System.out.println("m객체와 m2 객체는 같다.");
		} else {
			System.out.println("m객체와 m2 객체는 다르다. \n");
		}

		int a = 1;
		int b = 1;
		
		if (a == b) {
			System.out.println("a객체와 b 객체는 같다. \n");
		} else {
			System.out.println("a객체와 b 객체는 다르다. \n");
		}
		
		ClassEx c = new ClassEx();
		ClassEx c2 = new ClassEx();
		
		if (c == c2) {
			System.out.println("c객체와 c2 객체는 같다. \n");
		} else {
			System.out.println("c객체와 c2 객체는 다르다. \n");
		}
		
		
		
		
		
	}
}

class Member{
	
}