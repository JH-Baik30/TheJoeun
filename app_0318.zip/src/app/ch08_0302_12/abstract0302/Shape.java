package app.ch08_0302_12.abstract0302;

public abstract class Shape {
	protected int x, y;
	double pi = Math.PI;
	public abstract double area();
	public abstract double circumference();
}
