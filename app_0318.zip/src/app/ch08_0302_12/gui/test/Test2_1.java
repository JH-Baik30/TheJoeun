package app.ch08_0302_12.gui.test;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Choice;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

public class Test2_1 extends WindowAdapter implements ItemListener{
	TextArea ta;
	Checkbox ch1, ch2, ch3, ch4, ch5, ch6;
	public Test2_1() {
		JFrame frame = new JFrame();
		Panel p1 = new Panel();
		Panel p2 = new Panel();
		Panel p3 = new Panel();
		Panel p4 = new Panel();
		
		CheckboxGroup ch = new CheckboxGroup();
		ch1 = new Checkbox("아침", true, ch);
		ch2 = new Checkbox("점심", false, ch);
		ch3 = new Checkbox("저녁", false, ch);
		ch4 = new Checkbox("사과", false);
		ch5 = new Checkbox("딸기", false);
		ch6 = new Checkbox("배", false);
		Label[] la = new Label[9];
		for (int i = 0; i < la.length; i++) {
			la[i]= new Label(""); 
		}
		
		ta = new TextArea("<<자바 수강생 식생활>>", 20, 20, 3);
		
		Choice cho = new Choice();
		cho.add("아침");
		cho.add("점심");
		cho.add("저녁");
		
		p1.setLayout(new GridLayout(2, 4));
		p2.setLayout(new BorderLayout());
		p3.setLayout(new BorderLayout());
		p4.setLayout(new BorderLayout());
		
		p1.add(la[0]);	p1.add(ch1);	p1.add(ch2);	p1.add(ch3);
		p1.add(la[1]);	p1.add(ch4);	p1.add(ch5);	p1.add(ch6);
		
		p2.add(p1, BorderLayout.CENTER);
		p2.add(la[2], BorderLayout.SOUTH);
		
		p3.add(ta, BorderLayout.CENTER);
//		p2.add(la3, BorderLayout.NORTH);
		p3.add(la[3], BorderLayout.EAST);
		p3.add(la[4], BorderLayout.WEST);
//		p2.add(la6, BorderLayout.SOUTH);
		
		p4.add(cho, BorderLayout.CENTER);
		p4.add(la[5], BorderLayout.NORTH);
		p4.add(la[6], BorderLayout.EAST);
		p4.add(la[7], BorderLayout.WEST);
		p4.add(la[8], BorderLayout.SOUTH);
		
//		setLayout(new GridLayout(3, 1));
		frame.add(p2, BorderLayout.NORTH);
		frame.add(p3, BorderLayout.CENTER);
		frame.add(p4, BorderLayout.SOUTH);
		frame.setSize(300, 300);
		frame.setVisible(true);
		frame.addWindowListener(this);
		
		ch1.addItemListener(this);
		ch2.addItemListener(this);
		ch3.addItemListener(this);
		ch4.addItemListener(this);
		ch5.addItemListener(this);
		ch6.addItemListener(this);
	
	}
	
	@Override
	public void itemStateChanged(ItemEvent e) {
		
		
		System.out.println(e.getSource());
		Object obj = e.getSource();
		Checkbox str = (Checkbox) obj;
		//str.equals(ch6);
		//System.out.println(str);
		//ta.setText("1. 사과 :" + str.getState()+ "\n2. 딸기 :" + str.getState()+ "\n3. 배  :" + str.getState());
		//checkbox0.
		//ta.setText(ch4.getState() + ch5.getState() + ch6.getState());
	}
	
	public void windowClosing(WindowEvent e) {
		System.exit(0);
	}

	
	public static void main(String[] args) {
		new Test2_1();
	}
}
