package app.ch05_0224;

public class ForEx3 {
	public static void main(String[] args) {
		for (String str : args) {
			System.out.println(str);
		}
	}
}
