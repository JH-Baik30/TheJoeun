package app.ch20_0315_17;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class DBEx5_1 {
	// 연습문제) DBTEST2 TABLE 을 만들고 ID, PW 컬럼으로 데이터를 저장하시오.
	public static void main(String[] args) throws IOException {
//		String driver = "com.mysql.cj.jdbc.Driver";
//		String url = "jdbc:mysql://localhost:3306/app";

		Properties properties = new Properties();
//		properties.load(DBEx5_1.class.getResourceAsStream("database.properties"));
		String driver = properties.getProperty("driver");
		String url = properties.getProperty("url");
		String id = properties.getProperty("username");
		String pw = properties.getProperty("password");
		Connection conn = null;
		Statement stmt = null;
		
		try {
			Class.forName(driver);
			System.out.println("데이터베이스 드라이버 로딩성공!");
//			conn = DriverManager.getConnection(url, "root", "java");
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("데이터베이스 연결성공!");
			stmt = conn.createStatement();
			String sql = "CREATE TABLE DBTEST3(ID VARCHAR(10),"
					+ " PW VARCHAR(10), AGE INTEGER, CRE_DATE DATETIME)";	// INT or INTEGER 같음
			int result = stmt.executeUpdate(sql);
			String msg = result > -1 ? "성공" : "실패";

			sql = insert();
			result = stmt.executeUpdate(sql);
			msg = result > -1 ? "성공" : "실패";
			
		} catch (Exception e) {
			System.out.println("연결 실패!!!!");
		} finally {
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {		}
		}
	}
	public static String insert() {
		Scanner scan = new Scanner(System.in);
		System.out.println("DBTEST3 테이블에 값 입력하기");
		System.out.print("ID = ");
		String id = scan.next(); 
		System.out.print("PW = ");
		String pw = scan.next();
		System.out.print("AGE = ");
		int age = scan.nextInt();
//		INSERT INTO DBTEST3 VALUES('ABC', '123', 10, NOW())
		String sql = "INSERT INTO DBTEST3 VALUES('"
				+ id + "', '" + pw + "', " + age + ", now())";
		return sql;
	}
}
