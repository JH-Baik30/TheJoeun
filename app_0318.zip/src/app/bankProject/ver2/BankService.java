package app.bankProject.ver2;
//정현도움!!!!
public class BankService {
	public static void main(String[] args) {
		BankMenu bankMenu = new BankMenu();
		bankMenu.memberSystem();
	}
}


