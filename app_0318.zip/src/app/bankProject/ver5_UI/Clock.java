package app.bankProject.ver5_UI;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Clock {
	public static void main(String[] args) {
		Thread thread = new Thread();
		while (true) {
			try {
				Date now = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd hh:mm:ss E a");
				System.out.println(sdf.format(now));
				thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
