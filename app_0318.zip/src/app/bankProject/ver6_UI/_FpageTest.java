package app.bankProject.ver6_UI;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class _FpageTest extends Frame{
	public Panel p1;
	public Label lb1, lb2;
	public TextField tf1, tf2;
	public Button bt1, bt2;
	
	public _FpageTest() {
		p1 = new Panel();
		lb1 = new Label("lb1");
		lb2 = new Label("lb2");
		tf1 = new TextField("tf1");
		tf2 = new TextField("tf2");
		bt1 = new Button("bt1");
		bt2 = new Button("bt2");
		
		p1.setLayout(new GridLayout(2,3));
		p1.add(lb1);
		p1.add(tf1);
		p1.add(lb2);
		p1.add(tf2);
		p1.add(bt1);
		p1.add(bt2);
		
		setLayout(new BorderLayout());
		add(p1, "South");
		
		setSize(300, 300);
		setVisible(true);
		
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		
		
		
		
		
	}
	
	public static void main(String[] args) {
		new _FpageTest();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
