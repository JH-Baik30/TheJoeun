package app.bankProject.ver6_UI;

public class Member {
	//field
	private int account;
	private String name;
	private String pw;
	int balance;
	
	public Member(int account, String name, String pw) {
		this.account = account;
		this.name = name;
		this.pw = pw;
	}
	
	public void name() {
		
	} Member(int account, String name, String pw, int balance) {
		this.account = account;
		this.name = name;
		this.pw = pw;
		this.balance = balance;
	}
	
	// getter, setter method
	public int getAccount() 	{	return account;		}
	public String getName() 	{	return name;		}
	public String getPw() 		{	return pw;			}
	
	public void info() {
		System.out.println(getName() + " 님의 계좌번호는 " + getAccount() + " 입니다.");
		System.out.println("패스워드는 " + getPw() + " 로 설정 되었습니다.");
	}
	
	// 입금 메소드
	public void deposit(int deposit) {
		balance += deposit;
	}
	
	// 출금 메소드
	public void withDraw(int withDraw) {
		if (withDraw > balance) {
			System.out.println("요청 금액이 예금액보다 적습니다.");
		} else {
			balance -= withDraw;
			System.out.println(withDraw + " 원이 출금되었습니다.");
			balance();
		}
	}
	
	// 이체 메소드
	public void transfer(int transferMoney) {
		balance -= transferMoney;
	}
	
	// 잔고 확인
	public void balance() {
		System.out.println("현재 예금액은 " + balance + " 원입니다.");
	}
}
