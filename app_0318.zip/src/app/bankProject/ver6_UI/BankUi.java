package app.bankProject.ver6_UI;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import app.bankProject.ver4.CreateAccMenu2;

public class BankUi extends JFrame implements ActionListener{
	Toolkit toolkit = Toolkit.getDefaultToolkit();
//	Menu menu = new Menu();
	public JPanel cards, frontP, bankP, jp1, jp2, jp3, jp4;
	public JButton logInbt, creAccbt, bt1, bt2, bt3, bt4, bt5, bt6, btLogIn, btExit;
	public JTextArea ta; String to;
	public JLabel label, idLabel, pwLabel, blankLb1, blankLb2, blankLb3, blankLb4, blankLb5;
	public JTextField tf, logId, logPw;
	public BankUi() {
		cards = new JPanel(new CardLayout());
		
//		LogIn Panel
		frontP = new JPanel();
		frontP.setLayout(new BorderLayout());
		idLabel = new JLabel("ID");
		pwLabel = new JLabel("PW");
		logId = new JTextField("");
		logPw = new JTextField("");
		logInbt = new JButton("로그인");
		creAccbt = new JButton("회원가입"); 
		
//		LogIn Panel 에 담기
		frontP.add(idLabel, "main");
		frontP.add(pwLabel );
		frontP.add(logId   );
		frontP.add(logPw   );
		frontP.add(logInbt );
		frontP.add(creAccbt);
		
		
		
		
		
//		Banking Panel
		bankP = new JPanel();
		jp1 = new JPanel();	// west
		jp2 = new JPanel();	// center
		jp3 = new JPanel(new BorderLayout()); 	// east
		jp4 = new JPanel(new FlowLayout()); 	// south
		
		bt1 = new JButton("입  금");
		bt2 = new JButton("출  금");
		bt3 = new JButton("예금조회");
		jp1.setLayout(new GridLayout(3, 1));
		jp1.add(bt1);	jp1.add(bt2);	jp1.add(bt3);
//		
		jp2.setLayout(new BorderLayout());
		tf = new JTextField(nowTime());
		tf.setEditable(false);
		ta = new JTextArea("<< 안녕하세요 >>" + "\n" +"<< 당신의 이웃 당이 은행입니다~");
		ta.setEditable(false);
		jp2.add(tf, BorderLayout.NORTH); jp2.add(ta, BorderLayout.CENTER);
		
		
		bt4 = new JButton("계좌 이체");
		bt5 = new JButton("공 사 중");
		bt6 = new JButton("계좌 개설");
		jp3.setLayout(new GridLayout(3, 1));
		jp3.add(bt4);	jp3.add(bt5);	jp3.add(bt6);
		
		btLogIn = new JButton("로 그 인");
		btExit = new JButton("종   료");
		jp4.setLayout(new GridLayout(1, 4));

		JLabel imgLabel = new JLabel(), imgLabel2 = new JLabel();
		ImageIcon icon = new ImageIcon(BankUi.class.getResource("bank-transfer.png"));
		Image img = icon.getImage();
		Image updateImg = img.getScaledInstance(100, 60, Image.SCALE_SMOOTH);
		ImageIcon updateIcon = new ImageIcon(updateImg);
		ImageIcon updateIcon2 = updateIcon;
		imgLabel.setIcon(updateIcon);
		imgLabel2.setIcon(updateIcon2);
		imgLabel.setBounds(20, 220, 180, 100);
		imgLabel.setBounds(20, 220, 180, 100);
		imgLabel2.setBounds(370, 220, 180, 100);
		jp4.add(imgLabel);
		jp4.add(btLogIn); jp4.add(btExit);
		jp4.add(imgLabel2);

		
		

		
//		Banking Panel 에 담기
		bankP.add(jp1, "West");		//왼쪽
		bankP.add(jp2, "Center");		//중앙
		bankP.add(jp3, "East");		//오른쪽
		bankP.add(jp4, "South");		//아래
		
//		2개 패널을 메인 프레임에 담기
		cards.add(frontP);
		cards.add(bankP);
		
		add(cards);
		setSize(500, 300);
		setVisible(true);
		
		tf.addActionListener(this);
//		bt1.addActionListener(ActionEvent e ({
//			cards.show(frontP.getParent(),"main");
//		}));
		bt2.addActionListener(this);
		bt3.addActionListener(this);
		bt4.addActionListener(this);
		bt5.addActionListener(this);
		bt6.addActionListener(this);
		btExit.addActionListener(this);
		btLogIn.addActionListener(this);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
//	public String nowTime() {
////		Date now = new Date();
////		new SimpleDateFormat("yyy.MM.dd hh:mm:ss E a");
////		SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd hh:mm:ss E a");
////		tf.setText(now.toString());
//		Date from = new Date();
//		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		String to = transFormat.format(from);
//		return to;
//	}
	
	String nowTime() {
		Date now = new Date();
		
		Thread timeThread = new Thread(()-> {
			SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd HH:mm:ss");
			sdf.format(now);
			to = sdf.format(now);
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
			}
		});
		timeThread.start();
		return to;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		ta.setText(dTime());
		Object obj = e.getSource();
		if (obj == bt1) {
			toolkit.beep();			
			ta.setText(" << 입금을 선택하셨습니다. >>");
			
		} else if (obj == bt2) {
			toolkit.beep();
			ta.setText(" << 출금을 선택하셨습니다. >>");
			
		} else if (obj == bt3) {
			toolkit.beep();
			ta.setText(" << 조회를 선택하셨습니다. >>");
		} else if (obj == bt4) {
			toolkit.beep();
			ta.setText(" << 계좌이체를 선택하셨습니다. >>");
		} else if (obj == bt5) {
			toolkit.beep();
			ta.setText(" << 서비스 준비중 >>");
			
		} else if (obj == bt6) {
			toolkit.beep();
			ta.setText(" << 계좌 개설을 선택하셨습니다. >>");
//			menu.creatAccount();
		}
		
	}
	
	public String dTime() {
		Thread thread = new Thread();
		while (true) {
			try {
				Date now = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd HH:mm:ss");
				String dateTime = sdf.format(now);
				tf.setText(dateTime);
//				System.out.println(sdf.format(now));
				thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public static void main(String[] args) {
//		Thread t = new Thread();
		new BankUi();
//		t.start();
	}

//	@Override
//	public void run() {
//		while (true) {
//			Date now = new Date();
//			tf.setText(now.toString());
//			System.out.println(now.toString());
//			try {
//				Thread.sleep(1000);
//			} catch (Exception e) {
//			}
//		}
//	}
}


//슨생님 코드
//public static void time() {
//	Date now = new Date();
//	Thread timeThread = new Thread(()-> {
//		SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd hh:mm:ss E a");
//		sdf.format(now);
//		try {
//			Thread.sleep(1000);
//		} catch (Exception e) {
//		}
//	});
//	timeThread.start();
//}

//	public void time() {
//		Thread thread = new Thread();
//		while (true) {
//			try {
//				Date now = new Date();
//				SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd hh:mm:ss E a");
//				System.out.println(sdf.format(now));
//				String td = sdf;
//				label.setText(now.toString());
//				thread.sleep(1000);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		}
//	}

//	public String nowTime() {
//		Date now = new Date();
//		SimpleDateFormat sdf = new SimpleDateFormat("yyy.MM.dd hh:mm:ss E a");
//		tf.setText(now.toString());
//		return null;
//	}